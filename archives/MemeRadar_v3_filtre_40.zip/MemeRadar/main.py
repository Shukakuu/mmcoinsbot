#!/usr/bin/env python3
"""MemeRadar: LOCAL-ONLY read-only Solana discovery dashboard.

Usage: py main.py [--port 8765] [--interval 20] [--demo] [--once]
Never accepts private keys or places trades.
"""
from __future__ import annotations
import argparse, csv, io, json, threading, time, webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
from radar.engine import Radar
from radar.store import Store

ROOT=Path(__file__).resolve().parent
WEB=ROOT/'web'


def demo_payload():
    now=time.time()
    coins=[]
    specimens=[('NOVA','Nova Pup',78,'a_etudier',82,41200,79000,6,17.5,1.2),
               ('ORBIT','Orbit Cat',71,'a_etudier',90,93500,182000,47,5.1,3.7),
               ('PIXEL','Pixel Frog',62,'surveillance',70,20900,18000,12,-2.7,8.4),
               ('MIMI','Mimi',46,'incomplet',40,9400,12300,3,27.1,9.2),
               ('FOMO','Fomo King',83,'risque',90,3200,220000,8,110,-50.0),
               ('HUSH','Hush Duck',38,'incomplet',35,None,None,None,None,None)]
    for i,(symbol,name,score,status,cover,liq,vol,age,m5,h1) in enumerate(specimens):
        mint=('A'*(32+i))+'BCDE' # fictitious base58 strings, no real address
        prices=[0.000014*(1+i*0.2)*(1+0.012*x+0.08*__import__('math').sin(x*0.8+i)) for x in range(15)]
        risks=['Liquidité < 5 000 $','Pump > 70 % en 5 minutes'] if status=='risque' else []
        unknown=['Score RugCheck indisponible','Prix du même pool non confirmé'] if status=='incomplet' else []
        coins.append({'mint':mint,'symbol':symbol,'name':name,'score':score,'status':status,'coverage':cover,
          'liquidity_usd':liq,'volume_h1_usd':vol,'age_min':age,'change_m5_pct':m5,'change_h1_pct':h1,
          'buys_h1':105-i*10,'sells_h1':45+i*7,'price_usd':prices[-1],'first_price_usd':prices[0],
          'market_cap_usd':(liq*2.5 if liq else None),'fdv_usd':(liq*2.8 if liq else None),
          'pair_address':None,'gecko_gap_pct':1.4 if cover>=80 else None,
          'first_seen':now-2000,'last_seen':now-60,'sources':['gecko_new_pools','dex_profiles'] if i%2 else ['gecko_trending_pools'],
          'wallets':[],'wallet_hit_count':0,'patterns':([{'key':'early','label':'Départ précoce','why':'Exemple fictif de momentum initial.'}] if i==0 else [{'key':'momentum','label':'Impulsion acheteuse','why':'Exemple fictif de pression acheteuse.'}] if i==1 else []),'positives':['Momentum modéré','Volume en progression'] if score>60 else [],
          'risks':risks,'unknown':unknown,'safety_summary':{'mint_active':False if cover>70 else None,
          'freeze_active':False if cover>70 else None,'top10_pct':19.4 if cover>70 else None,
          'rugcheck_score':12 if cover>70 else None,'lp_locked_pct':None},
          'history':[{'ts':now-900+60*x,'price':p} for x,p in enumerate(prices)],
          'observed_change_pct':round((prices[-1]/prices[0]-1)*100,2),
          'pieces':{'liquidité':12,'volume/liquidité':9,'pression acheteuse':8,'sécurité autorités':10}})
    return {'coins':coins,'stats':{'total':len(coins),'interesting':2,'incomplete':2,'risky':1},
      'status':{'mode':'demo','running':False,'last_scan':now,'cycle':1,'scanned':6,'discovered':6,
      'interval_seconds':20,'next_scan':None,'started_at':None,'finished_at':now,'duration_seconds':0,
      'phase':'Simulation figée','progress_done':0,'progress_total':0,'last_outcome':'ok','new_tokens':0,
      'errors':['Exemple fictif : aucune connexion aux marchés ; aucun de ces tokens n’est une recommandation.']}}


def make_handler(radar, demo=False):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt,*args):
            if not self.path.startswith('/api/data'): super().log_message(fmt,*args)

        def respond(self,body,content_type='application/json; charset=utf-8',code=200):
            if isinstance(body,str): raw=body.encode('utf-8')
            else: raw=json.dumps(body,ensure_ascii=False,allow_nan=False).encode('utf-8')
            self.send_response(code)
            self.send_header('Content-Type',content_type)
            self.send_header('Content-Length',str(len(raw)))
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
            self.end_headers();self.wfile.write(raw)

        def do_GET(self):
            path=urlparse(self.path).path
            if path=='/api/data': return self.respond(demo_payload() if demo else radar.view())
            if path=='/api/export':
                coins=(demo_payload() if demo else radar.view())['coins']
                s=io.StringIO();writer=csv.writer(s)
                writer.writerow(['mint','symbol','score_non_calibre','statut','couverture_pct','prix_usd',
                   'liquidite_usd','volume_h1_usd','variation_5m_pct','age_paire_min','sources','signaux_observes','risques','inconnus'])
                for r in coins:
                    writer.writerow([r.get('mint'),r.get('symbol'),r.get('score'),r.get('status'),r.get('coverage'),
                         r.get('price_usd'),r.get('liquidity_usd'),r.get('volume_h1_usd'),r.get('change_m5_pct'),
                         r.get('age_min'),';'.join(r.get('sources',[])),';'.join(p.get('label','') for p in r.get('patterns',[])),';'.join(r.get('risks',[])),';'.join(r.get('unknown',[]))])
                return self.respond(s.getvalue(),'text/csv; charset=utf-8')
            if path in ('/','/index.html','/style.css','/app.js'):
                file=WEB/('index.html' if path=='/' else path.lstrip('/'))
                ctype='text/html; charset=utf-8' if file.suffix=='.html' else ('text/css; charset=utf-8' if file.suffix=='.css' else 'application/javascript; charset=utf-8')
                return self.respond(file.read_text(encoding='utf-8'),ctype)
            self.respond({'error':'not found'},code=404)

        def do_POST(self):
            if urlparse(self.path).path!='/api/refresh':return self.respond({'error':'not found'},code=404)
            if demo:return self.respond({'error':'Mode démo : aucun scan réseau'},code=400)
            if not radar.request_scan():
                return self.respond({'ok':False,'running':radar.status['running'],
                                     'error':'Scan déjà en cours ou déjà demandé'},code=409)
            self.respond({'ok':True,'queued':True},code=202)
    return Handler


def main():
    parser=argparse.ArgumentParser(description='MemeRadar (lecture seule, interface localhost)')
    parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--interval',type=int,default=20,help='Secondes après chaque cycle (minimum 20)')
    parser.add_argument('--limit',type=int,default=14,help='Tokens analysés par cycle (1-25)')
    parser.add_argument('--db',default=str(ROOT/'radar.db'))
    parser.add_argument('--wallets',default=str(ROOT/'wallets.txt'))
    parser.add_argument('--rpc',default='https://api.mainnet-beta.solana.com',help='RPC Solana public ou personnel')
    parser.add_argument('--demo',action='store_true',help='Affiche des tokens FICTIFS sans requête externe')
    parser.add_argument('--once',action='store_true',help='Exécute un cycle et s’arrête sans interface')
    parser.add_argument('--no-browser',action='store_true')
    args=parser.parse_args()
    if args.once and args.demo:
        parser.error('--once et --demo ne peuvent pas être combinés')
    radar=None if args.demo else Radar(args.db,args.wallets,args.interval,args.limit,args.rpc)
    if args.once:
        print('Lancement d’un cycle de détection en lecture seule...')
        done=radar.run_once();print(json.dumps({'success':done,'status':radar.status,'stats':radar.view()['stats']},ensure_ascii=False,indent=2));return
    if not args.demo:
        threading.Thread(target=radar.run_loop,name='radar-scanner',daemon=True).start()
    url=f'http://127.0.0.1:{args.port}'
    server=ThreadingHTTPServer(('127.0.0.1',args.port),make_handler(radar,args.demo))
    print('MemeRadar', 'DÉMO FICTIVE' if args.demo else 'LIVE SCAN', '|', url)
    print('Lecture seule. Aucune clé privée, transaction, position ou ordre. Ctrl+C pour stopper.')
    if not args.no_browser: threading.Timer(0.8,lambda:webbrowser.open(url)).start()
    try: server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt: print('\nArrêt de MemeRadar.')
    finally:
        if radar is not None:
            radar.stop_event.set()
            radar.refresh_event.set()
        server.server_close()

if __name__=='__main__':main()
