# MemeRadar v8 — J7 → Narrative → Lancement Solana

Scanner de recherche **local et en lecture seule** pour les memecoins Solana. **Aucun achat, vente, signature, wallet privé ou copy-trading automatique.** Les alertes ne constituent pas des recommandations financières ; les pertes totales sont possibles.

## Installation Windows 11 (Python 3.13 recommandé)

1. **Sauvegardez votre ancien dossier**, en particulier `radar.db` et `wallets.txt`.
2. Décompressez MemeRadar v8 dans **un nouveau dossier**. Ne fusionnez pas l'extraction avec un vieux répertoire.
3. Dans CMD ou PowerShell depuis le dossier `MemeRadar` :

```powershell
py -3 -m pip install -r requirements-j7.txt
```

4. Lancez `START_J7.ps1` (double-clic via PowerShell, ou `powershell -File .\START_J7.ps1`). Entrez votre token **J7Tracker** dans la console. Aucun token n'est stocké dans le code, l'interface ou la base.
5. Ouvrez **http://127.0.0.1:8765** (le script peut aussi ouvrir le navigateur automatiquement).
6. Vérifiez les diagnostics : **Moteur v8.0**, connexion J7 et statut de PumpPortal.

Le flux PumpPortal de **créations** et de **migrations** est tenté automatiquement sans clé API. Si le fournisseur requiert une clé ou refuse la connexion, un diagnostic apparaît ; le scanner traditionnel continue. Une clé Data API peut être définie facultativement dans `PUMPPORTAL_API_KEY`, mais elle n'est **pas** créée ou payée par MemeRadar. **Aucun abonnement aux flux de trades facturés** n'est effectué. Pour désactiver complètement le flux : `py -3 main.py --no-launch-feed`.

### Conserver un historique plus récent

- Si vous avez téléchargé la version **avec historique**, elle contient la copie du `radar.db` reçu précédemment (6 984 tokens). **Elle n'inclut pas vos futures observations**.
- Si votre ancien dossier a tourné depuis le dernier envoi, utilisez la version **code seul**, puis copiez votre `radar.db` le plus récent **après arrêt du bot**.
- À la première ouverture, le schéma SQLite est migré vers `PRAGMA user_version=8`. L'ancienne recherche v1/v2/v3 reste accessible. **Ne remplacez pas votre sauvegarde par la base migrée sans garder l'original.**
- Les anciennes structures ne sont pas supprimées ni modifiées par la nouvelle migration.

## Fonctionnement exact du backend

### 1. J7Tracker (Socket.IO)

Le client existant reçoit les publications de comptes surveillés et leurs mises à jour. MemeRadar extrait de façon *explicable* certaines expressions (par exemple `DOOMSDAY`, `GTA VI`, `OPENAI`, des hashtags, tickers et noms propres). Les **surlignages graphiques propriétaires** de J7 ne sont pas exposés comme tels dans son API documentée : l'extraction de MemeRadar n'est pas une copie fidèle de leur algorithme. Une publication ne prouve **jamais** qu'un auteur soutient un token donné.

Les alias GTA VI sont conservés, mais les nouvelles expressions peuvent aussi être reconnues dynamiquement. Les références exactes des posts sont stockées pour expliquer la provenance et la fraîcheur des rapprochements.

### 2. Créations et migrations (PumpPortal, gratuit selon le fournisseur)

Le module `radar/live_launches.py` ouvre **une connexion WebSocket** et envoie uniquement `subscribeNewToken` et `subscribeMigration`. **Aucun `subscribeTokenTrade`, `subscribeAccountTrade` ni API d'ordres.**

Chaque création est enregistrée dans `live_launches` avec mint, nom, ticker, timestamp de réception, `marketCapSol` et autres valeurs natives effectivement présentes. Les valeurs en SOL ne sont **jamais inventées comme prix USD**. Un token correspondant à une narrative active est affiché immédiatement **« Non vérifié »**, même si DexScreener ne connaît pas encore son prix. Les clones restent des mints indépendants.

Les autres lancements sont conservés dans un registre léger. Un échantillon témoin est sélectionné selon un hachage déterministe du mint **avant de connaître son résultat**. Ils ne sont pas promus comme opportunités.

### 3. Cotations et contrôles indépendants

- Le scanner historique DexScreener/GeckoTerminal/RugCheck continue d'enrichir les candidats en arrière-plan.
- La voie rapide J7 affiche le token avant de solliciter un fournisseur de prix. Une voie distincte recherche les cotations DEX.
- Un autre worker, borné en fréquence, consulte Solana RPC pour enregistrer les plus gros **comptes token bruts** et, si possible, la part détenue par le wallet signalé au lancement. **Ces chiffres incluent potentiellement les réserves et ne prouvent aucun lien insider/developer.** Les erreurs RPC restent « non vérifié ».
- Les données manquantes **ne donnent ni zéro risque ni validation d'une stratégie**.

### 4. Évaluation avec témoins

La route `/api/evaluation` calcule une comparaison *descriptive* à partir des nouvelles observations v8 : tokens reliés à J7 et témoins sélectionnés avant de connaître leur avenir. Les contrôles sont ensuite rapprochés par plateforme, heure (±15 min) et capitalisation initiale en SOL quand elle est connue. Le prix de référence est la première cotation disponible **à partir de 30 secondes après le lancement**, et l'évaluation utilise une cotation observée à l'horizon, pas le pic a posteriori. Toute observation manquante reste **non mesurée**. Il n'y a ni exécution de trade, ni slippage réel, ni garantie de vendre. **Les deux groupes ne permettent pas de prouver une causalité J7.**

Les tables de résultats nouvelles ne sont pas remplies rétroactivement à partir des anciennes alertes : seul un nouveau fonctionnement peut produire une comparaison prospective valide.

### 5. Interface

- Thème sombre minimaliste, compatible mobile.
- Mots J7, derniers lancements associés, risques, historiques et statuts.
- Un lien **Axiom** pour chaque mint Solana, plus DexScreener et Solscan dans la fiche.
- Diagnostic de connexion J7 et PumpPortal, des échecs RPC et des cotations.
- Aucune fonctionnalité de connexion à un wallet ou de transaction.

## Tests

```powershell
py -3 -m unittest discover -s tests -q
```

Démo sans données réelles :

```powershell
py -3 main.py --demo --port 8765
```

**Important :** le mode démo montre des tokens fictifs. N'utilisez pas leur valeur, leur score ou leur adresse comme donnée de marché.

## Limites restantes, à ne pas masquer

- Les premiers snipers peuvent acheter dans le bloc de création ; aucune garantie d'être premier avec le flux public.
- La qualité d'un signal J7 dépend des comptes réellement accessibles dans votre abonnement.
- Le RPC Solana public peut être indisponible ou limité. Les analyses de wallets liés, ventes coordonnées et PnL réels des snipers **ne sont pas validées** par ce module.
- La performance affichée dans la comparaison est une **variation de prix observée, pas un gain réalisable**.
- Le score historique est encore **heuristique et non calibré** ; il ne mesure pas une probabilité de hausse.
- Le refactoring v8 a isolé la sélection et les nouveaux flux ; l'ancien pipeline demeure présent pour compatibilité. Il ne faut pas affirmer que toute la dette technique historique a disparu.
- MemeRadar reste une application **locale** ; ne l'exposez pas sur Internet sans véritable authentification et architecture dédiée.

## Sources et conformité

- [J7Tracker : flux Socket.IO](https://docs.j7tracker.io/docs/feed)
- [PumpPortal : flux de créations](https://pumpportal.fun/data-api/real-time/)
- [PumpPortal : tarifs et flux gratuits](https://pumpportal.fun/fees/)

Conservez une sauvegarde avant toute migration. Les anciens guides sont classés dans `docs/historique` et l'ancien frontend dans `docs/ancien_frontend` ; les anciens modules de recherche demeurent actifs pour lire l'historique.
