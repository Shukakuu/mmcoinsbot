#!/usr/bin/env python3
"""À LANCER CHEZ TOI avant le premier démarrage live : vérifie que les services réels répondent comme le bot
l'attend. Aucun ordre, aucune clé privée. Les clés API ne sont jamais affichées.

    export HELIUS_API_KEY=...  JUPITER_API_KEY=...     (Windows : set HELIUS_API_KEY=...)
    python validate_sources.py [--mint MINT_DE_TEST] [--wallet ADRESSE]

Copie-colle la sortie complète (y compris le bloc « FORMES ») si une ligne est ❌ ou ⚠ : je corrigerai le code
d'après les vraies réponses. Un format qui a changé, c'est des filtres qui rejettent tout (ou pire, laissent tout passer)."""
import argparse
import json
import os
import sys
from pathlib import Path

from bot.http import HttpError, get_json, post_json
from bot.market import LiveMarket, WSOL
from bot.safety import SafetyChecker
from bot.sources.rpc_poll import parse_swap

DEFAULT_MINT = "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"   # BONK : liquide, a des paires en SOL
PUBLIC_RPC = "https://api.mainnet-beta.solana.com"
OK, WARN, FAIL = "✅", "⚠️ ", "❌"


def shape(o, depth=3):
    """Structure d'une réponse (clés et types, jamais les valeurs) : sûr à partager."""
    if isinstance(o, dict):
        return {k: (shape(v, depth - 1) if depth > 0 else type(v).__name__) for k, v in list(o.items())[:30]}
    if isinstance(o, list):
        return [shape(o[0], depth - 1)] if o and depth > 0 else f"liste[{len(o)}]"
    return type(o).__name__


def check_dexscreener(get, mint):
    try:
        raw = get(f"https://api.dexscreener.com/latest/dex/tokens/{mint}")
    except HttpError as e:
        return FAIL, f"appel impossible : {e}", None
    pairs = raw.get("pairs") if isinstance(raw, dict) else None
    if not pairs:
        return FAIL, "aucune paire renvoyée (mauvais token de test ? essaie --mint)", shape(raw)
    sol = [p for p in pairs if p.get("chainId") == "solana" and (p.get("quoteToken") or {}).get("address") == WSOL]
    if not sol:
        return WARN, "des paires existent mais aucune cotée en SOL : le bot ne verrait pas ce token", shape(pairs[0])
    best = max(sol, key=lambda p: (p.get("liquidity") or {}).get("usd") or 0)
    missing = [k for k, ok in (("priceNative", best.get("priceNative")), ("priceUsd", best.get("priceUsd")),
                               ("liquidity.usd", (best.get("liquidity") or {}).get("usd")),
                               ("pairCreatedAt", best.get("pairCreatedAt")), ("fdv", best.get("fdv"))) if not ok]
    if missing:
        return FAIL, f"champs attendus absents : {missing}", shape(best)
    return OK, f"{len(sol)} paire(s) SOL ; prix {best['priceNative']} SOL ; liquidité {best['liquidity']['usd']:,.0f} $", shape(best)


def check_dex_discovery(get):
    """Flux de découverte (profils + boosts). Format vérifié sur une réponse réelle ; renvoie aussi un mint à tester."""
    from bot.sources.dexscreener import BASE, FEEDS, parse_discovery
    found, shapes = {}, {}
    for source, path in FEEDS:
        try:
            raw = get(BASE + path)
        except HttpError as e:
            return FAIL, f"{path} : {e}", None, None
        shapes[source] = shape(raw[:1] if isinstance(raw, list) else raw, 2)
        for c in parse_discovery(raw, source):
            found.setdefault(c["mint"], c)
    if not found:
        return WARN, "aucun token Solana dans les flux à cet instant (possible, réessaie)", shapes, None
    return OK, f"{len(found)} token(s) Solana distincts (profils + boosts)", shapes, next(iter(found))


def check_dex_pairs(get, mint):
    """Route /token-pairs/v1/solana/{mint} : prix, liquidité, volume, transactions (format non vérifié par moi)."""
    from bot.sources.dexscreener import BASE, best_sol_pair, pair_fields
    try:
        raw = get(f"{BASE}/token-pairs/v1/solana/{mint}")
    except HttpError as e:
        return FAIL, f"appel impossible : {e}", None, None
    pair = best_sol_pair(raw)
    if pair is None:
        return WARN, "aucune paire cotée en SOL pour ce token (essaie un autre --mint)", shape(raw[:1] if isinstance(raw, list) else raw, 2), None
    f = pair_fields(pair)
    miss = [k for k in ("price_sol", "liquidity_usd", "pair_age_min", "volume_h1_usd", "buys_h1", "sells_h1") if f[k] is None]
    if f["price_sol"] is None or f["liquidity_usd"] is None:
        return FAIL, f"champs critiques absents : {miss}", shape(pair, 2), None
    note = f" (champs de momentum absents : {miss})" if miss else ""
    return (WARN if miss else OK), f"prix {f['price_sol']:.3g} SOL, liquidité {f['liquidity_usd']:,.0f} $, âge {f['pair_age_min']:.0f} min{note}", \
        shape(pair, 2), pair.get("pairAddress")


def check_rugcheck_report(get, mint):
    """Route /report : risques, autorités du token, top holders (format non vérifié par moi)."""
    try:
        raw = get(f"https://api.rugcheck.xyz/v1/tokens/{mint}/report")
    except HttpError as e:
        return FAIL, f"appel impossible : {e}", None
    if not isinstance(raw, dict) or not isinstance(raw.get("risks"), list):
        return FAIL, "pas de liste 'risks' : format changé, le filtre RugCheck serait aveugle", shape(raw)
    tok = raw.get("token") or {}
    has_auth = "mintAuthority" in tok or "mintAuthority" in raw
    holders = raw.get("topHolders")
    notes = []
    if not has_auth:
        notes.append("autorité mint introuvable (le bot la jugera inconnue et rejettera)")
    if not isinstance(holders, list) or not any(isinstance(h, dict) and "pct" in h for h in holders):
        notes.append("top holders sans champ 'pct' (concentration inconnue)")
    return (WARN if notes else OK), f"{len(raw['risks'])} risque(s)" + (" ; " + " ; ".join(notes) if notes else ""), shape(raw, 2)


def check_gecko_ohlcv(get, pool):
    from bot.sources import geckoterminal as GT
    GT._limiter.min_interval = 0
    try:
        candles = GT.fetch_ohlcv(pool, limit=30, get=get)
    except HttpError as e:
        return FAIL, f"appel impossible : {e}", None
    if not candles:
        return WARN, "aucune bougie lisible (format ou pool trop récent)", None
    return OK, f"{len(candles)} bougies d'une minute lues", None


def check_rugcheck(get, mint):
    try:
        raw = get(f"https://api.rugcheck.xyz/v1/tokens/{mint}/report/summary")
    except HttpError as e:
        return FAIL, f"appel impossible : {e} (le bot rejettera TOUS les tokens : require_rugcheck=true)", None
    risks = raw.get("risks") if isinstance(raw, dict) else None
    if not isinstance(risks, list):
        return FAIL, "pas de liste 'risks' : le format a changé, le filtre RugCheck serait aveugle", shape(raw)
    levels = sorted({str(r.get("level", "?")).lower() for r in risks if isinstance(r, dict)})
    if risks and not (set(levels) - {"?"}):
        return FAIL, "les risques n'ont pas de champ 'level'", shape(raw)
    return OK, f"{len(risks)} risque(s), niveaux vus : {levels or ['aucun']}", shape(raw)


def check_mint(safety, mint):
    mi = safety.mint_info(mint)
    if not mi:
        return FAIL, "lecture du mint impossible (RPC ? clé Helius ?)", None
    return OK, f"autorité mint active={mi['mint_authority_active']}, freeze active={mi['freeze_authority_active']}, décimales={mi['decimals']}", mi


def check_jupiter(safety, mint, price_sol, size_sol=0.1):
    st = safety.sell_test(mint, 6, price_sol, size_sol) if price_sol else None
    rt = safety.roundtrip_test(mint, size_sol)
    if st is None and rt is None:
        return FAIL, (f"aucune cotation ({safety.jup_base}). Clé manquante ou URL obsolète ? "
                      "Crée une clé gratuite sur portal.jup.ag, puis JUPITER_API_KEY=... "
                      "(l'ancienne URL lite-api.jup.ag devait être retirée en 2026)"), None
    if rt is None:
        return WARN, "cotation de vente OK mais aller-retour mesuré indisponible : le bot utilisera l'estimation", {"sell": st}
    return OK, f"aller-retour mesuré pour {size_sol} SOL : {rt:.1f} % ; vente possible={st[0] if st else '?'}", {"sell": st, "rt": rt}


def check_wallet_txs(post, rpc_url, wallet, n_sigs=10, n_tx=5):
    try:
        sigs = post(rpc_url, {"jsonrpc": "2.0", "id": 1, "method": "getSignaturesForAddress", "params": [wallet, {"limit": n_sigs}]})["result"]
    except (HttpError, KeyError) as e:
        return FAIL, f"getSignaturesForAddress impossible : {e}", None
    if not sigs:
        return WARN, "ce wallet n'a aucune transaction récente", None
    parsed = fetched = 0
    first_shape = None
    for s in [x for x in sigs if x.get("err") is None][:n_tx]:
        try:
            tx = post(rpc_url, {"jsonrpc": "2.0", "id": 1, "method": "getTransaction",
                                "params": [s["signature"], {"encoding": "jsonParsed", "maxSupportedTransactionVersion": 0}]})["result"]
        except (HttpError, KeyError) as e:
            return FAIL, f"getTransaction impossible : {e}", None
        if tx:
            fetched += 1
            first_shape = first_shape or shape(tx, 2)
            parsed += 1 if parse_swap(tx, wallet) else 0
    if fetched == 0:
        return FAIL, "aucune transaction lisible (format ou accès RPC)", None
    return OK, f"{fetched} tx lues, {parsed} reconnues comme achat/vente par le bot", first_shape


def check_gmgn(runner=None):
    """Flux smart money de GMGN (clé personnelle GMGN_API_KEY + gmgn-cli). Vérifie que les champs dont le bot a
    besoin existent : sans prix, la dérive est inconnue (tout est rejeté) ; sans horodatage, on prend l'heure d'arrivée."""
    from bot.sources.gmgn import PRICE_KEYS, TS_KEYS, extract_records, run_cli
    if runner is None:
        if not os.getenv("GMGN_API_KEY"):
            return WARN, "GMGN_API_KEY absente : source GMGN non testée (clé sur https://gmgn.ai/ai ; npm install -g gmgn-cli)", None
        runner = run_cli
    try:
        raw = runner(["track", "smartmoney", "--chain", "sol", "--limit", "20", "--raw"])
    except RuntimeError as e:
        return FAIL, f"{e} (réseau IPv4 uniquement ; clé valide ?)", None
    recs = extract_records(raw)
    if not recs:
        return FAIL, "aucun enregistrement avec 'maker' + 'base_address' : le format a changé ou la liste est vide", shape(raw)
    fields = set().union(*[set(r) for r in recs])
    need = [k for k in ("maker", "side", "base_address", "amount_usd") if k not in fields]
    if need:
        return FAIL, f"champs indispensables absents : {need}", shape(recs[0], 1)
    ts_k, px_k = [k for k in TS_KEYS if k in fields], [k for k in PRICE_KEYS if k in fields]
    if not px_k:
        return WARN, (f"{len(recs)} trades lus mais AUCUN champ de prix ({list(PRICE_KEYS)}) : la dérive serait inconnue et le bot "
                      "rejetterait tout. Envoie-moi la forme ci-dessous."), shape(recs[0], 1)
    if not ts_k:
        return WARN, f"{len(recs)} trades lus, prix OK ({px_k}) mais aucun horodatage : heure d'arrivée utilisée", shape(recs[0], 1)
    return OK, f"{len(recs)} trades lus ; horodatage={ts_k[0]}, prix={px_k[0]}", shape(recs[0], 1)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--mint", default=DEFAULT_MINT)
    ap.add_argument("--wallet", default=None)
    ap.add_argument("--wallets-file", default="wallets.txt")
    a = ap.parse_args()

    key = os.getenv("HELIUS_API_KEY")
    rpc = f"https://mainnet.helius-rpc.com/?api-key={key}" if key else PUBLIC_RPC
    safety = SafetyChecker(rpc)
    wallet = a.wallet
    if not wallet and Path(a.wallets_file).exists():
        for line in Path(a.wallets_file).read_text(encoding="utf-8").splitlines():
            if line.split("#")[0].strip():
                wallet = line.split("#")[0].strip()
                break

    results, shapes = [], {}

    def run(name, fn):
        try:
            st, msg, sh = fn()
        except Exception as e:  # noqa: BLE001
            st, msg, sh = FAIL, f"exception inattendue : {type(e).__name__}: {e}", None
        results.append((st, name, msg))
        if sh is not None:
            shapes[name] = sh

    if not key:
        results.append((WARN, "HELIUS_API_KEY", "absente : RPC public (limité, sans garantie). Définis la variable."))
    results.append((OK if os.getenv("JUPITER_API_KEY") else WARN, "JUPITER_API_KEY",
                    "présente" if os.getenv("JUPITER_API_KEY") else "absente : les cotations Jupiter échoueront probablement"))
    run("DexScreener", lambda: check_dexscreener(get_json, a.mint))
    price = None
    try:
        price = LiveMarket(safety).price_at(a.mint)
    except Exception:  # noqa: BLE001
        pass
    run("RugCheck (résumé)", lambda: check_rugcheck(get_json, a.mint))
    run("RugCheck (rapport complet)", lambda: check_rugcheck_report(get_json, a.mint))
    holder = {}

    def _disc():
        st, msg, sh, mint = check_dex_discovery(get_json)
        holder["mint"] = mint
        return st, msg, sh
    run("DexScreener (découverte)", _disc)

    def _pairs():
        st, msg, sh, pool = check_dex_pairs(get_json, holder.get("mint") or a.mint)
        holder["pool"] = pool
        return st, msg, sh
    run("DexScreener (paires /token-pairs)", _pairs)
    if holder.get("pool"):
        run("GeckoTerminal (bougies)", lambda: check_gecko_ohlcv(get_json, holder["pool"]))
    run("RPC : lecture du mint", lambda: check_mint(safety, a.mint))
    run("Jupiter (cotations)", lambda: check_jupiter(safety, a.mint, price))
    if wallet:
        run("RPC : transactions d'un wallet", lambda: check_wallet_txs(post_json, rpc, wallet))
    else:
        results.append((WARN, "RPC : transactions d'un wallet", "aucun wallet fourni (--wallet ADRESSE ou wallets.txt)"))
    run("GMGN (flux smart money)", lambda: check_gmgn())
    if os.getenv("TELEGRAM_BOT_TOKEN") and os.getenv("TELEGRAM_CHAT_ID"):
        results.append((OK, "Telegram", "variables présentes (un message de test partira au démarrage du live)"))
    else:
        results.append((WARN, "Telegram", "variables absentes : pas d'alertes (optionnel)"))

    print("=" * 66 + "\nVALIDATION DES SOURCES RÉELLES\n" + "=" * 66)
    for st, name, msg in results:
        print(f"{st} {name:34s} {msg}")
    print("\n--- FORMES (clés et types seulement, sans valeurs ni clés API) ---")
    print(json.dumps(shapes, indent=1, ensure_ascii=False)[:6000])
    bad = sum(1 for r in results if r[0] == FAIL)
    print(f"\n{'TOUT EST OK' if not bad and all(r[0] == OK for r in results) else f'{bad} échec(s)'} : "
          "ne lance `python main.py live` qu'une fois les ❌ réglés.")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
