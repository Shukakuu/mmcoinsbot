import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from bot.config import load_config                      # noqa: E402
from bot.convergence import ConvergenceDetector         # noqa: E402
from bot.db import Journal                              # noqa: E402
from bot.filters import apply_filters                   # noqa: E402
from bot.market import ReplayMarket                     # noqa: E402
from bot.models import TokenInfo, WalletEvent           # noqa: E402
from bot.paper import PaperBroker                       # noqa: E402
from bot.risk import RiskManager                        # noqa: E402
from bot.simulate import generate, WALLETS              # noqa: E402
from bot.sources.rpc_poll import parse_swap             # noqa: E402
from bot.wallets import WalletBook                      # noqa: E402
from bot.engine import Engine                           # noqa: E402
from bot.health import HEALTH                           # noqa: E402
from bot.market import LiveMarket                       # noqa: E402
from bot.models import Position                         # noqa: E402
from bot.scoring import score_candidate, _age_points    # noqa: E402
from bot.convergence import Signal                      # noqa: E402
from bot.costs import estimate_roundtrip_cost_pct       # noqa: E402
from bot.engine import trail_pct_for                    # noqa: E402
from bot.fingerprint import fingerprint                 # noqa: E402
from bot.gate import evaluate, bootstrap_p_positive     # noqa: E402
from bot import execution_policy as XP                  # noqa: E402
from bot.alerts import Notifier                         # noqa: E402
from bot.http import mask, HttpError                    # noqa: E402
from bot.lock import InstanceLock                       # noqa: E402
from unittest import mock                               # noqa: E402
import validate_sources as VS                           # noqa: E402
from bot.review import classify, review, summarize, format_review   # noqa: E402
from bot.sources.gmgn import GmgnSource, extract_records, parse_ts, to_event   # noqa: E402
from bot.execution import Executor, JupiterExecutor, LiveTradingDisabled, PaperExecutor, make_executor   # noqa: E402
from bot.risk import dynamic_size                       # noqa: E402
from bot.risk.sizing import concordance, context_factor, signal_strength   # noqa: E402
from bot.sources.dexscreener import DexClient, best_sol_pair, pair_fields, parse_discovery   # noqa: E402
from bot.sources import geckoterminal as GT             # noqa: E402
from bot.sources.pumpportal import PumpPortalSource, parse_trade   # noqa: E402
from bot.scout import Scout                             # noqa: E402
from bot.jsonl import JsonlLog                          # noqa: E402
from bot.safety import SafetyChecker                    # noqa: E402
import re as _re                                        # noqa: E402
from main import run_replay                             # noqa: E402


def cfg_det():
    c = load_config()
    c["sim"]["tx_fail_prob"] = 0.0
    return c


def book_for(tmp, wallets):
    p = Path(tmp) / "w.txt"
    p.write_text("\n".join(f"{w}  # source=manual cluster={c}" for w, c in wallets.items()))
    return WalletBook(p, enforce_j7_freshness=False)


def good_info(**kw):
    d = dict(mint="M", price_sol=1.0, liquidity_usd=80000, fdv_usd=1e6, pair_age_min=60,
             mint_authority_active=False, freeze_authority_active=False, rugcheck_levels=["info"],
             sell_quote_ok=True, sell_impact_pct=0.5, x_flags=[])
    d.update(kw)
    return TokenInfo(**d)


class FiltersTest(unittest.TestCase):
    def test_clean_token_passes(self):
        self.assertEqual(apply_filters(None, good_info(), 5.0, load_config()), [])

    def test_each_red_flag_rejects(self):
        c = load_config()
        cases = {"mint_authority_active": dict(mint_authority_active=True),
                 "freeze_authority_active": dict(freeze_authority_active=True),
                 "low_liquidity": dict(liquidity_usd=5000),
                 "no_sell_route(honeypot?)": dict(sell_quote_ok=False),
                 "high_sell_impact": dict(sell_impact_pct=9),
                 "rugcheck_danger": dict(rugcheck_levels=["danger"]),
                 "pair_too_new": dict(pair_age_min=2),
                 "x_veto:new_account": dict(x_flags=["new_account"])}
        for expected, kw in cases.items():
            self.assertIn(expected, apply_filters(None, good_info(**kw), 5.0, c), expected)
        self.assertIn("late_entry_drift", apply_filters(None, good_info(), 60.0, c))

    def test_unknown_critical_data_fails_closed(self):
        c = load_config()
        for field in ("mint_authority_active", "freeze_authority_active", "liquidity_usd",
                      "sell_quote_ok", "sell_impact_pct", "rugcheck_levels", "pair_age_min"):
            r = apply_filters(None, good_info(**{field: None}), 5.0, c)
            self.assertTrue(any(x.startswith("unknown:") for x in r), field)


class ConvergenceTest(unittest.TestCase):
    def test_same_cluster_counts_once_and_independent_fire(self):
        with tempfile.TemporaryDirectory() as tmp:
            book = book_for(tmp, {"a1": "A", "a2": "A", "a3": "A", "b": "B", "c": "C"})
            det = ConvergenceDetector(load_config(), book)
            mk = lambda w, t: WalletEvent(ts=t, wallet=w, side="buy", mint="M", sol_amount=1, token_amount=100)
            self.assertIsNone(det.on_buy(mk("a1", 0)))
            self.assertIsNone(det.on_buy(mk("a2", 10)))
            self.assertIsNone(det.on_buy(mk("a3", 20)))         # 3 wallets mais 1 seul cluster
            self.assertIsNone(det.on_buy(mk("b", 30)))          # 2 clusters
            sig = det.on_buy(mk("c", 40))                       # 3 clusters -> signal
            self.assertIsNotNone(sig)
            self.assertEqual(sig.clusters, 3)
            self.assertIsNone(det.on_buy(mk("c", 50)))          # pas de re-déclenchement

    def test_window_expires(self):
        with tempfile.TemporaryDirectory() as tmp:
            book = book_for(tmp, {"x": "X", "y": "Y", "z": "Z"})
            det = ConvergenceDetector(load_config(), book)
            mk = lambda w, t: WalletEvent(ts=t, wallet=w, side="buy", mint="M", sol_amount=1, token_amount=100)
            det.on_buy(mk("x", 0))
            det.on_buy(mk("y", 60))
            self.assertIsNone(det.on_buy(mk("z", 3600)))        # x et y sont sortis de la fenêtre de 15 min


class WalletWeightTest(unittest.TestCase):
    def test_losing_wallet_gets_zero_weight_after_probation(self):
        with tempfile.TemporaryDirectory() as tmp:
            book = book_for(tmp, {"w": "W"})
            for i in range(5):                                   # 5 allers-retours perdants (-50 %)
                book.observe(WalletEvent(ts=i * 10, wallet="w", side="buy", mint=f"M{i}", sol_amount=2, token_amount=100))
                book.observe(WalletEvent(ts=i * 10 + 5, wallet="w", side="sell", mint=f"M{i}", sol_amount=1, token_amount=100))
            self.assertEqual(book.weight("w"), 0.0)
            self.assertEqual(book.weight("inconnu"), 1.0)

    def test_stale_j7_wallets_are_ignored(self):
        with tempfile.TemporaryDirectory() as tmp:
            wp = Path(tmp) / "wallets.txt"
            wp.write_text("jj  # source=j7 first_seen=2026-10-01 last_seen=2026-10-01\nmm  # source=manual\n")
            book = WalletBook(wp, max_j7_age_min=120)
            self.assertEqual(book.active(1_000_000), {"mm"})     # pas de statut = pas de confiance
            (Path(tmp) / "j7_sync_status.json").write_text(json.dumps({"last_success": "2026-10-12T10:00:00+00:00"}))
            from datetime import datetime
            ts = datetime.fromisoformat("2026-10-12T10:30:00+00:00").timestamp()
            self.assertEqual(book.active(ts), {"jj", "mm"})
            self.assertEqual(book.active(ts + 3 * 3600), {"mm"})


class ParseSwapTest(unittest.TestCase):
    def tx(self, sol_delta, tok_delta, wsol=0.0):
        w = "WALLET"
        pre_tok = [{"owner": w, "mint": "TOK", "uiTokenAmount": {"uiAmountString": "1000"}}]
        post_tok = [{"owner": w, "mint": "TOK", "uiTokenAmount": {"uiAmountString": str(1000 + tok_delta)}}]
        return {"blockTime": 123, "transaction": {"signatures": ["sig1"], "message": {"accountKeys": [{"pubkey": w}, {"pubkey": "X"}]}},
                "meta": {"err": None, "fee": 5000, "preBalances": [10_000_000_000, 0],
                         "postBalances": [10_000_000_000 + int(sol_delta * 1e9) - 5000, 0],
                         "preTokenBalances": pre_tok, "postTokenBalances": post_tok}}

    def test_buy_and_sell(self):
        b = parse_swap(self.tx(-1.5, 500), "WALLET")
        self.assertEqual((b["side"], b["mint"]), ("buy", "TOK"))
        self.assertAlmostEqual(b["sol_amount"], 1.5, places=6)
        s = parse_swap(self.tx(2.0, -400), "WALLET")
        self.assertEqual(s["side"], "sell")
        self.assertAlmostEqual(s["sol_amount"], 2.0, places=6)

    def test_ambiguous_or_failed_ignored(self):
        self.assertIsNone(parse_swap(self.tx(0.0, 0), "WALLET"))
        t = self.tx(-1.0, 100)
        t["meta"]["err"] = {"InstructionError": 1}
        self.assertIsNone(parse_swap(t, "WALLET"))


class BrokerTest(unittest.TestCase):
    def test_costs_make_round_trip_a_loss_when_price_flat(self):
        data = {"sol_usd": 150, "tokens": {"M": {"price_path": [[0, 1.0], [10_000, 1.0]], "liquidity_usd": 80000}}}
        br = PaperBroker(cfg_det(), ReplayMarket(data, validate=False), 10.0)
        pos, why = br.buy("M", "M", 0.1, 100, ["w"])
        self.assertIsNotNone(pos, why)
        ok, proceeds, _ = br.sell(pos, 1.0, 200)
        self.assertTrue(ok)
        self.assertLess(proceeds, 0.1)                           # frais + slippage + pourboire

    def test_low_liquidity_hits_price_hard(self):
        def round_trip(liq):
            data = {"sol_usd": 150, "tokens": {"M": {"price_path": [[0, 1.0], [10_000, 1.0]], "liquidity_usd": liq}}}
            br = PaperBroker(cfg_det(), ReplayMarket(data, validate=False), 10.0)
            pos, _ = br.buy("M", "M", 1.0, 100, ["w"])
            return br.sell(pos, 1.0, 200)[1]
        shallow, deep = round_trip(3000), round_trip(300000)     # pool de 20 SOL contre 2000 SOL
        self.assertLess(shallow, 0.85)                           # ~ -20 % d'impact aller-retour
        self.assertGreater(deep, 0.93)                         # friction fixe ~5 % (frais, slippage de base, pourboires)
        self.assertLess(shallow, deep - 0.1)


class RiskTest(unittest.TestCase):
    def test_daily_loss_limit_and_cooldown(self):
        r = RiskManager(load_config())
        ok, why, size = r.check_entry(1000, 10.0, [], 80000, 150)
        self.assertTrue(ok)
        self.assertAlmostEqual(size, 0.1, places=6)             # 1 % de 10 SOL
        r.on_close(1100, -0.4)                                   # -4 % > limite de 3 %
        ok, why, _ = r.check_entry(1200, 9.6, [], 80000, 150)
        self.assertEqual((ok, why), (False, "daily_loss_limit"))
        ok, why, _ = r.check_entry(1000 + 86400 + 10, 9.6, [], 80000, 150)   # lendemain : réarmé
        self.assertTrue(ok)

    def test_consecutive_losses_trigger_cooldown(self):
        r = RiskManager(load_config())
        r.check_entry(0, 100.0, [], 80000, 150)
        for i in range(4):
            r.on_close(10 + i, -0.01)
        ok, why, _ = r.check_entry(100, 100.0, [], 80000, 150)
        self.assertEqual((ok, why), (False, "cooldown_after_losses"))
        ok, _, _ = r.check_entry(100 + 3700, 100.0, [], 80000, 150)
        self.assertTrue(ok)

    def test_stale_data_and_kill_switch_block(self):
        r = RiskManager(load_config())
        self.assertEqual(r.check_entry(0, 10.0, [], 80000, 150, data_ok=False)[:2], (False, "data_stale"))
        with tempfile.TemporaryDirectory() as tmp:
            stop = os.path.join(tmp, "STOP")
            open(stop, "w").close()
            r2 = RiskManager(load_config(), enforce_stop_file=True, stop_file=stop)
            self.assertEqual(r2.check_entry(0, 10.0, [], 80000, 150)[:2], (False, "kill_switch_file"))

    def test_size_limited_by_pool_liquidity(self):
        r = RiskManager(load_config())
        ok, _, size = r.check_entry(0, 1000.0, [], 30000, 150)   # 1 % de 1000 = 10 SOL, mais pool de 200 SOL
        self.assertTrue(ok)
        self.assertAlmostEqual(size, 30000 / 150 * 0.005, places=6)


class ScenarioTest(unittest.TestCase):
    """Rejoue le scénario synthétique SANS échec aléatoire et vérifie chaque comportement attendu."""
    @classmethod
    def setUpClass(cls):
        with tempfile.TemporaryDirectory() as tmp:
            data = generate()
            dp, wp = Path(tmp) / "s.json", Path(tmp) / "w.txt"
            dp.write_text(json.dumps(data))
            wp.write_text("\n".join(f"{w}  # source=manual cluster={c}" for w, c in WALLETS.items()))
            cls.engine, cls.j, _ = run_replay(cfg_det(), dp, wp, ":memory:", verbose_report=False)

    def decisions(self):
        return {r[0]: (r[1], json.loads(r[2])) for r in self.j.c.execute("SELECT symbol,decision,reasons FROM candidates")}

    def test_entries_and_rejections(self):
        d = self.decisions()
        for ok in ("RUNNER_A", "RUNNER_B", "SLOW_BLEED", "LOSER_C", "RUG", "RUNNER_D"):
            self.assertEqual(d[ok][0], "enter", ok)
        self.assertIn("no_sell_route(honeypot?)", d["HONEYPOT"][1])
        self.assertIn("mint_authority_active", d["MINT_ACTIVE"][1])
        self.assertIn("late_entry_drift", d["LATE_DRIFT"][1])
        self.assertIn("low_liquidity", d["LOW_LIQ"][1])
        self.assertIn("rugcheck_danger", d["RC_DANGER"][1])
        self.assertNotIn("SAME_CLUSTER", d)                      # 3 wallets du même cluster : aucun signal
        self.assertNotIn("BAIT", d)                              # un seul wallet : aucun signal

    def test_exit_reasons(self):
        ex = {r[0]: r[1] for r in self.j.c.execute("SELECT symbol,exit_reason FROM positions")}
        self.assertEqual(ex["SLOW_BLEED"], "stop_loss")
        self.assertEqual(ex["LOSER_C"], "stop_loss")
        self.assertEqual(ex["RUG"], "liquidity_collapse")
        self.assertIn(ex["RUNNER_A"], ("trailing_stop", "smart_wallets_sold"))

    def test_rug_loss_is_bounded_by_position_size(self):
        pnl = self.j.c.execute("SELECT pnl_sol FROM positions WHERE symbol='RUG'").fetchone()[0]
        self.assertGreater(pnl, -0.11)                           # <= ~1 % du capital de 10 SOL


class DailyLossFirstEventTest(unittest.TestCase):
    """Revue : si le 1er événement du jour est une clôture, le stop journalier doit quand même s'appliquer."""
    def test_close_is_first_event_of_the_day(self):
        r = RiskManager(load_config())
        r.check_entry(0, 10.0, [], 80000, 150)                    # jour 0
        day1 = 86400 + 100
        r.on_close(day1, -0.5, equity=9.5)                        # 1er événement du jour 1 : une perte de 5 %
        self.assertAlmostEqual(r.day_start_equity, 10.0, places=6)  # reconstitué : 9.5 - (-0.5)
        self.assertEqual(r.check_entry(day1 + 10, 9.5, [], 80000, 150)[:2], (False, "daily_loss_limit"))

    def test_close_without_equity_still_reconstructs_baseline(self):
        r = RiskManager(load_config())
        r.on_close(86400 + 5, -0.5)                               # equity inconnue à la clôture
        self.assertEqual(r.check_entry(86400 + 20, 9.5, [], 80000, 150)[:2], (False, "daily_loss_limit"))


class DeterminismTest(unittest.TestCase):
    def test_two_replays_give_identical_reports(self):
        with tempfile.TemporaryDirectory() as tmp:
            dp, wp = Path(tmp) / "s.json", Path(tmp) / "w.txt"
            dp.write_text(json.dumps(generate()))
            wp.write_text("\n".join(f"{w}  # source=manual cluster={c}" for w, c in WALLETS.items()))
            reports = [run_replay(load_config(), dp, wp, ":memory:", verbose_report=False)[2] for _ in range(2)]
            self.assertEqual(reports[0], reports[1])              # seed fixe : comparatifs de config possibles


def _scenario_files(tmp):
    dp, wp = Path(tmp) / "s.json", Path(tmp) / "w.txt"
    data = generate()
    dp.write_text(json.dumps(data))
    wp.write_text("\n".join(f"{w}  # source=manual cluster={c}" for w, c in WALLETS.items()))
    return data, dp, wp


class PersistenceTest(unittest.TestCase):
    def _engine(self, data, wp, journal):
        cfg = cfg_det()
        market = ReplayMarket(data)
        book = WalletBook(wp, enforce_j7_freshness=False, journal=journal)
        return Engine(cfg, market, book, journal, PaperBroker(cfg, market, cfg.capital.start_sol), RiskManager(cfg))

    def test_restart_restores_cash_positions_and_risk(self):
        with tempfile.TemporaryDirectory() as tmp:
            data, dp, wp = _scenario_files(tmp)
            db = str(Path(tmp) / "j.db")
            j1 = Journal(db)
            e1 = self._engine(data, wp, j1)
            for ev in sorted(data["events"], key=lambda e: e["ts"]):
                e1.handle_event(WalletEvent(ts=ev["ts"], wallet=ev["wallet"], side=ev["side"], mint=ev["mint"],
                                            sol_amount=ev["sol_amount"], token_amount=ev.get("token_amount")))
                if e1.positions:
                    break
            self.assertTrue(e1.positions)                        # on s'arrête avec une position ouverte
            e1.save_state()
            j2 = Journal(db)                                     # "redémarrage" : nouvel objet, même fichier
            e2 = self._engine(data, wp, j2)
            self.assertTrue(e2.load_state())
            self.assertAlmostEqual(e2.broker.cash, e1.broker.cash, places=9)
            self.assertEqual([p.id for p in e2.positions], [p.id for p in e1.positions])
            self.assertEqual(e2.risk.to_state(), e1.risk.to_state())
            self.assertEqual(e2.broker._next_id, e1.broker._next_id)

    def test_refuses_to_start_with_open_positions_but_no_state(self):
        with tempfile.TemporaryDirectory() as tmp:
            data, dp, wp = _scenario_files(tmp)
            j = Journal(str(Path(tmp) / "j.db"))
            j.log_position(Position(id=1, mint="M", symbol="M", open_ts=0, entry_price=1.0, tokens_initial=1,
                                    tokens_remaining=1, cost_sol=0.1, entry_liquidity_usd=1e5, wallets=[]))
            with self.assertRaises(RuntimeError):
                self._engine(data, wp, j).load_state()

    def test_replay_refuses_non_empty_journal(self):
        with tempfile.TemporaryDirectory() as tmp:
            data, dp, wp = _scenario_files(tmp)
            db = str(Path(tmp) / "j.db")
            Journal(db).kv_set("x", 1)
            with self.assertRaises(SystemExit):
                run_replay(cfg_det(), dp, wp, db, verbose_report=False)


class WatchConsistencyTest(unittest.TestCase):
    def test_watch_price_is_read_at_exact_due_time(self):
        with tempfile.TemporaryDirectory() as tmp:
            data, dp, wp = _scenario_files(tmp)
            eng, j, _ = run_replay(cfg_det(), dp, wp, ":memory:", verbose_report=False)
            market = ReplayMarket(data)
            ts0, p0, r1 = j.c.execute("SELECT ts0,price0,r_1h FROM watch WHERE mint='MINT_RUNNER_A'").fetchone()
            expected = (market.price_at("MINT_RUNNER_A", ts0 + 3600) / p0 - 1) * 100
            self.assertAlmostEqual(r1, expected, places=9)

    def test_live_market_refuses_to_pretend_current_price_is_old(self):
        class FakeSafety:
            pass
        lm = LiveMarket(FakeSafety())
        pair = {"priceNative": "0.001", "liquidity": {"usd": 50000}}
        import time as _t
        lm._cache["M"] = (_t.time(), pair)
        self.assertEqual(lm.price_at("M", _t.time()), 0.001)
        self.assertIsNone(lm.price_at("M", _t.time() - 3600))    # instant trop ancien : inconnu, pas un prix actuel


class ScenarioValidationTest(unittest.TestCase):
    def test_incomplete_scenario_raises_instead_of_disabling_filters(self):
        data = {"sol_usd": 150, "tokens": {"M": {"price_path": [[0, 1.0]], "liquidity_usd": 50000}}}
        with self.assertRaises(ValueError) as cm:
            ReplayMarket(data)
        self.assertIn("fdv_usd", str(cm.exception))
        self.assertIn("pair_created_ts", str(cm.exception))


class EquityCostsTest(unittest.TestCase):
    def test_equity_is_net_of_exit_costs(self):
        data = {"sol_usd": 150, "tokens": {"M": {"price_path": [[0, 1.0], [10_000, 1.0]], "liquidity_usd": 300000}}}
        br = PaperBroker(cfg_det(), ReplayMarket(data, validate=False), 10.0)
        pos, _ = br.buy("M", "M", 1.0, 100, ["w"])
        eq = br.equity(200, [pos])
        self.assertLess(eq, 10.0 - 0.05)     # frais 1 % x2, slippage, pourboire : jamais valorisé au prix brut


class SignalAgeAndHealthTest(unittest.TestCase):
    def test_old_signal_is_rejected(self):
        c = load_config()
        self.assertIn("signal_too_old", apply_filters(None, good_info(), 5.0, c, signal_age_s=c.entry.max_signal_age_s + 1))
        self.assertNotIn("signal_too_old", apply_filters(None, good_info(), 5.0, c, signal_age_s=10))

    def test_degraded_source_blocks_new_entries_but_not_exits(self):
        HEALTH.reset()
        HEALTH.threshold = 1
        try:
            HEALTH.fail("api.example")
            with tempfile.TemporaryDirectory() as tmp:
                data, dp, wp = _scenario_files(tmp)
                eng, j, _ = run_replay(cfg_det(), dp, wp, ":memory:", verbose_report=False)
                decisions = [r[0] for r in j.c.execute("SELECT decision FROM candidates")]
                self.assertNotIn("enter", decisions)
                reasons = [r[0] for r in j.c.execute("SELECT reasons FROM candidates WHERE decision='skip_risk'")]
                self.assertTrue(all("data_stale" in x for x in reasons) and reasons)
        finally:
            HEALTH.reset()
            HEALTH.threshold = 5


class ScoringTest(unittest.TestCase):
    def test_convergence_no_longer_saturates_at_three_wallets(self):
        c = load_config()
        mk = lambda w: Signal("M", 0, 1.0, 0, [], 0, w, 0)
        s3 = score_candidate(mk(3.0), good_info(), 5.0, c)[1]["convergence"]
        s8 = score_candidate(mk(8.0), good_info(), 5.0, c)[1]["convergence"]
        self.assertGreater(s8, s3 + 5)
        self.assertLessEqual(s8, 40.0)

    def test_age_ramp_is_smooth(self):
        c = load_config()
        pts = [_age_points(a, c) for a in (10, 15, 25, 40, 400, 720, 1500, 2880)]
        self.assertEqual(pts[0], 0.0)
        self.assertEqual(sorted(pts[:4]), pts[:4])               # monte
        self.assertEqual(pts[3], 10.0)
        self.assertGreaterEqual(pts[-1], 4.0)                    # redescend sans tomber à 0
        self.assertLess(pts[-1], 10.0)



class CostGateTest(unittest.TestCase):
    def test_fixed_tips_crush_small_positions(self):
        c = load_config()
        big = estimate_roundtrip_cost_pct(c, 0.1, 80000, 150)
        tiny = estimate_roundtrip_cost_pct(c, 0.01, 80000, 150)      # 1 % d'un compte d'~1 SOL (~150 $)
        self.assertLess(big, c.filters.max_roundtrip_cost_pct)
        self.assertGreater(tiny, 50)                                  # économiquement impossible
        self.assertEqual(estimate_roundtrip_cost_pct(c, 0.1, None, 150), 100.0)   # inconnu = prohibitif

    def test_expensive_roundtrip_is_rejected_by_filter(self):
        c = load_config()
        self.assertIn("high_roundtrip_cost", apply_filters(None, good_info(roundtrip_cost_pct=25.0), 5.0, c))
        self.assertNotIn("high_roundtrip_cost", apply_filters(None, good_info(roundtrip_cost_pct=6.0), 5.0, c))


def _bare_engine(cfg, path, tmp):
    market = ReplayMarket({"sol_usd": 150, "tokens": {"M": {"price_path": path, "liquidity_usd": 500000}}}, validate=False)
    j = Journal()
    book = WalletBook(Path(tmp) / "none.txt", enforce_j7_freshness=False)
    broker = PaperBroker(cfg, market, 10.0)
    eng = Engine(cfg, market, book, j, broker, RiskManager(cfg))
    pos, why = broker.buy("M", "M", 0.5, 0, ["w"])
    assert pos, why
    pos.decision_price, pos.risk_sol, pos.config_hash = 1.0, 0.1, eng.fingerprint
    eng.positions.append(pos)
    return eng, pos


class ExitImprovementsTest(unittest.TestCase):
    def test_trailing_tightens_with_peak(self):
        tiers, base = [[2.0, 25.0], [3.0, 18.0], [5.0, 14.0], [10.0, 10.0]], 25.0
        self.assertEqual(trail_pct_for(1.5, tiers, base), 25.0)
        self.assertEqual(trail_pct_for(3.2, tiers, base), 18.0)
        self.assertEqual(trail_pct_for(6.0, tiers, base), 14.0)
        self.assertEqual(trail_pct_for(25.0, tiers, base), 10.0)

    def test_breakeven_stop_after_a_35pct_run(self):
        with tempfile.TemporaryDirectory() as tmp:
            eng, pos = _bare_engine(cfg_det(), [[0, 1.0], [60, 1.0], [120, 1.45], [180, 1.02], [240, 1.02]], tmp)
            e = pos.entry_price
            eng.market.tokens["M"]["price_path"] = [[0, e], [60, e], [120, e * 1.45], [180, e * 1.02], [240, e * 1.02]]
            eng.market._ts["M"] = [p[0] for p in eng.market.tokens["M"]["price_path"]]
            for t in (60, 120, 180):
                eng._check_positions(t)
            self.assertEqual(eng.closed[0].exit_reason, "breakeven_stop")
            self.assertGreater(eng.closed[0].proceeds_sol, eng.closed[0].cost_sol * 0.85)   # sort proche du nul, pas à -20 %

    def test_no_breakeven_without_the_run(self):
        with tempfile.TemporaryDirectory() as tmp:
            eng, pos = _bare_engine(cfg_det(), [[0, 1.0]], tmp)
            e = pos.entry_price
            eng.market.tokens["M"]["price_path"] = [[0, e], [60, e * 1.20], [120, e * 1.02]]
            eng.market._ts["M"] = [0, 60, 120]
            for t in (60, 120):
                eng._check_positions(t)
            self.assertFalse(eng.closed)                                   # +20 % puis retour : pas de déclenchement


class MeasurementTest(unittest.TestCase):
    def test_positions_carry_mae_mfe_r_and_fingerprint(self):
        with tempfile.TemporaryDirectory() as tmp:
            data, dp, wp = _scenario_files(tmp)
            eng, j, _ = run_replay(cfg_det(), dp, wp, ":memory:", verbose_report=False)
            rows = j.c.execute("SELECT mae_pct,mfe_pct,r_multiple,config_hash,symbol FROM positions WHERE close_ts IS NOT NULL").fetchall()
            self.assertTrue(rows)
            for mae, mfe, r, h, sym in rows:
                self.assertLessEqual(mae, 0.0)
                self.assertGreaterEqual(mfe, 0.0)
                self.assertIsNotNone(r)
                self.assertEqual(h, eng.fingerprint)
            rug = [x for x in rows if x[4] == "RUG"][0]
            self.assertLess(rug[2], -1.0)                                  # le rug coûte plus que la perte visée : visible en R

    def test_fingerprint_changes_with_config(self):
        a, b = load_config(), load_config()
        self.assertEqual(fingerprint(a), fingerprint(b))
        b["exit"]["stop_loss_pct"] = 15.0
        self.assertNotEqual(fingerprint(a), fingerprint(b))


class PromotionGateTest(unittest.TestCase):
    def test_lucky_outlier_fails(self):
        rets = [-5.0] * 199 + [1500.0]                                      # 200 trades, UN énorme gagnant
        passed, checks = evaluate(rets, [r / 100 * 0.1 for r in rets], 10.0)
        self.assertFalse(passed)
        names = {n: ok for n, ok, _ in checks}
        self.assertFalse(names["profit factor >= 1.0 SANS les 3 meilleurs trades"])

    def test_real_bot_like_sample_fails(self):
        rets = [-8.0, -25.0, -14.0, -30.0, -34.0, 260.0, 30.0, -20.0, -32.0, -33.0, 9.0]
        self.assertFalse(evaluate(rets, [r / 100 * 18 for r in rets], 150.0)[0])

    def test_solid_sample_passes(self):
        pattern = [40.0, -15.0, -15.0, 40.0, -15.0, 40.0, -15.0, -15.0, 40.0, -15.0]
        rets = pattern * 30                                                 # 300 trades, +7 % par trade
        passed, checks = evaluate(rets, [r / 100 * 0.1 for r in rets], 10.0)
        self.assertTrue(passed, checks)

    def test_empty_and_determinism(self):
        self.assertFalse(evaluate([], [], 10.0)[0])
        r = [3.0, -2.0, 5.0, -1.0] * 10
        self.assertEqual(bootstrap_p_positive(r), bootstrap_p_positive(r))

    def test_cli_on_csv(self):
        import argparse, contextlib, io
        from main import run_gate
        with tempfile.TemporaryDirectory() as tmp:
            f = Path(tmp) / "t.csv"
            f.write_text("pnl_usd,mise_usd\n-5,30\n48,18\n-3,17\n")
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                passed = run_gate(load_config(), argparse.Namespace(real_csv=str(f), capital=150.0, db=None, all_configs=False))
            self.assertFalse(passed)
            self.assertIn("NON PASSÉE", out.getvalue())


class ExecutionPolicyTest(unittest.TestCase):
    def test_sell_slippage_never_exceeds_hard_cap(self):
        vals = [XP.sell_slippage_for_attempt(i) for i in range(8)]
        self.assertEqual(vals[0], XP.SELL_BASE_SLIPPAGE)
        self.assertTrue(all(v <= XP.SELL_HARD_CAP for v in vals))           # l'ancien bot montait à 45 %
        self.assertEqual(vals, sorted(vals))

    def test_stuck_after_max_attempts_and_buy_ceiling(self):
        acts = [XP.next_sell_action(i) for i in range(XP.MAX_SELL_ATTEMPTS)]
        self.assertEqual(acts[:-1], ["retry"] * (XP.MAX_SELL_ATTEMPTS - 1))
        self.assertEqual(acts[-1], "stuck")
        self.assertEqual(XP.buy_min_out(1000, slippage=0.5), 950)           # slippage d'achat borné à 5 %
        self.assertEqual(XP.buy_min_out(1000, price_ceiling_tokens=990), 990)   # le plafond de prix prime
        self.assertAlmostEqual(XP.realized_vs_expected_gap(0.010, 0.0093), 7.0, places=6)



class AlertsAndSecurityTest(unittest.TestCase):
    def test_telegram_token_and_api_keys_never_appear_in_error_messages(self):
        m = mask("https://api.telegram.org/bot123456:ABC-def_ghi/sendMessage?x=1")
        self.assertNotIn("123456", m)
        self.assertNotIn("ABC", m)
        self.assertNotIn("api-key", mask("https://mainnet.helius-rpc.com/?api-key=SECRET123"))
        self.assertNotIn("SECRET123", mask("https://mainnet.helius-rpc.com/?api-key=SECRET123"))

    def test_notifier_is_noop_without_credentials_and_dedupes(self):
        n = Notifier(token=None, chat_id=None)
        self.assertFalse(n.enabled)
        self.assertFalse(n.send("x"))
        sent = []
        with mock.patch("bot.alerts.post_json", side_effect=lambda url, data, **kw: sent.append((url, data)) or {"ok": True}):
            n2 = Notifier(token="1:ABC", chat_id="42")
            self.assertTrue(n2.send("a", key="k", min_interval=60))
            self.assertFalse(n2.send("a", key="k", min_interval=60))     # même alerte dans l'intervalle : ignorée
            self.assertTrue(n2.send("b", key="k2", min_interval=60))
        self.assertEqual(len(sent), 2)
        self.assertEqual(sent[0][1]["chat_id"], "42")

    def test_notifier_swallows_network_errors(self):
        with mock.patch("bot.alerts.post_json", side_effect=HttpError("boom")):
            self.assertFalse(Notifier(token="1:ABC", chat_id="42").send("x"))

    def test_engine_notifies_entry_exit_and_block(self):
        class Fake:
            def __init__(self): self.msgs = []
            def send(self, text, key=None, min_interval=0.0): self.msgs.append(text)
        with tempfile.TemporaryDirectory() as tmp:
            data, dp, wp = _scenario_files(tmp)
            fake = Fake()
            cfg = cfg_det()
            market = ReplayMarket(data)
            j = Journal()
            book = WalletBook(wp, enforce_j7_freshness=False, journal=j)
            eng = Engine(cfg, market, book, j, PaperBroker(cfg, market, 10.0), RiskManager(cfg), notifier=fake)
            for ev in sorted(data["events"], key=lambda e: e["ts"]):
                eng.handle_event(WalletEvent(ts=ev["ts"], wallet=ev["wallet"], side=ev["side"], mint=ev["mint"],
                                             sol_amount=ev["sol_amount"], token_amount=ev.get("token_amount")))
            eng.finish(max(max(p[0] for p in t["price_path"]) for t in data["tokens"].values()))
            self.assertTrue(any("ENTRÉE" in m for m in fake.msgs))
            self.assertTrue(any("SORTIE" in m for m in fake.msgs))


class InstanceLockTest(unittest.TestCase):
    def test_second_instance_is_refused_and_lock_is_released(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = str(Path(tmp) / "x.lock")
            a, b = InstanceLock(path), InstanceLock(path)
            self.assertTrue(a.acquire())
            self.assertFalse(b.acquire())                         # 2e instance : refusée
            a.release()
            self.assertTrue(b.acquire())                          # libre après libération
            b.release()


class ValidateSourcesTest(unittest.TestCase):
    """Schémas SUPPOSÉS (écrits de mémoire) : ces tests prouvent que le script de validation détecte une
    réponse conforme ou cassée ; seul un lancement chez toi prouve que les vrais services sont conformes."""
    GOOD_DEX = {"pairs": [{"chainId": "solana", "quoteToken": {"address": VS.WSOL}, "priceNative": "0.0001",
                           "priceUsd": "0.015", "liquidity": {"usd": 250000}, "pairCreatedAt": 1700000000000, "fdv": 1e9}]}

    def test_shape_never_leaks_values(self):
        sh = VS.shape({"apiKey": "SECRET", "n": 5, "items": [{"a": 1.5}]})
        self.assertNotIn("SECRET", json.dumps(sh))
        self.assertEqual(sh["apiKey"], "str")

    def test_dexscreener_good_missing_and_empty(self):
        self.assertEqual(VS.check_dexscreener(lambda u: self.GOOD_DEX, "M")[0], VS.OK)
        broken = json.loads(json.dumps(self.GOOD_DEX))
        del broken["pairs"][0]["liquidity"]
        st, msg, _ = VS.check_dexscreener(lambda u: broken, "M")
        self.assertEqual(st, VS.FAIL)
        self.assertIn("liquidity.usd", msg)
        self.assertEqual(VS.check_dexscreener(lambda u: {"pairs": []}, "M")[0], VS.FAIL)
        no_sol = {"pairs": [{"chainId": "solana", "quoteToken": {"address": "USDC"}}]}
        self.assertEqual(VS.check_dexscreener(lambda u: no_sol, "M")[0], VS.WARN)

        def boom(u):
            raise HttpError("HTTP 500")
        self.assertEqual(VS.check_dexscreener(boom, "M")[0], VS.FAIL)

    def test_rugcheck_good_and_changed_format(self):
        good = {"score": 10, "risks": [{"name": "x", "level": "warn"}, {"name": "y", "level": "danger"}]}
        st, msg, _ = VS.check_rugcheck(lambda u: good, "M")
        self.assertEqual(st, VS.OK)
        self.assertIn("danger", msg)
        self.assertEqual(VS.check_rugcheck(lambda u: {"detail": "new format"}, "M")[0], VS.FAIL)
        self.assertEqual(VS.check_rugcheck(lambda u: {"risks": [{"name": "x"}]}, "M")[0], VS.FAIL)

    def test_mint_and_jupiter_checks_with_patched_network(self):
        from bot.safety import SafetyChecker
        sc = SafetyChecker("http://rpc.invalid", jupiter_base="http://jup.invalid", jupiter_key="K")
        acct = {"result": {"value": {"data": {"parsed": {"info": {"mintAuthority": None, "freezeAuthority": None, "decimals": 5}}}}}}
        with mock.patch("bot.safety.post_json", return_value=acct):
            st, msg, _ = VS.check_mint(sc, "M")
            self.assertEqual(st, VS.OK)
            self.assertIn("décimales=5", msg)
        with mock.patch("bot.safety.post_json", side_effect=HttpError("down")):
            self.assertEqual(VS.check_mint(sc, "M")[0], VS.FAIL)
        quotes = iter([{"outAmount": "5000000000"}, {"outAmount": "95000000"}, {"outAmount": "95000000"}])
        with mock.patch("bot.safety.get_json", side_effect=lambda *a, **k: next(quotes)):
            st, msg, _ = VS.check_jupiter(sc, "M", 0.0001, 0.1)
            self.assertEqual(st, VS.OK)
        with mock.patch("bot.safety.get_json", side_effect=HttpError("HTTP 401 sur http://jup.invalid")):
            st, msg, _ = VS.check_jupiter(sc, "M", 0.0001, 0.1)
            self.assertEqual(st, VS.FAIL)
            self.assertIn("portal.jup.ag", msg)



class ReviewTest(unittest.TestCase):
    def test_classification_covers_all_four_outcomes(self):
        self.assertTrue(classify("enter", 45.0)[1].startswith("✅ bonne entrée"))
        self.assertTrue(classify("enter", -60.0)[1].startswith("❌ erreur"))
        self.assertTrue(classify("reject", -70.0)[1].startswith("✅ bon rejet"))
        self.assertTrue(classify("reject", 150.0)[1].startswith("⚠️ occasion manquée"))
        self.assertEqual(classify("enter", 5.0)[0], "stable")                 # sous le seuil des frais : neutre
        self.assertIn("non évalué", classify("enter", None)[1])
        self.assertIn("non évalué", classify("skip_risk", 80.0)[1])

    def test_review_joins_decisions_prices_and_realized_pnl(self):
        j = Journal()
        j.log_candidate(1000, "MA", "AAA", "enter", 80.0, [], {})
        j.log_watch("MA", 1000, "enter", [], 1.0, 10.0, -50.0)
        j.log_position(Position(id=1, mint="MA", symbol="AAA", open_ts=1000, entry_price=1.0, tokens_initial=1,
                                tokens_remaining=0, cost_sol=0.1, entry_liquidity_usd=1e5, wallets=[],
                                proceeds_sol=0.08, close_ts=2000, exit_reason="stop_loss", closed=True))
        j.log_candidate(1100, "MB", "BBB", "reject", 0.0, ["late_entry_drift"], {})
        j.log_watch("MB", 1100, "reject", ["late_entry_drift"], 1.0, 300.0, 900.0)
        j.log_candidate(1200, "MC", "CCC", "reject", 0.0, ["low_liquidity"], {})
        j.log_watch("MC", 1200, "reject", ["low_liquidity"], 1.0, -80.0, -95.0)
        rows = review(j, 6)
        by = {r["symbol"]: r for r in rows}
        self.assertTrue(by["AAA"]["verdict"].startswith("❌"))                 # entrée suivie d'une chute
        self.assertAlmostEqual(by["AAA"]["realized_pct"], -20.0, places=6)    # mais le stop a limité la perte
        self.assertEqual(by["AAA"]["exit"], "stop_loss")
        self.assertTrue(by["BBB"]["verdict"].startswith("⚠️"))
        self.assertTrue(by["CCC"]["verdict"].startswith("✅ bon rejet"))
        s = summarize(rows)
        self.assertEqual((s["erreur"], s["occasion_manquee"], s["bon_rejet"]), (1, 1, 1))
        # un rejet de SÉCURITÉ suivi d'une hausse n'est pas une occasion manquée (honeypot : irréalisable)
        j.log_candidate(1300, "MD", "DDD", "reject", 0.0, ["no_sell_route(honeypot?)"], {})
        j.log_watch("MD", 1300, "reject", ["no_sell_route(honeypot?)"], 1.0, 200.0, 500.0)
        j.log_candidate(1400, "ME", "EEE", "reject", 0.0, ["rugcheck_danger", "unknown:sell_impact"], {})
        j.log_watch("ME", 1400, "reject", ["rugcheck_danger"], 1.0, 80.0, 120.0)
        by2 = {r["symbol"]: r for r in review(j, 6)}
        self.assertTrue(by2["DDD"]["verdict"].startswith("🛡️"))
        self.assertTrue(by2["EEE"]["verdict"].startswith("🛡️"))
        s2 = summarize(list(by2.values()))
        self.assertEqual(s2["rejet_securite"], 2)
        self.assertEqual(s2["occasion_manquee"], 1)            # seul le rejet « late_entry_drift » reste une occasion manquée
        out = format_review(rows, 6)
        self.assertIn("REVUE DES DÉCISIONS", out)
        self.assertIn("Précision des entrées", out)
        self.assertEqual(len(review(j, 1)), 5)

    def test_empty_journal_gives_clear_message(self):
        self.assertIn("Aucune décision", format_review(review(Journal(), 6), 6))

    def test_scenario_flags_the_rug_as_an_error_despite_bounded_loss(self):
        with tempfile.TemporaryDirectory() as tmp:
            data, dp, wp = _scenario_files(tmp)
            eng, j, _ = run_replay(cfg_det(), dp, wp, ":memory:", verbose_report=False)
            by = {r["symbol"]: r for r in review(j, 6)}
            self.assertTrue(by["RUG"]["verdict"].startswith("❌"))
            self.assertEqual(by["RUG"]["exit"], "liquidity_collapse")
            self.assertGreater(by["RUG"]["realized_pct"], -101.0)



class SprayWalletTest(unittest.TestCase):
    def test_wallet_buying_everything_is_not_a_signal(self):
        with tempfile.TemporaryDirectory() as tmp:
            book = book_for(tmp, {"spray": "S", "x": "X", "y": "Y", "z": "Z"})
            det = ConvergenceDetector(load_config(), book)
            mk = lambda w, m, t: WalletEvent(ts=t, wallet=w, side="buy", mint=m, sol_amount=1, token_amount=100)
            for i in range(15):                                         # l'arroseur achète 15 tokens différents en 15 min
                det.on_buy(mk("spray", f"T{i}", i * 60))
            det.on_buy(mk("x", "M", 1000))
            det.on_buy(mk("spray", "M", 1010))
            self.assertIsNone(det.on_buy(mk("y", "M", 1020)))           # spray ignoré : seulement 2 wallets utiles
            self.assertIsNotNone(det.on_buy(mk("z", "M", 1030)))        # 3 wallets sélectifs : signal

    def test_selective_wallets_are_unaffected(self):
        with tempfile.TemporaryDirectory() as tmp:
            book = book_for(tmp, {"a": "A", "b": "B", "c": "C"})
            det = ConvergenceDetector(load_config(), book)
            mk = lambda w, t: WalletEvent(ts=t, wallet=w, side="buy", mint="M", sol_amount=1, token_amount=100)
            det.on_buy(mk("a", 0))
            det.on_buy(mk("b", 30))
            self.assertIsNotNone(det.on_buy(mk("c", 60)))

    def test_unknown_drift_fails_closed(self):
        self.assertIn("unknown:drift", apply_filters(None, good_info(), None, load_config()))


GOOD_REC = {"id": "r1", "maker": "WalletSM1", "side": "buy", "base_address": "MintAAA", "amount_usd": 300.0,
            "timestamp": 1_790_000_000, "price_usd": 0.00002}


class GmgnSourceTest(unittest.TestCase):
    """Schéma SUPPOSÉ d'après la documentation publique : prouve la cohérence de l'adaptateur, pas la conformité du vrai service."""
    def test_event_conversion_and_units(self):
        ev = to_event(GOOD_REC, sol_usd=150.0, now=5.0)
        self.assertEqual((ev.wallet, ev.side, ev.mint), ("WalletSM1", "buy", "MintAAA"))
        self.assertAlmostEqual(ev.sol_amount, 2.0)                        # 300 $ / 150 $ par SOL
        self.assertAlmostEqual(ev.price_sol, 0.00002 / 150.0, places=12)  # prix cohérent avec le prix USD
        self.assertEqual(ev.ts, 1_790_000_000)

    def test_rejects_unusable_records(self):
        self.assertIsNone(to_event({**GOOD_REC, "side": "swap"}, 150.0, 0))
        self.assertIsNone(to_event({**GOOD_REC, "amount_usd": "abc"}, 150.0, 0))
        self.assertIsNone(to_event({**GOOD_REC, "base_address": "So11111111111111111111111111111111111111112"}, 150.0, 0))
        self.assertIsNone(to_event(GOOD_REC, sol_usd=0, now=0))
        no_price = to_event({k: v for k, v in GOOD_REC.items() if k != "price_usd"}, 150.0, 0)
        self.assertIsNone(no_price.token_amount)                          # prix inconnu : la dérive sera « inconnue » (rejet)

    def test_extract_records_handles_envelopes(self):
        self.assertEqual(extract_records([GOOD_REC]), [GOOD_REC])
        self.assertEqual(extract_records({"code": 0, "data": {"list": [GOOD_REC]}}), [GOOD_REC])
        self.assertEqual(extract_records({"data": "nothing"}), [])

    def test_timestamp_formats(self):
        self.assertEqual(parse_ts(1_790_000_000), 1_790_000_000)
        self.assertEqual(parse_ts(1_790_000_000_000), 1_790_000_000)       # millisecondes
        self.assertAlmostEqual(parse_ts("2026-10-12T10:00:00Z"), 1_791_799_200.0, places=0)
        self.assertIsNone(parse_ts("pas une date"))

    def test_poll_dedupes_registers_wallets_and_respects_interval(self):
        with tempfile.TemporaryDirectory() as tmp:
            book = book_for(tmp, {})
            clock = [100.0]
            calls = []
            def runner(args):
                calls.append(args)
                return {"data": {"list": [GOOD_REC, {**GOOD_REC, "id": "r2", "maker": "WalletSM2"}]}}
            src = GmgnSource(book, load_config(), lambda: 150.0, runner=runner, now_fn=lambda: clock[0],
                             commands=[["track", "smartmoney", "--raw"]])
            ev1 = src.poll()
            self.assertEqual(len(ev1), 2)
            self.assertIn("WalletSM1", book.active())                         # wallet enregistré dynamiquement
            self.assertEqual(src.poll(), [])                                  # intervalle non écoulé : aucun appel
            self.assertEqual(len(calls), 1)
            clock[0] += 60
            self.assertEqual(src.poll(), [])                                  # mêmes ids : dédupliqués
            self.assertEqual(len(calls), 2)

    def test_failure_marks_source_degraded_without_crashing(self):
        HEALTH.reset()
        HEALTH.threshold = 2
        try:
            with tempfile.TemporaryDirectory() as tmp:
                def boom(args):
                    raise RuntimeError("gmgn-cli introuvable")
                clock = [0.0]
                src = GmgnSource(book_for(tmp, {}), load_config(), lambda: 150.0, runner=boom, now_fn=lambda: clock[0],
                                 commands=[["track", "smartmoney"]])
                for _ in range(2):
                    clock[0] += 100
                    self.assertEqual(src.poll(), [])
                self.assertEqual(HEALTH.degraded(), ["gmgn"])
        finally:
            HEALTH.reset()
            HEALTH.threshold = 5

    def test_dynamic_wallets_survive_reload_and_feed_convergence(self):
        with tempfile.TemporaryDirectory() as tmp:
            book = book_for(tmp, {})
            recs = [{**GOOD_REC, "id": f"r{i}", "maker": f"W{i}", "timestamp": 1_790_000_000 + i * 20} for i in range(3)]
            src = GmgnSource(book, load_config(), lambda: 150.0, runner=lambda a: recs, now_fn=lambda: 0.0,
                             commands=[["track", "smartmoney"]])
            events = src.poll()
            book.reload()                                                      # relecture de wallets.txt : GMGN conservés
            self.assertEqual(book.active(), {"W0", "W1", "W2"})
            det = ConvergenceDetector(load_config(), book)
            sigs = [det.on_buy(e) for e in events]
            self.assertIsNone(sigs[0])
            self.assertIsNone(sigs[1])
            self.assertIsNotNone(sigs[2])                                      # 3 wallets distincts sur le même token


class ValidateGmgnTest(unittest.TestCase):
    def test_good_missing_price_empty_and_error(self):
        good = lambda a: {"data": {"list": [GOOD_REC]}}
        self.assertEqual(VS.check_gmgn(good)[0], VS.OK)
        no_price = lambda a: [{k: v for k, v in GOOD_REC.items() if k != "price_usd"}]
        st, msg, _ = VS.check_gmgn(no_price)
        self.assertEqual(st, VS.WARN)
        self.assertIn("rejetterait tout", msg)
        self.assertEqual(VS.check_gmgn(lambda a: {"data": []})[0], VS.FAIL)
        no_core = lambda a: [{"maker": "w", "base_address": "m"}]
        self.assertEqual(VS.check_gmgn(no_core)[0], VS.FAIL)

        def err(a):
            raise RuntimeError("gmgn-cli code 1")
        self.assertEqual(VS.check_gmgn(err)[0], VS.FAIL)



ROOT = Path(__file__).resolve().parent.parent


class NoRealTradingGuardTest(unittest.TestCase):
    """PHASE DE TEST : aucun code ne doit créer, signer ni envoyer de transaction réelle, ni manipuler une clé privée."""
    FORBIDDEN = _re.compile(r"(private[_ ]?key|secret[_ ]?key|keypair|sign_?transaction|send_?(raw_)?transaction|"
                            r"sendRawTransaction|from_secret|mnemonic|seed phrase|getenv\(\s*[\"'][A-Z_]*(PRIVATE|SECRET|MNEMONIC|SEED))",
                            _re.IGNORECASE)

    def test_source_code_contains_no_signing_or_key_handling(self):
        files = list((ROOT / "bot").rglob("*.py")) + [ROOT / "main.py", ROOT / "validate_sources.py", ROOT / "j7_sync.py"] \
            + list((ROOT / "tools").rglob("*.py"))
        offenders = [f"{f.relative_to(ROOT)}: {m.group(0)}" for f in files
                     for m in self.FORBIDDEN.finditer(f.read_text(encoding="utf-8"))]
        self.assertEqual(offenders, [], "code interdit pendant la phase de test")

    def test_live_executor_cannot_be_built_or_used(self):
        with self.assertRaises(LiveTradingDisabled):
            JupiterExecutor()
        with self.assertRaises(LiveTradingDisabled):
            make_executor(load_config(), None, mode="live")
        stub = object.__new__(JupiterExecutor)                     # même en contournant le constructeur
        for call in (lambda: stub.buy("M", "M", 0.1, 0, []), lambda: stub.sell(None, 1.0, 0),
                     lambda: stub.equity(0, [])):
            with self.assertRaises(LiveTradingDisabled):
                call()

    def test_both_executors_share_the_single_interface(self):
        self.assertTrue(issubclass(PaperExecutor, Executor))
        self.assertTrue(issubclass(JupiterExecutor, Executor))
        self.assertEqual(make_executor(load_config(), ReplayMarket({"tokens": {}}, validate=False)).mode, "paper")

    def test_engine_runs_on_any_executor_implementing_the_interface(self):
        class Fake(Executor):
            mode = "fake"
            def __init__(self): self.cash, self.bought = 10.0, []
            def buy(self, mint, symbol, amount_sol, ts, wallets):
                self.bought.append(amount_sol)
                self.cash -= amount_sol
                return Position(id=self._next_id, mint=mint, symbol=symbol, open_ts=ts, entry_price=1.0, tokens_initial=1,
                                tokens_remaining=1, cost_sol=amount_sol, entry_liquidity_usd=1e5, wallets=wallets), "ok"
            def sell(self, pos, fraction, ts): return False, 0.0, None
            def equity(self, ts, positions): return self.cash + sum(p.cost_sol for p in positions)
        with tempfile.TemporaryDirectory() as tmp:
            data, dp, wp = _scenario_files(tmp)
            cfg, fake = cfg_det(), Fake()
            market = ReplayMarket(data)
            j = Journal()
            eng = Engine(cfg, market, WalletBook(wp, enforce_j7_freshness=False, journal=j), j, fake, RiskManager(cfg))
            for ev in sorted(data["events"], key=lambda e: e["ts"])[:12]:
                eng.handle_event(WalletEvent(ts=ev["ts"], wallet=ev["wallet"], side=ev["side"], mint=ev["mint"],
                                             sol_amount=ev["sol_amount"], token_amount=ev.get("token_amount")))
            self.assertTrue(fake.bought)                              # la décision est indépendante du mode d'exécution
            eng.save_state()
            self.assertEqual(j.kv_get("engine_state")["cash"], fake.cash)


class DynamicSizingTest(unittest.TestCase):
    def cfg(self, start=200.0):
        c = load_config()
        c["capital"]["start_sol"] = start
        return c

    def size(self, c, score=80, eff=3.0, liq=200000, equity=200.0, expo=0.0, **kw):
        return dynamic_size(c, equity, score, eff, liq, 150.0, expo, **kw)

    def test_stronger_signal_means_bigger_position_never_above_cap(self):
        c = self.cfg()
        sizes = [self.size(c, score=sc, eff=5.0)[0] for sc in (62, 70, 80, 90, 100)]
        self.assertEqual(sizes, sorted(sizes))
        self.assertLess(sizes[0], sizes[-1])
        cap = 200.0 * c.risk.max_position_pct / 100
        self.assertTrue(all(0 < x <= cap + 1e-9 for x in sizes))      # le plafond par position tient toujours

    def test_more_independent_wallets_increase_size_but_discovery_only_is_smaller(self):
        c = self.cfg()
        self.assertGreater(self.size(c, eff=5.0)[0], self.size(c, eff=3.0)[0])
        self.assertLess(self.size(c, eff=0.0)[0], self.size(c, eff=3.0)[0])      # sans wallets : taille réduite
        self.assertEqual(concordance(0.0, 3, 0.7), 0.7)

    def test_context_only_ever_shrinks_the_position(self):
        self.assertEqual(context_factor(0.0, 0, 0.0, 3.0), 1.0)
        self.assertLess(context_factor(-2.0, 0, 0.0, 3.0), 1.0)
        stacked = context_factor(-2.0, 3, 8.0, 3.0)                       # perte du jour + pertes consécutives + drawdown
        self.assertLess(stacked, context_factor(-2.0, 0, 0.0, 3.0))       # les causes se cumulent
        self.assertGreaterEqual(stacked, 0.25)                            # mais il reste un plancher
        self.assertLessEqual(context_factor(5.0, 0, 0.0, 3.0), 1.0)      # des gains ne font JAMAIS grossir la mise
        c = self.cfg()
        calm, bad = self.size(c)[0], self.size(c, day_pnl_pct=-2.0, consec_losses=3, drawdown_pct=9.0)[0]
        self.assertLess(bad, calm)

    def test_exit_liquidity_and_pool_share_limit_the_size(self):
        c = self.cfg()
        size, why, d = self.size(c, liq=30000, eff=5.0)               # pool de 200 SOL
        self.assertEqual(why, "ok")
        self.assertIn(d.get("limited_by"), ("liquidity_share", "exit_impact"))
        impact_pct = 2 * size * 150 / 30000 * 100
        self.assertLessEqual(impact_pct, c.filters.max_sell_impact_pct + 1e-6)   # impact de sortie vérifié AVANT l'entrée

    def test_small_account_is_floored_at_cost_minimum_or_refused(self):
        c = self.cfg(10.0)
        s1, why1, d1 = self.size(c, equity=10.0)
        s2, why2, d2 = self.size(c, equity=10.0, score=100, eff=5.0)
        self.assertEqual((why1, why2), ("ok", "ok"))
        self.assertTrue(d1.get("raised_to_cost_floor"))
        self.assertAlmostEqual(s1, d1["min_size_for_costs"], places=6)
        tiny, why, _ = self.size(self.cfg(1.0), equity=1.0)           # compte d'~1 SOL : impossible
        self.assertEqual(tiny, 0.0)
        self.assertIn(why, ("size_too_small_for_costs", "size_too_small", "costs_exceed_cap_at_any_size"))

    def test_exposure_room_caps_the_size(self):
        c = self.cfg()
        total = 200.0 * c.risk.max_total_exposure_pct / 100                # 20 SOL d'exposition maximale
        size, why, d = self.size(c, expo=total - 0.2, eff=5.0, score=100)
        self.assertEqual(why, "ok")
        self.assertLessEqual(size, 0.2 + 1e-9)                             # il ne reste que 0,2 SOL de marge
        self.assertEqual(d.get("limited_by"), "exposure_room")
        size0, why0, _ = self.size(c, expo=total, score=100)               # plus aucune marge : refus
        self.assertEqual((size0, why0), (0.0, "size_too_small_for_costs"))

    def test_risk_manager_uses_dynamic_size_and_logs_details(self):
        c = self.cfg()
        r = RiskManager(c)
        ok, why, size = r.check_entry(0, 200.0, [], 200000, 150, score=90, eff_weight=5.0)
        self.assertTrue(ok)
        self.assertEqual(r.last_sizing["size_sol"], round(size, 6))
        self.assertIn("strength", r.last_sizing)

    def test_signal_strength_bounds(self):
        self.assertAlmostEqual(signal_strength(60, 60, 0.3), 0.3)
        self.assertAlmostEqual(signal_strength(100, 60, 0.3), 1.0)
        self.assertAlmostEqual(signal_strength(40, 60, 0.3), 0.3)       # sous le seuil : plancher, jamais négatif


class DiscoverySourceTest(unittest.TestCase):
    REAL = json.loads((ROOT / "tests" / "fixtures" / "dexscreener_boosts_real_sample.json").read_text())

    def test_parser_on_real_feed_sample_keeps_only_solana_and_merges_duplicates(self):
        out = {c["mint"]: c for c in parse_discovery(self.REAL, "boost")}
        self.assertEqual(len(out), 5)                                        # 9 entrées : 4 hors Solana / doublon
        self.assertNotIn("0xd5D49D68a555f3C50cCDa9BD9a8691692E5ce172", out)  # robinhood écarté
        grok = out["4qH8A5GxvRMZgpRFjXASc6U9HAoEzKeUqxY2dPB7pump"]
        self.assertEqual(grok["boost_amount"], 40)                           # 30 + 10, comme totalAmount réel
        self.assertTrue(grok["has_twitter"])
        self.assertFalse(out["2ipd4etMC4NfcASg3FQdq5xKkZWrCXvBJd8D1nAFpump"]["has_twitter"])

    def test_parser_is_robust_to_garbage(self):
        self.assertEqual(parse_discovery({"error": "x"}, "boost"), [])
        self.assertEqual(parse_discovery([None, 5, {"chainId": "solana"}], "boost"), [])

    def test_client_merges_both_feeds_and_picks_best_pair(self):
        calls = []
        def fake_get(url, **kw):
            calls.append(url)
            if "profiles" in url:
                return [{"chainId": "solana", "tokenAddress": "MintA", "links": []}]
            if "boosts" in url:
                return [{"chainId": "solana", "tokenAddress": "MintA", "amount": 30, "links": [{"type": "twitter"}]},
                        {"chainId": "solana", "tokenAddress": "MintB", "amount": 10}]
            return [{"chainId": "solana", "quoteToken": {"address": VS.WSOL}, "priceNative": "0.001", "liquidity": {"usd": 10}},
                    {"chainId": "solana", "quoteToken": {"address": VS.WSOL}, "priceNative": "0.002", "liquidity": {"usd": 90}},
                    {"chainId": "solana", "quoteToken": {"address": "USDC"}, "priceNative": "9", "liquidity": {"usd": 999}}]
        cl = DexClient(get=fake_get, pairs_rps=1000)
        disc = {c["mint"]: c for c in cl.discovery()}
        self.assertEqual(disc["MintA"]["source"], "profile+boost")
        self.assertEqual(disc["MintA"]["boost_amount"], 30)
        self.assertEqual(set(disc), {"MintA", "MintB"})
        self.assertEqual(cl.pairs("MintA")["priceNative"], "0.002")          # la plus liquide, cotée en SOL
        self.assertIsNone(best_sol_pair({"pairs": []}))
        self.assertEqual(best_sol_pair({"pairs": [{"chainId": "solana", "quoteToken": {"address": VS.WSOL}}]})["chainId"], "solana")

    def test_pair_fields_units(self):
        f = pair_fields({"baseToken": {"symbol": "AAA"}, "priceNative": "0.0002", "priceUsd": "0.03",
                         "liquidity": {"usd": 50000}, "fdv": 1e6, "pairCreatedAt": 1_000_000 * 1000,
                         "volume": {"h1": 12000}, "txns": {"h1": {"buys": 60, "sells": 30}},
                         "priceChange": {"h1": 12.5, "m5": -1}}, now=1_000_000 + 1800)
        self.assertEqual(f["symbol"], "AAA")
        self.assertAlmostEqual(f["sol_usd"], 150.0)
        self.assertAlmostEqual(f["pair_age_min"], 30.0)
        self.assertEqual((f["buys_h1"], f["sells_h1"], f["volume_h1_usd"]), (60, 30, 12000.0))
        self.assertIsNone(pair_fields({})["price_sol"])                        # absent = inconnu, jamais 0


def _scout_data(now):
    def token(created_min_ago, **kw):
        t = {"symbol": "T", "price_path": [[now - 86400 + i * 60, 0.001 * (1 + 0.0001 * i)] for i in range(0, 1500)],
             "liquidity_usd": 150000, "fdv_usd": 2_000_000, "pair_created_ts": now - created_min_ago * 60,
             "mint_authority_active": False, "freeze_authority_active": False, "rugcheck_levels": ["info"],
             "sell_quote_ok": True}
        t.update(kw)
        return t
    return {"sol_usd": 150.0, "tokens": {"GOOD": token(120), "HONEY": token(120, sell_quote_ok=False),
                                         "NEWBORN": token(3)}}


class ScoutLoopTest(unittest.TestCase):
    def build(self, tmp, now, start=200.0):
        cfg = cfg_det()
        cfg["capital"]["start_sol"] = start
        data = _scout_data(now)
        market = ReplayMarket(data)
        j = Journal()
        clock = [now]
        jl = JsonlLog(str(Path(tmp) / "decisions.jsonl"))
        eng = Engine(cfg, market, WalletBook(Path(tmp) / "none.txt", enforce_j7_freshness=False), j,
                     PaperExecutor(cfg, market, start), RiskManager(cfg), now_fn=lambda: clock[0], jsonl=jl)

        class FakeDex:
            def __init__(self): self.feed = []
            def discovery(self): return list(self.feed)
        dex = FakeDex()
        return Scout(cfg, eng, dex, j, now_fn=lambda: clock[0]), eng, dex, clock, j, jl

    def test_discovery_decisions_are_logged_and_each_token_seen_once(self):
        now = 1_790_000_000.0
        with tempfile.TemporaryDirectory() as tmp:
            scout, eng, dex, clock, j, jl = self.build(tmp, now)
            dex.feed = [{"mint": "GOOD", "source": "boost", "boost_amount": 30},
                        {"mint": "HONEY", "source": "profile", "boost_amount": 0}]
            self.assertEqual(scout.tick(), 2)
            dec = {r[0]: (r[1], json.loads(r[2])) for r in j.c.execute("SELECT mint,decision,reasons FROM candidates")}
            self.assertEqual(dec["GOOD"][0], "enter")
            self.assertEqual(dec["HONEY"][0], "reject")
            self.assertIn("no_sell_route(honeypot?)", dec["HONEY"][1])
            clock[0] += 120
            self.assertEqual(scout.tick(), 0)                                 # déjà vus : pas de ré-évaluation
            lines = [json.loads(x) for x in (Path(tmp) / "decisions.jsonl").read_text().splitlines()]
            enter = [x for x in lines if x["type"] == "decision" and x["decision"] == "enter"][0]
            self.assertEqual(enter["source"], "discovery:boost")
            self.assertIn("iso", enter)
            self.assertGreater(enter["size_sol"], 0)
            self.assertIn("strength", enter["sizing"])
            self.assertEqual(eng.positions[0].equity_at_entry, 200.0)

    def test_discovery_signal_uses_reduced_size_without_wallets(self):
        now = 1_790_000_000.0
        with tempfile.TemporaryDirectory() as tmp:
            scout, eng, dex, clock, j, jl = self.build(tmp, now)
            dex.feed = [{"mint": "GOOD", "source": "boost", "boost_amount": 30}]
            scout.tick()
            d = json.loads(j.c.execute("SELECT detail FROM candidates WHERE decision='enter'").fetchone()[0])["sizing"]
            self.assertEqual(d["concordance"], load_config().sizing.no_wallet_factor)

    def test_too_new_token_is_retried_once_later(self):
        now = 1_790_000_000.0
        with tempfile.TemporaryDirectory() as tmp:
            scout, eng, dex, clock, j, jl = self.build(tmp, now)
            dex.feed = [{"mint": "NEWBORN", "source": "profile", "boost_amount": 0}]
            scout.tick()
            self.assertEqual(j.c.execute("SELECT decision FROM candidates").fetchone()[0], "reject")
            clock[0] += 11 * 60
            scout.tick()
            decisions = [r[0] for r in j.c.execute("SELECT decision FROM candidates ORDER BY id")]
            self.assertEqual(decisions, ["reject", "enter"])                  # réexaminé après 10 min : désormais assez âgé

    def test_exit_is_written_to_jsonl_with_prices_and_reason(self):
        now = 1_790_000_000.0
        with tempfile.TemporaryDirectory() as tmp:
            scout, eng, dex, clock, j, jl = self.build(tmp, now)
            dex.feed = [{"mint": "GOOD", "source": "boost", "boost_amount": 30}]
            scout.tick()
            pos = eng.positions[0]
            t = eng.market.tokens["GOOD"]
            t["price_path"] = t["price_path"][:1450] + [[now + 60 * k, pos.entry_price * 0.5] for k in range(1, 400)]
            eng.market._ts["GOOD"] = [p[0] for p in t["price_path"]]
            eng.advance_to(now + 3600)
            lines = [json.loads(x) for x in (Path(tmp) / "decisions.jsonl").read_text().splitlines()]
            ex = [x for x in lines if x["type"] == "exit"]
            self.assertEqual(len(ex), 1)
            self.assertEqual(ex[0]["reason"], "stop_loss")
            self.assertAlmostEqual(ex[0]["entry_price"], pos.entry_price)
            self.assertLess(ex[0]["exit_price"], ex[0]["entry_price"])
            self.assertLess(ex[0]["pnl_pct"], 0)


class OptionalSourcesTest(unittest.TestCase):
    def test_pumpportal_message_parsing(self):
        ev = parse_trade({"txType": "buy", "mint": "M", "traderPublicKey": "W", "solAmount": 1.5, "tokenAmount": 3000,
                          "signature": "sig"}, now=77.0)
        self.assertEqual((ev.wallet, ev.side, ev.mint, ev.ts), ("W", "buy", "M", 77.0))
        self.assertAlmostEqual(ev.price_sol, 1.5 / 3000)
        self.assertIsNone(parse_trade({"message": "Successfully subscribed"}, 0))
        self.assertIsNone(parse_trade({"txType": "create", "mint": "M", "traderPublicKey": "W", "solAmount": 1}, 0))
        self.assertIsNone(parse_trade({"txType": "buy", "mint": "M", "traderPublicKey": "W", "solAmount": "x"}, 0))
        self.assertIsNone(parse_trade("not a dict", 0))

    def test_pumpportal_subscription_and_queue_with_fake_socket(self):
        import asyncio
        class FakeWS:
            def __init__(self, msgs): self.sent, self._m = [], msgs
            async def send(self, x): self.sent.append(json.loads(x))
            def __aiter__(self):
                async def gen():
                    for m in self._m:
                        yield m
                return gen()
        msgs = [json.dumps({"message": "ok"}), "pas du json",
                json.dumps({"txType": "sell", "mint": "M", "traderPublicKey": "W", "solAmount": 2, "tokenAmount": 10})]
        src = PumpPortalSource(["W1", "W2"], now_fn=lambda: 5.0)
        ws = FakeWS(msgs)
        asyncio.run(src._consume(ws))
        self.assertEqual(ws.sent[0], {"method": "subscribeAccountTrade", "keys": ["W1", "W2"]})
        got = src.poll()
        self.assertEqual([e.side for e in got], ["sell"])
        self.assertEqual(src.poll(), [])
        self.assertFalse(PumpPortalSource([], connect=lambda u: None).start())      # rien à suivre : non démarré

    def test_geckoterminal_ohlcv_parsing(self):
        payload = {"data": {"attributes": {"ohlcv_list": [[1700000120, 2, 3, 1, 2.5, 100], [1700000060, 1, 2, 0.5, 2, 90]]}}}
        c = GT.parse_ohlcv(payload)
        self.assertEqual([x[0] for x in c], [1700000060, 1700000120])         # tri chronologique
        self.assertEqual(c[0][1:5], (1.0, 2.0, 0.5, 2.0))
        self.assertEqual(GT.parse_ohlcv({"data": {}}), [])
        self.assertEqual(GT.parse_ohlcv(None), [])
        GT._limiter.min_interval = 0
        got = GT.fetch_ohlcv("POOL", get=lambda url, params=None: payload)
        self.assertEqual(len(got), 2)


class OhlcvReplayToolTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        sys.path.insert(0, str(ROOT / "tools"))
        import replay_ohlcv
        cls.R = replay_ohlcv

    def candles(self, closes, wick=0.0):
        t0 = 1_790_000_000
        out = []
        for i, c in enumerate(closes):
            o = closes[i - 1] if i else c
            out.append((t0 + 60 * i, o, max(o, c) * (1 + wick), min(o, c) * (1 - wick), c, 1000.0))
        return out

    def test_steady_decline_hits_stop_loss(self):
        cfg = load_config()
        res = self.R.replay(self.candles([1.0 - 0.01 * i for i in range(40)]), cfg, entry_index=2)
        self.assertEqual(res["exit_reason"], "stop_loss")
        self.assertLess(res["pnl_pct"], 0)

    def test_worst_case_wick_triggers_stop_even_if_close_recovers(self):
        cfg = load_config()
        flat = [1.0] * 10
        c = self.candles(flat + [1.0] + [1.0] * 5)
        ts, o, h, l, cl, v = c[8]
        c[8] = (ts, o, 1.02, 0.60, cl, v)                    # grosse mèche basse, clôture inchangée
        res = self.R.replay(c, cfg, entry_index=2)
        self.assertEqual(res["exit_reason"], "stop_loss")   # ordre pessimiste : le plus bas avant le plus haut

    def test_big_run_is_exited_by_a_protective_rule_with_gain(self):
        cfg = load_config()
        path = [1.0] * 5 + [1.0 + 0.1 * i for i in range(1, 25)] + [3.0 - 0.15 * i for i in range(1, 15)]
        res = self.R.replay(self.candles(path), cfg, entry_index=3)
        self.assertTrue(res["closed"])
        self.assertIn(res["exit_reason"], ("trailing_stop", "breakeven_stop"))
        self.assertGreater(res["peak_vs_entry_pct"], 100)


class RugcheckReportAndLiveMarketTest(unittest.TestCase):
    GOOD = {"score": 10, "rugged": False, "token": {"mintAuthority": None, "freezeAuthority": None},
            "topHolders": [{"pct": 12.0}, {"pct": 8.0}, {"pct": 5.0}],
            "risks": [{"name": "Low liquidity", "level": "warn"}]}

    def test_report_parsing_good_changed_and_failing(self):
        sc = SafetyChecker(mode="rugcheck_only")
        with mock.patch("bot.safety.get_json", return_value=self.GOOD):
            r = sc.rugcheck_report("M")
        self.assertEqual((r["mint_authority_active"], r["freeze_authority_active"]), (False, False))
        self.assertAlmostEqual(r["top10_pct"], 25.0)
        self.assertEqual(r["levels"], ["warn"])
        active = json.loads(json.dumps(self.GOOD))
        active["token"]["mintAuthority"] = "SomeAuthority"
        with mock.patch("bot.safety.get_json", return_value=active):
            self.assertTrue(SafetyChecker(mode="rugcheck_only").rugcheck_report("M2")["mint_authority_active"])
        with mock.patch("bot.safety.get_json", return_value={"detail": "changé"}):
            self.assertIsNone(SafetyChecker(mode="rugcheck_only").rugcheck_report("M3"))      # format changé : inconnu
        with mock.patch("bot.safety.get_json", side_effect=HttpError("500")):
            self.assertIsNone(SafetyChecker(mode="rugcheck_only").rugcheck_report("M4"))

    def test_rugcheck_only_mode_fills_info_and_never_touches_rpc_or_jupiter(self):
        sc = SafetyChecker(mode="rugcheck_only")
        info = good_info(mint="M5", rugcheck_levels=None, mint_authority_active=None, freeze_authority_active=None,
                         sell_quote_ok=None, sell_impact_pct=None)
        with mock.patch("bot.safety.get_json", return_value=self.GOOD), \
                mock.patch("bot.safety.post_json", side_effect=AssertionError("RPC interdit en mode rugcheck_only")):
            sc.fill(info, 0.1)
        self.assertEqual((info.mint_authority_active, info.sell_quote_ok), (False, True))
        danger = json.loads(json.dumps(self.GOOD))
        danger["risks"].append({"name": "Honeypot", "level": "danger"})
        with mock.patch("bot.safety.get_json", return_value=danger):
            i2 = good_info(mint="M6", sell_quote_ok=None)
            SafetyChecker(mode="rugcheck_only").fill(i2, 0.1)
        self.assertFalse(i2.sell_quote_ok)

    def test_live_market_info_fills_momentum_and_models_exit_impact(self):
        pair = {"chainId": "solana", "quoteToken": {"address": VS.WSOL}, "baseToken": {"symbol": "AAA"},
                "priceNative": "0.001", "priceUsd": "0.15", "liquidity": {"usd": 30000}, "fdv": 1e6,
                "pairCreatedAt": (__import__("time").time() - 3600) * 1000, "volume": {"h1": 20000},
                "txns": {"h1": {"buys": 80, "sells": 40}}, "priceChange": {"h1": 30.0, "m5": 2.0}}
        class FakeClient:
            def pairs(self, mint): return pair
        class FakeSafety:
            def fill(self, info, size): info.rugcheck_levels = ["info"]
        lm = LiveMarket(FakeSafety(), client=FakeClient(), model_exit=True)
        info = lm.info("M", __import__("time").time(), 0.5)
        self.assertEqual((info.symbol, info.buys_h1, info.sells_h1), ("AAA", 80, 40))
        self.assertAlmostEqual(info.sell_impact_pct, 2 * 0.5 * 150 / 30000 * 100, places=6)
        self.assertAlmostEqual(lm.sol_usd, 150.0)


class MomentumScoringTest(unittest.TestCase):
    def test_score_is_normalised_to_what_is_measurable(self):
        c = load_config()
        no_wallet = Signal("M", 0, 1.0, 0, [], 0, 0.0, 0)
        s_no_mom = score_candidate(no_wallet, good_info(liquidity_usd=200000), 0.0, c)
        self.assertLessEqual(s_no_mom[0], 100.0)
        self.assertEqual(s_no_mom[1]["convergence"], 0.0)
        self.assertGreater(s_no_mom[0], 80.0)               # sans wallets ni volume, un token propre n'est pas pénalisé à tort

    def test_buy_pressure_and_volume_raise_the_score(self):
        c = load_config()
        sig = Signal("M", 0, 1.0, 0, [], 0, 0.0, 0)
        weak = good_info(liquidity_usd=50000, volume_h1_usd=1000, buys_h1=20, sells_h1=60, price_change_h1_pct=300.0)
        strong = good_info(liquidity_usd=50000, volume_h1_usd=60000, buys_h1=90, sells_h1=30, price_change_h1_pct=20.0)
        self.assertGreater(score_candidate(sig, strong, 0.0, c)[0], score_candidate(sig, weak, 0.0, c)[0] + 15)


class ReportSectionsTest(unittest.TestCase):
    def test_report_shows_refused_tokens_and_size_distribution(self):
        with tempfile.TemporaryDirectory() as tmp:
            data, dp, wp = _scenario_files(tmp)
            cfg = cfg_det()
            cfg["capital"]["start_sol"] = 200.0
            eng, j, report = run_replay(cfg, dp, wp, ":memory:", verbose_report=False)
            self.assertIn("Derniers tokens REFUSÉS", report)
            self.assertIn("DISTRIBUTION DES TAILLES", report)
            self.assertIn("honeypot", report)
            sizes = [r[0] for r in j.c.execute("SELECT size_pct FROM positions WHERE size_pct IS NOT NULL")]
            self.assertTrue(sizes and all(0 < x <= cfg.risk.max_position_pct + 1e-9 for x in sizes))



class ValidateNewRoutesTest(unittest.TestCase):
    REAL = json.loads((ROOT / "tests" / "fixtures" / "dexscreener_boosts_real_sample.json").read_text())
    PAIR = {"chainId": "solana", "pairAddress": "POOL1", "quoteToken": {"address": VS.WSOL}, "baseToken": {"symbol": "A"},
            "priceNative": "0.001", "priceUsd": "0.15", "liquidity": {"usd": 40000}, "fdv": 1e6, "pairCreatedAt": 1_700_000_000_000,
            "volume": {"h1": 9000}, "txns": {"h1": {"buys": 50, "sells": 20}}, "priceChange": {"h1": 5, "m5": 1}}

    def test_discovery_check_on_real_format(self):
        st, msg, shapes, mint = VS.check_dex_discovery(lambda u: self.REAL)
        self.assertEqual(st, VS.OK)
        self.assertIn("5 token(s) Solana", msg.replace("5 token(s) Solana distincts", "5 token(s) Solana"))
        self.assertTrue(mint)
        self.assertEqual(VS.check_dex_discovery(lambda u: [])[0], VS.WARN)

        def boom(u):
            raise HttpError("HTTP 500")
        self.assertEqual(VS.check_dex_discovery(boom)[0], VS.FAIL)

    def test_pairs_check_ok_missing_fields_and_no_sol_pair(self):
        st, msg, sh, pool = VS.check_dex_pairs(lambda u: [self.PAIR], "M")
        self.assertEqual((st, pool), (VS.OK, "POOL1"))
        no_mom = {k: v for k, v in self.PAIR.items() if k not in ("volume", "txns")}
        self.assertEqual(VS.check_dex_pairs(lambda u: [no_mom], "M")[0], VS.WARN)
        no_price = {k: v for k, v in self.PAIR.items() if k != "priceNative"}
        self.assertEqual(VS.check_dex_pairs(lambda u: [no_price], "M")[0], VS.FAIL)
        self.assertEqual(VS.check_dex_pairs(lambda u: [], "M")[0], VS.WARN)

    def test_rugcheck_report_check(self):
        good = {"risks": [], "token": {"mintAuthority": None, "freezeAuthority": None}, "topHolders": [{"pct": 3.0}]}
        self.assertEqual(VS.check_rugcheck_report(lambda u: good, "M")[0], VS.OK)
        self.assertEqual(VS.check_rugcheck_report(lambda u: {"risks": [], "token": {}}, "M")[0], VS.WARN)
        self.assertEqual(VS.check_rugcheck_report(lambda u: {"nope": 1}, "M")[0], VS.FAIL)

    def test_gecko_check(self):
        payload = {"data": {"attributes": {"ohlcv_list": [[1700000060, 1, 2, 0.5, 2, 90]]}}}
        self.assertEqual(VS.check_gecko_ohlcv(lambda url, params=None: payload, "POOL")[0], VS.OK)
        self.assertEqual(VS.check_gecko_ohlcv(lambda url, params=None: {}, "POOL")[0], VS.WARN)


if __name__ == "__main__":
    unittest.main(verbosity=2)
