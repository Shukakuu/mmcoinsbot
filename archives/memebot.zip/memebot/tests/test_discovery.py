"""Tests du module de découverte automatique de wallets (tout est hors-ligne : fausse blockchain, aucune requête réelle)."""
import contextlib
import io
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from bot.config import load_config                                   # noqa: E402
from bot.db import Journal                                           # noqa: E402
from bot.engine import Engine                                        # noqa: E402
from bot.execution.paper import PaperExecutor                        # noqa: E402
from bot.http import HttpError                                       # noqa: E402
from bot.market import ReplayMarket                                  # noqa: E402
from bot.models import Position, WalletEvent                         # noqa: E402
from bot.report import build_report                                  # noqa: E402
from bot.risk import RiskManager                                     # noqa: E402
from bot.scout import Scout                                          # noqa: E402
from bot.wallet_discovery import BudgetExceeded, ReadOnlyRpc, WalletDiscovery   # noqa: E402
from bot.wallet_scoring import Verdict, compute_metrics, score_wallet            # noqa: E402
from bot.wallets import WalletBook                                   # noqa: E402
from bot.wallets_registry import WalletRegistry                      # noqa: E402

NOW = 1_800_000_000.0
DAY = 86400.0


def cfg_fast():
    c = load_config()
    c["discovery"]["helius_rps"] = 100000
    c["discovery"]["public_rps"] = 100000
    return c


def ev(side, mint, sol, tokens, ts, wallet="W"):
    return WalletEvent(ts=ts, wallet=wallet, side=side, mint=mint, sol_amount=sol, token_amount=tokens)


def round_trips(n, win_sell, loss_sell, wins, span_days, t0=NOW - 40 * DAY, start_idx=0):
    """n allers-retours sur n tokens distincts répartis sur span_days : `wins` gagnants (vente = win_sell SOL), le reste perdants."""
    out = []
    for i in range(n):
        t = t0 + i * (span_days * DAY / max(n, 1))
        out.append(ev("buy", f"T{start_idx + i}", 1.0, 1000.0, t))
        out.append(ev("sell", f"T{start_idx + i}", win_sell if i < wins else loss_sell, 1000.0, t + 3600))
    return out


def metrics(events, d, age=60.0, complete=True, creation=None):
    return compute_metrics(events, creation or {}, age, complete, d)


# ---------------------------------------------------------------------------------------- scoring
class WalletScoringTest(unittest.TestCase):
    d = load_config().discovery

    def test_regular_winner_is_eligible(self):
        m = metrics(round_trips(20, 1.6, 0.7, 14, 25), self.d)
        v = score_wallet(m, self.d)
        self.assertEqual(v.status, "eligible", (v.reason, v.score, m))
        self.assertGreaterEqual(v.score, self.d.min_score)
        self.assertEqual(m["n_closed"], 20)
        self.assertAlmostEqual(m["win_rate"], 0.7)
        self.assertAlmostEqual(m["realized_pnl_sol"], 14 * 0.6 - 6 * 0.3, places=6)
        self.assertLess(m["tokens_per_day"], 4)

    def test_sprayer_is_excluded(self):
        evs = []
        for i in range(40):                                   # 40 tokens différents en moins d'une journée
            t = NOW - 5 * DAY + i * 1200
            evs += [ev("buy", f"S{i}", 1.0, 1000.0, t), ev("sell", f"S{i}", 1.5, 1000.0, t + 300)]
        m = metrics(evs, self.d)
        v = score_wallet(m, self.d)
        self.assertGreater(m["tokens_per_day"], self.d.max_tokens_per_day)
        self.assertEqual((v.status, v.reason, v.score), ("excluded", "sprayer", 0.0))

    def test_sniper_dev_is_penalised_never_rewarded(self):
        evs = round_trips(10, 2.0, 2.0, 10, 20)                # gagnant à 100 % : un « super » wallet sur le papier
        creation = {f"T{i}": evs[2 * i].ts - 5 for i in range(10)}          # il achète 5 s après la création, à chaque fois
        m = metrics(evs, self.d, creation=creation)
        v = score_wallet(m, self.d)
        self.assertEqual(m["sniper_share"], 1.0)
        self.assertEqual(v.status, "excluded")
        self.assertEqual(v.reason, "sniper")
        clean = score_wallet(metrics(evs, self.d), self.d)      # même historique sans info de création : score sans pénalité
        self.assertLess(v.score, clean.score * 0.5)

    def test_too_young_wallet_is_excluded(self):
        v = score_wallet(metrics(round_trips(12, 1.6, 0.7, 9, 3, t0=NOW - 3 * DAY), self.d, age=3.0), self.d)
        self.assertEqual((v.status, v.reason, v.score), ("excluded", "too_young", None))

    def test_one_lucky_trade_does_not_make_a_good_wallet(self):
        evs = round_trips(10, 21.0, 0.8, 1, 20)                # 1 gain de +20 SOL, 9 petites pertes
        m = metrics(evs, self.d)
        v = score_wallet(m, self.d)
        self.assertGreater(m["realized_pnl_sol"], 15)
        self.assertEqual(v.components["regularity"], 0.0)       # tout le gain vient d'UN trade
        self.assertEqual(v.status, "excluded")

    def test_unknown_when_too_few_closed_trades_or_no_age(self):
        v = score_wallet(metrics(round_trips(3, 1.6, 0.7, 3, 10), self.d), self.d)
        self.assertEqual((v.status, v.reason, v.score), ("unknown", "too_few_closed_trades", None))
        self.assertEqual(score_wallet(metrics(round_trips(10, 1.6, 0.7, 7, 10), self.d, age=None), self.d).status, "unknown")

    def test_sells_without_a_known_buy_are_ignored_never_guessed(self):
        evs = [ev("sell", "X1", 5.0, 1000.0, NOW - DAY), ev("sell", "X2", 5.0, 1000.0, NOW - DAY + 10)]
        m = metrics(evs, self.d)
        self.assertEqual(m["unmatched_sells"], 2)
        self.assertEqual((m["realized_pnl_sol"], m["n_closed"]), (0.0, 0))

    def test_partial_sells_count_realised_pnl_but_not_a_closed_trade(self):
        evs = [ev("buy", "P", 2.0, 2000.0, NOW - 5 * DAY), ev("sell", "P", 1.5, 1000.0, NOW - 4 * DAY)]    # moitié vendue : +0,5 SOL
        m = metrics(evs, self.d)
        self.assertAlmostEqual(m["realized_pnl_sol"], 0.5, places=6)
        self.assertEqual(m["n_closed"], 0)

    def test_score_is_normalised_and_unknown_creation_caps_confidence(self):
        v = score_wallet(metrics(round_trips(30, 3.0, 0.9, 27, 30), self.d), self.d)
        self.assertLessEqual(v.score, 0.8)                      # création des tokens inconnue : plafond de confiance
        self.assertIn("sniper_unknown", v.reason)
        self.assertTrue(0.0 <= v.score <= 1.0)


# ---------------------------------------------------------------------------------------- registre / auto-entretien
def new_registry(tmp=None):
    j, cfg = Journal(), cfg_fast()
    return j, cfg, WalletRegistry(j, cfg)


def eligible(score=0.7):
    return Verdict("eligible", "ok", score, {"n_trades": 40, "n_closed": 12, "realized_pnl_sol": 3.0, "win_rate": 0.7,
                                             "age_days": 90.0, "age_complete": True, "tokens_per_day": 2.0, "sniper_share": 0.0})


class RegistryMaintenanceTest(unittest.TestCase):
    def test_new_wallet_starts_with_a_low_test_weight_and_the_move_is_logged(self):
        j, cfg, reg = new_registry()
        self.assertTrue(reg.add_pending("A", "MINT1234", NOW))
        self.assertFalse(reg.add_pending("A", "MINT1234", NOW))               # pas de doublon
        reg.apply_verdict("A", eligible(), NOW)
        self.assertEqual(reg.weight("A"), cfg.discovery.starter_weight)
        self.assertEqual(reg.get("A")["status"], "testing")
        acts = [r[2] for r in reg.events_since(0) if r[1] == "A"]
        self.assertEqual(acts, ["candidate", "added"])
        why = [r[3] for r in reg.events_since(0) if r[2] == "added"][0]
        self.assertIn("eligible", why)

    def test_excluded_and_unknown_wallets_have_zero_weight(self):
        j, cfg, reg = new_registry()
        for a, v in (("S", Verdict("excluded", "sprayer", 0.0, {"tokens_per_day": 30.0})),
                     ("U", Verdict("unknown", "too_few_closed_trades", None, {}))):
            reg.add_pending(a, "M", NOW)
            reg.apply_verdict(a, v, NOW)
            self.assertEqual(reg.weight(a), 0.0)
        self.assertEqual(reg.active_addresses(), [])

    def test_three_losing_signals_degrade_then_remove(self):
        j, cfg, reg = new_registry()
        reg.add_pending("A", "M", NOW)
        reg.apply_verdict("A", eligible(), NOW)
        for _ in range(3):
            reg.record_signal_outcome(["A"], -20.0, NOW)
        moves = reg.maintenance(NOW + DAY)
        self.assertEqual(moves[0][1], "degraded")
        self.assertIn("3 signaux perdants d'affilée", moves[0][2])
        self.assertAlmostEqual(reg.weight("A"), cfg.discovery.starter_weight * 0.5)      # poids réduit
        for _ in range(3):
            reg.record_signal_outcome(["A"], -15.0, NOW + DAY)
        moves = reg.maintenance(NOW + 2 * DAY)
        self.assertEqual(moves[0][1], "removed")                                          # puis retrait
        self.assertEqual((reg.weight("A"), reg.get("A")["status"]), (0.0, "removed"))
        self.assertEqual([r[2] for r in reg.events_since(0) if r[1] == "A"][-2:], ["degraded", "removed"])

    def test_negative_recent_pnl_over_five_signals_degrades_even_without_a_streak(self):
        j, cfg, reg = new_registry()
        reg.add_pending("A", "M", NOW)
        reg.apply_verdict("A", eligible(), NOW)
        for p in (10.0, -5.0, -8.0, 3.0, -6.0):                                           # somme -6 %, aucune série de 3 pertes
            reg.record_signal_outcome(["A"], p, NOW)
        self.assertEqual(reg.get("A")["consec_losses"], 1)
        moves = reg.maintenance(NOW + DAY)
        self.assertEqual(moves[0][1], "degraded")
        self.assertIn("P&L récent négatif", moves[0][2])

    def test_winning_signals_raise_the_weight_up_to_the_cap(self):
        j, cfg, reg = new_registry()
        reg.add_pending("A", "M", NOW)
        reg.apply_verdict("A", eligible(), NOW)
        for _ in range(3):
            reg.record_signal_outcome(["A"], 25.0, NOW)
        moves = reg.maintenance(NOW + DAY)
        self.assertEqual(moves[0][1], "promoted")
        self.assertAlmostEqual(reg.weight("A"), cfg.discovery.starter_weight + cfg.discovery.promote_step)
        self.assertEqual(reg.get("A")["status"], "tracked")
        for k in range(20):
            reg.record_signal_outcome(["A"], 10.0, NOW)
            reg.maintenance(NOW + (k + 2) * DAY)
        self.assertLessEqual(reg.weight("A"), cfg.discovery.max_weight)

    def test_outcome_only_reaches_the_wallets_of_the_signal(self):
        j, cfg, reg = new_registry()
        for a in ("A", "B"):
            reg.add_pending(a, "M", NOW)
            reg.apply_verdict(a, eligible(), NOW)
        reg.record_signal_outcome(["A", "UNKNOWN"], -10.0, NOW)
        self.assertEqual((reg.get("A")["signals_lost"], reg.get("B")["signals_lost"]), (1, 0))
        self.assertIsNone(reg.get("UNKNOWN"))

    def test_reevaluation_that_fails_removes_a_followed_wallet(self):
        j, cfg, reg = new_registry()
        reg.add_pending("A", "M", NOW)
        reg.apply_verdict("A", eligible(), NOW)
        reg.apply_verdict("A", Verdict("excluded", "sprayer", 0.0, {"tokens_per_day": 40.0}), NOW + 8 * DAY)
        self.assertEqual((reg.get("A")["status"], reg.weight("A")), ("removed", 0.0))


# ---------------------------------------------------------------------------------------- WalletBook : base + fichier
class WalletBookMergeTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.j, self.cfg = Journal(), cfg_fast()
        self.reg = WalletRegistry(self.j, self.cfg)
        for a in ("AUTO1", "EXCL1"):
            self.reg.add_pending(a, "M", NOW)
        self.reg.apply_verdict("AUTO1", eligible(), NOW)
        self.reg.apply_verdict("EXCL1", Verdict("excluded", "sprayer", 0.0, {}), NOW)

    def tearDown(self):
        self.tmp.cleanup()

    def book(self, text=None):
        path = Path(self.tmp.name) / "wallets.txt"
        if text is not None:
            path.write_text(text)
        return WalletBook(path, enforce_j7_freshness=False, journal=self.j, registry=self.reg)

    def test_database_wallets_work_without_any_file(self):
        b = self.book(None)                                                    # wallets.txt n'existe pas : devenu optionnel
        self.assertEqual(b.active(), {"AUTO1"})
        self.assertEqual(b.weight("AUTO1"), self.cfg.discovery.starter_weight)
        self.assertEqual(b.weight("EXCL1"), 0.0)
        self.assertNotIn("EXCL1", b.wallets)                                   # exclu : jamais suivi

    def test_file_and_database_are_merged(self):
        b = self.book("MAN1  # source=manual cluster=G1\n")
        self.assertEqual(b.active(), {"MAN1", "AUTO1"})
        self.assertEqual(b.weight("MAN1"), 1.0)                                # logique historique pour le fichier
        self.assertEqual(b.cluster("MAN1"), "G1")
        self.assertEqual(b.wallets["AUTO1"]["source"], "auto")

    def test_file_takes_precedence_when_a_wallet_is_in_both(self):
        b = self.book("AUTO1  # source=manual cluster=MINE\n")
        self.assertEqual(b.wallets["AUTO1"]["source"], "manual")
        self.assertEqual(b.cluster("AUTO1"), "MINE")
        self.assertEqual(b.weight("AUTO1"), 1.0)                               # choix explicite de l'utilisateur respecté

    def test_reload_picks_up_registry_changes(self):
        b = self.book(None)
        self.reg.add_pending("NEW1", "M", NOW)
        self.reg.apply_verdict("NEW1", eligible(), NOW)
        b.reload()
        self.assertIn("NEW1", b.active())
        for _ in range(3):
            self.reg.record_signal_outcome(["NEW1"], -20.0, NOW)
        self.reg.maintenance(NOW + DAY)
        b.reload()
        self.assertAlmostEqual(b.weight("NEW1"), self.cfg.discovery.starter_weight * 0.5)


# ---------------------------------------------------------------------------------------- sans clé / budget / lecture seule
class DisabledAndBudgetTest(unittest.TestCase):
    def env_without_key(self):
        env = {k: v for k, v in os.environ.items() if k != "HELIUS_API_KEY"}
        return mock.patch.dict(os.environ, env, clear=True)

    def test_without_key_the_module_disables_itself_with_a_clear_message(self):
        j, cfg = Journal(), cfg_fast()
        with self.env_without_key():
            disc = WalletDiscovery.from_env(cfg, j, WalletRegistry(j, cfg), dex=None)
        self.assertFalse(disc.enabled)
        self.assertIn("HELIUS_API_KEY", disc.why)
        self.assertIsNone(disc.step())                                         # ne fait rien, ne plante pas
        self.assertEqual(disc.tick(NOW), [])

    def test_public_rpc_is_opt_in_and_slow(self):
        j, cfg = Journal(), load_config()
        with self.env_without_key():
            disc = WalletDiscovery.from_env(cfg, j, WalletRegistry(j, cfg), dex=None, public_rpc=True)
        self.assertTrue(disc.enabled)
        self.assertEqual(disc.rpc.label, "public")
        self.assertAlmostEqual(disc.rpc.limiter.min_interval, 1.0 / cfg.discovery.public_rps)

    def test_key_is_read_from_the_environment_and_throttle_is_10_rps(self):
        j, cfg = Journal(), load_config()
        with mock.patch.dict(os.environ, {"HELIUS_API_KEY": "SECRETKEY123"}):
            disc = WalletDiscovery.from_env(cfg, j, WalletRegistry(j, cfg), dex=None)
        self.assertEqual(disc.rpc.label, "helius")
        self.assertAlmostEqual(disc.rpc.limiter.min_interval, 0.1)             # 10 requêtes par seconde
        self.assertNotIn("SECRETKEY123", repr(disc.why))

    def test_disabled_in_config(self):
        j, cfg = Journal(), cfg_fast()
        cfg["discovery"]["enabled"] = False
        self.assertFalse(WalletDiscovery.from_env(cfg, j, WalletRegistry(j, cfg), None).enabled)

    def test_cli_prints_the_reason_and_exits_cleanly_without_key(self):
        import argparse
        from main import run_discover
        with self.env_without_key(), tempfile.TemporaryDirectory() as tmp:
            out = io.StringIO()
            with contextlib.redirect_stdout(out):
                code = run_discover(load_config(), argparse.Namespace(db=str(Path(tmp) / "x.db"), public_rpc=False, max_units=0))
            self.assertEqual(code, 0)
            self.assertIn("désactivée", out.getvalue())
            self.assertIn("HELIUS_API_KEY", out.getvalue())

    def test_scout_keeps_running_when_discovery_is_disabled(self):
        j, cfg = Journal(), cfg_fast()
        with DisabledAndBudgetTest.env_without_key(self):
            disc = WalletDiscovery.from_env(cfg, j, WalletRegistry(j, cfg), None)
        with tempfile.TemporaryDirectory() as tmp:
            market = ReplayMarket({"tokens": {}}, validate=False)
            eng = Engine(cfg, market, WalletBook(Path(tmp) / "n.txt", enforce_j7_freshness=False), j,
                         PaperExecutor(cfg, market, 10.0), RiskManager(cfg), now_fn=lambda: NOW)

            class Dex:
                def discovery(self): return []
            Scout(cfg, eng, Dex(), j, now_fn=lambda: NOW, discovery=disc).tick()      # ne lève rien

    def test_scout_survives_a_crashing_discovery(self):
        j, cfg = Journal(), cfg_fast()
        class Boom:
            def tick(self, now): raise RuntimeError("panne")
        with tempfile.TemporaryDirectory() as tmp:
            market = ReplayMarket({"tokens": {}}, validate=False)
            eng = Engine(cfg, market, WalletBook(Path(tmp) / "n.txt", enforce_j7_freshness=False), j,
                         PaperExecutor(cfg, market, 10.0), RiskManager(cfg), now_fn=lambda: NOW)

            class Dex:
                def discovery(self): return []
            Scout(cfg, eng, Dex(), j, now_fn=lambda: NOW, discovery=Boom()).tick()

    def test_only_read_methods_are_allowed(self):
        j, cfg = Journal(), cfg_fast()
        rpc = ReadOnlyRpc("http://rpc.invalid", 100000, j, cfg, post=lambda u, p: {"result": []})
        for bad in ("getBalance", "requestAirdrop", "simulateBundle", "anything"):
            with self.assertRaises(ValueError):
                rpc.rpc(bad, [])
        self.assertEqual(rpc.rpc("getSignaturesForAddress", ["A", {"limit": 1}]), [])

    def test_daily_cap_is_enforced_persisted_and_resets_next_day(self):
        j, cfg = Journal(), cfg_fast()
        cfg["discovery"]["monthly_credit_budget"] = 90                          # plafond jour = 3
        clock = [NOW]
        mk = lambda: ReadOnlyRpc("http://rpc.invalid", 100000, j, cfg, now_fn=lambda: clock[0], post=lambda u, p: {"result": []})
        rpc = mk()
        for _ in range(3):
            rpc.rpc("getSignaturesForAddress", ["A", {}])
        with self.assertRaises(BudgetExceeded):
            rpc.rpc("getSignaturesForAddress", ["A", {}])
        with self.assertRaises(BudgetExceeded):                                 # compteur PERSISTÉ : une nouvelle instance ne repart pas de zéro
            mk().rpc("getSignaturesForAddress", ["A", {}])
        self.assertEqual(rpc.remaining_today(), 0)
        clock[0] += DAY
        mk().rpc("getSignaturesForAddress", ["A", {}])                          # lendemain : repart
        self.assertEqual(mk().usage()["today"], 1)
        self.assertEqual(mk().usage()["month"], 4)

    def test_monthly_cap_is_enforced_even_if_the_daily_cap_allows(self):
        from datetime import datetime, timezone
        j, cfg = Journal(), cfg_fast()
        cfg["discovery"]["monthly_credit_budget"] = 3000                        # plafond jour = 100
        month = datetime.fromtimestamp(NOW, timezone.utc).strftime("%Y-%m")
        j.kv_set("wd_credits", {"day": int(NOW // DAY), "day_used": 0, "month": month, "month_used": 2999})
        rpc = ReadOnlyRpc("http://rpc.invalid", 100000, j, cfg, now_fn=lambda: NOW, post=lambda u, p: {"result": []})
        self.assertEqual(rpc.remaining_today(), 1)                              # le mois limite, pas le jour
        rpc.rpc("getSignaturesForAddress", ["A", {}])
        with self.assertRaises(BudgetExceeded) as cm:
            rpc.rpc("getSignaturesForAddress", ["A", {}])
        self.assertIn("mensuel", str(cm.exception))


# ---------------------------------------------------------------------------------------- pipeline avec fausse blockchain
def swap_tx(wallet, mint, side, sol, tokens, ts, sig):
    delta = tokens if side == "buy" else -tokens
    sol_delta = -sol if side == "buy" else sol
    return {"blockTime": ts, "transaction": {"signatures": [sig], "message": {"accountKeys": [{"pubkey": wallet}, {"pubkey": "X"}]}},
            "meta": {"err": None, "fee": 5000, "preBalances": [10_000_000_000, 0],
                     "postBalances": [10_000_000_000 + int(sol_delta * 1e9) - 5000, 0],
                     "preTokenBalances": [{"owner": wallet, "mint": mint, "uiTokenAmount": {"uiAmountString": "1000"}}],
                     "postTokenBalances": [{"owner": wallet, "mint": mint, "uiTokenAmount": {"uiAmountString": str(1000 + delta)}}]}}


class FakeChain:
    def __init__(self):
        self.sigs, self.txs, self.calls, self.fail = {}, {}, [], False

    def post(self, url, payload):
        m, p = payload["method"], payload["params"]
        self.calls.append(m)
        if self.fail:
            raise HttpError("réseau coupé")
        if m == "getSignaturesForAddress":
            return {"result": self.sigs.get(p[0], [])}
        if m == "getTransaction":
            return {"result": self.txs.get(p[0])}
        return {"result": None}

    def add_wallet_history(self, wallet, trips, span_days, win_sell=1.6, loss_sell=0.7, wins=None, unreadable=0):
        wins = trips if wins is None else wins
        sigs, i = [], 0
        for k in range(trips):
            t = NOW - span_days * DAY + k * (span_days * DAY / trips)
            mint = f"{wallet}_T{k}"
            for side, sol, tt in (("buy", 1.0, t), ("sell", win_sell if k < wins else loss_sell, t + 3600)):
                sig = f"{wallet}-{i}"
                i += 1
                sigs.append({"signature": sig, "blockTime": int(tt), "err": None})
                if not (unreadable and i <= unreadable):
                    self.txs[sig] = swap_tx(wallet, mint, side, sol, 1000.0, int(tt), sig)
        self.sigs[wallet] = sorted(sigs, key=lambda s: -s["blockTime"])           # plus récent d'abord, comme le vrai RPC


class FakeDex:
    def __init__(self, pairs, feed=None): self._p, self._feed = pairs, feed or []
    def pairs(self, mint): return self._p.get(mint)
    def discovery(self): return list(self._feed)


def make_discovery(chain, dex=None, cfg=None, clock=None):
    j, cfg = Journal(), cfg or cfg_fast()
    reg = WalletRegistry(j, cfg)
    clock = clock or [NOW]
    rpc = ReadOnlyRpc("http://rpc.invalid", 100000, j, cfg, now_fn=lambda: clock[0], post=chain.post)
    return WalletDiscovery(cfg, j, reg, rpc, dex or FakeDex({}), now_fn=lambda: clock[0]), j, reg, clock


def _pair(h24, liq=50000.0, addr="POOL"):
    return {"chainId": "solana", "pairAddress": addr, "priceNative": "0.001", "priceUsd": "0.15", "liquidity": {"usd": liq},
            "priceChange": {"h24": h24}, "pairCreatedAt": 1_790_000_000_000}


class BootstrapTest(unittest.TestCase):
    def test_fresh_database_is_bootstrapped_from_the_discovery_feed(self):
        feed = [{"mint": m, "source": "boost"} for m in ("WINNER", "FLAT", "ILLIQUID", "NOPAIR")]
        dex = FakeDex({"WINNER": _pair(350.0), "FLAT": _pair(5.0), "ILLIQUID": _pair(900.0, liq=500.0)}, feed)
        disc, j, reg, clock = make_discovery(FakeChain(), dex=dex)
        self.assertEqual(disc.next_token(), "WINNER")                           # +100 % sur 24 h ET liquidité suffisante
        self.assertEqual(j.kv_get("wd_bootstrap")["queue"], ["WINNER"])
        j.kv_set("wd_tokens_done", {"WINNER": "ok:3"})
        self.assertIsNone(disc.next_token())                                    # file épuisée ; pas de nouvel amorçage avant 6 h
        calls = []
        dex.discovery = lambda: calls.append(1) or feed
        disc.next_token()
        self.assertEqual(calls, [])
        clock[0] += 7 * 3600
        disc.next_token()
        self.assertEqual(calls, [1])                                            # après 6 h : nouvel instantané

    def test_bootstrap_failure_is_harmless(self):
        class Broken:
            def discovery(self): raise HttpError("500")
            def pairs(self, m): raise HttpError("500")
        disc, *_ = make_discovery(FakeChain(), dex=Broken())
        self.assertIsNone(disc.next_token())

    def test_watch_winners_take_priority_over_bootstrap(self):
        dex = FakeDex({"B": _pair(500.0)}, [{"mint": "B", "source": "boost"}])
        disc, j, reg, _ = make_discovery(FakeChain(), dex=dex)
        j.log_watch("FROM_SCOUT", NOW, "reject", [], 1.0, 80.0, 300.0)
        self.assertEqual(disc.next_token(), "FROM_SCOUT")


class DiscoveryPipelineTest(unittest.TestCase):
    def test_wallet_evaluation_from_chain_history(self):
        chain = FakeChain()
        chain.add_wallet_history("GOOD", trips=8, span_days=30, wins=6)
        disc, j, reg, _ = make_discovery(chain)
        v = disc.evaluate_wallet("GOOD")
        self.assertEqual(v.status, "eligible", (v.reason, v.score, v.metrics))
        self.assertEqual(v.metrics["n_closed"], 8)
        self.assertAlmostEqual(v.metrics["age_days"], 30.0, delta=0.5)
        self.assertTrue(v.metrics["age_complete"])
        self.assertAlmostEqual(v.metrics["realized_pnl_sol"], 6 * 0.6 - 2 * 0.3, places=6)

    def test_unreadable_history_means_unknown_never_a_guess(self):
        chain = FakeChain()
        chain.add_wallet_history("BAD", trips=8, span_days=30, unreadable=10)    # 10 transactions sur 16 introuvables
        disc, *_ = make_discovery(chain)
        v = disc.evaluate_wallet("BAD")
        self.assertEqual((v.status, v.reason, v.score), ("unknown", "history_unreadable", None))
        self.assertEqual(disc.evaluate_wallet("EMPTY").reason, "no_history")

    def test_rpc_failure_leaves_the_wallet_pending_and_does_not_crash(self):
        chain = FakeChain()
        disc, j, reg, _ = make_discovery(chain)
        reg.add_pending("W", "M", NOW)
        chain.fail = True
        self.assertIsNone(disc.step())
        self.assertEqual(reg.get("W")["status"], "pending")                      # ni évalué ni exclu : pas de verdict deviné

    def test_early_buyers_extracted_from_the_start_of_the_pool_history(self):
        chain = FakeChain()
        t0 = int(NOW - 3600)
        sigs = [{"signature": f"s{i}", "blockTime": t0 + i * 20, "err": None} for i in range(4)]
        sigs.append({"signature": "late", "blockTime": t0 + 3 * 3600, "err": None})            # hors fenêtre de 30 min
        chain.sigs["POOL"] = list(reversed(sigs))
        chain.txs["s0"] = swap_tx("B1", "M", "buy", 1.0, 1000.0, t0, "s0")
        chain.txs["s1"] = swap_tx("B2", "M", "buy", 2.0, 1000.0, t0 + 20, "s1")
        chain.txs["s2"] = swap_tx("B1", "M", "buy", 1.0, 1000.0, t0 + 40, "s2")               # doublon de B1
        chain.txs["s3"] = swap_tx("S1", "M", "sell", 1.0, 1000.0, t0 + 60, "s3")                # vendeur : ignoré
        chain.txs["late"] = swap_tx("B9", "M", "buy", 1.0, 1000.0, t0 + 3 * 3600, "late")
        disc, *_ = make_discovery(chain)
        res, why = disc.early_buyers("M", "POOL")
        self.assertEqual(why, "ok")
        self.assertEqual(res[0], ["B1", "B2"])

    def test_token_whose_history_cannot_be_reached_is_skipped_not_guessed(self):
        chain = FakeChain()
        chain.sigs["POOL"] = [{"signature": f"x{i}", "blockTime": 1_790_000_000 + i, "err": None} for i in range(1000)]
        disc, j, reg, _ = make_discovery(chain, dex=FakeDex({"M": {"pairAddress": "POOL", "pairCreatedAt": 1_790_000_000_000}}))
        msg = disc.process_token("M")
        self.assertIn("irrécupérable", msg)
        self.assertEqual(reg.counts(), {})                                       # aucun candidat inventé
        self.assertEqual(j.kv_get("wd_tokens_done")["M"], "history_too_long")
        self.assertEqual(chain.calls.count("getSignaturesForAddress"), disc.d.max_sig_pages)   # pages bornées

    def test_full_flow_token_to_candidates_to_verdicts(self):
        chain = FakeChain()
        t0 = int(NOW - 7200)
        chain.sigs["POOL"] = [{"signature": "e1", "blockTime": t0, "err": None}, {"signature": "e2", "blockTime": t0 + 30, "err": None}]
        chain.txs["e1"] = swap_tx("GOOD", "M", "buy", 1.0, 1000.0, t0, "e1")
        chain.txs["e2"] = swap_tx("SPRAY", "M", "buy", 1.0, 1000.0, t0 + 30, "e2")
        chain.add_wallet_history("GOOD", trips=8, span_days=30, wins=6)
        spray = []
        for i in range(40):
            t = NOW - 5 * DAY + i * 1200
            for k, (side, sol) in enumerate((("buy", 1.0), ("sell", 1.5))):
                sig = f"SP-{i}-{k}"
                spray.append({"signature": sig, "blockTime": int(t + 300 * k), "err": None})
                chain.txs[sig] = swap_tx("SPRAY", f"SP{i}", side, sol, 1000.0, int(t + 300 * k), sig)
        spray.append({"signature": "SP-old", "blockTime": int(NOW - 60 * DAY), "err": None})       # wallet ancien (60 jours)
        chain.sigs["SPRAY"] = sorted(spray, key=lambda s: -s["blockTime"])
        disc, j, reg, clock = make_discovery(chain, dex=FakeDex({"M": {"pairAddress": "POOL", "pairCreatedAt": t0 * 1000}}))
        j.log_watch("M", NOW - 3 * 3600, "reject", ["low_liquidity"], 1.0, 120.0, 400.0)     # un token qui a bien performé
        msgs = []
        while True:
            m = disc.step()
            if m is None:
                break
            msgs.append(m)
        self.assertEqual(len(msgs), 3)                                           # 1 token + 2 évaluations
        self.assertIn("2 nouveaux candidats", msgs[0])
        self.assertEqual(reg.get("GOOD")["status"], "testing")
        self.assertEqual(reg.weight("GOOD"), disc.d.starter_weight)
        self.assertEqual((reg.get("SPRAY")["status"], reg.get("SPRAY")["reason"]), ("excluded", "sprayer"))
        self.assertIn("M", j.kv_get("wd_tokens_done"))
        self.assertIsNone(disc.step())                                           # file vide
        self.assertIn("M", j.kv_get("wd_token_meta"))                            # date de création mémorisée (métrique sniper)

    def test_budget_exhaustion_pauses_and_resumes_next_day(self):
        chain = FakeChain()
        chain.add_wallet_history("GOOD", trips=8, span_days=30, wins=6)
        cfg = cfg_fast()
        cfg["discovery"]["monthly_credit_budget"] = 30 * 5                       # 5 appels par jour : insuffisant pour 1 wallet
        disc, j, reg, clock = make_discovery(chain, cfg=cfg)
        reg.add_pending("GOOD", "M", NOW)
        self.assertIsNone(disc.step())                                           # budget épuisé en cours de travail : pause, pas de plantage
        self.assertEqual(reg.get("GOOD")["status"], "pending")
        self.assertEqual(disc.rpc.remaining_today(), 0)
        cfg["discovery"]["monthly_credit_budget"] = 30 * 100                     # budget relevé / lendemain
        disc.rpc.daily_cap = 100
        clock[0] += DAY
        self.assertIsNotNone(disc.step())
        self.assertEqual(reg.get("GOOD")["status"], "testing")

    def test_candidate_tokens_include_winners_and_tokens_of_followed_wallets_but_not_done_ones(self):
        chain = FakeChain()
        disc, j, reg, _ = make_discovery(chain)
        j.log_watch("LOSER", NOW, "enter", [], 1.0, -50.0, -80.0)
        j.log_watch("WIN", NOW, "enter", [], 1.0, 60.0, 300.0)
        self.assertEqual(disc.next_token(), "WIN")
        j.kv_set("wd_tokens_done", {"WIN": "ok:3"})
        self.assertIsNone(disc.next_token())                                      # le perdant n'est jamais exploré
        reg.add_pending("F", "M", NOW)
        reg.apply_verdict("F", eligible(), NOW)
        j.log_event(ev("buy", "BOUGHT_BY_F", 1.0, 100.0, NOW, wallet="F"))
        self.assertEqual(disc.next_token(), "BOUGHT_BY_F")

    def test_creation_map_feeds_the_sniper_metric(self):
        chain = FakeChain()
        disc, j, reg, _ = make_discovery(chain)
        j.log_candidate(NOW, "M1", "A", "reject", 0.0, [], {"pair_created_ts": 1_790_000_000})
        j.kv_set("wd_token_meta", {"M2": {"pair": "P", "created_ts": 1_790_000_500}})
        self.assertEqual(disc.creation_map(), {"M1": 1_790_000_000, "M2": 1_790_000_500})

    def test_daily_tick_runs_maintenance_once_and_logs_moves(self):
        chain = FakeChain()
        disc, j, reg, clock = make_discovery(chain)
        reg.add_pending("A", "M", NOW)
        reg.apply_verdict("A", eligible(), NOW)
        for _ in range(3):
            reg.record_signal_outcome(["A"], -20.0, NOW)
        first = disc.tick(NOW + DAY)
        self.assertEqual([m[1] for m in first], ["degraded"])
        self.assertEqual(disc.tick(NOW + DAY + 60), [])                           # une seule passe par jour


# ---------------------------------------------------------------------------------------- moteur + rapport
class EngineAndReportTest(unittest.TestCase):
    def test_closed_position_outcome_is_attributed_to_the_signal_wallets(self):
        j, cfg = Journal(), cfg_fast()
        cfg["sim"]["tx_fail_prob"] = 0.0
        reg = WalletRegistry(j, cfg)
        reg.add_pending("WX", "M", NOW)
        reg.apply_verdict("WX", eligible(), NOW)
        with tempfile.TemporaryDirectory() as tmp:
            market = ReplayMarket({"sol_usd": 150, "tokens": {"M": {"price_path": [[0, 1.0]], "liquidity_usd": 500000}}}, validate=False)
            book = WalletBook(Path(tmp) / "n.txt", enforce_j7_freshness=False, journal=j, registry=reg)
            eng = Engine(cfg, market, book, j, PaperExecutor(cfg, market, 10.0), RiskManager(cfg))
            pos, why = eng.broker.buy("M", "M", 0.5, 0, ["WX"])
            pos.risk_sol = 0.1
            eng.positions.append(pos)
            e = pos.entry_price
            market.tokens["M"]["price_path"] = [[0, e], [60, e * 0.5], [120, e * 0.5]]
            market._ts["M"] = [0, 60, 120]
            eng._last_tick = 0
            eng.advance_to(180)
            self.assertTrue(eng.closed)
            self.assertEqual((reg.get("WX")["signals_lost"], reg.get("WX")["consec_losses"]), (1, 1))

    def test_report_has_a_wallets_section(self):
        j, cfg = Journal(), cfg_fast()
        reg = WalletRegistry(j, cfg)
        for a in ("AAAA1111BBBB", "SPRAY0000"):
            reg.add_pending(a, "M", NOW)
        reg.apply_verdict("AAAA1111BBBB", eligible(0.72), NOW)
        reg.apply_verdict("SPRAY0000", Verdict("excluded", "sprayer", 0.0, {"tokens_per_day": 30.0}), NOW)
        for _ in range(3):
            reg.record_signal_outcome(["AAAA1111BBBB"], -20.0, NOW)
        reg.maintenance(NOW + DAY)
        j.kv_set("wd_credits", {"day": 1, "day_used": 412, "month": "2027-01", "month_used": 5100})
        rep = build_report(j, 10.0, cfg=cfg)
        self.assertIn("WALLETS SUIVIS AUTOMATIQUEMENT", rep)
        self.assertIn("AAAA11…BBBB", rep)
        self.assertIn("degraded", rep)
        self.assertIn("sprayer", rep)
        self.assertIn("412 aujourd'hui", rep)
        self.assertNotIn("WALLETS SUIVIS", build_report(Journal(), 10.0, cfg=cfg))        # section absente si rien n'a été découvert


if __name__ == "__main__":
    unittest.main(verbosity=2)
