#!/usr/bin/env python3
"""Rejoue les règles de SORTIE du bot sur des bougies OHLCV (réelles ou fichier JSON), en supposant le PIRE ordre dans
chaque bougie (le plus bas avant le plus haut). Sert à valider la mécanique de sortie sur des prix réels récents,
pas à prouver une rentabilité.

    python tools/replay_ohlcv.py --pool ADRESSE_DU_POOL [--entry-index 10]     (réseau requis)
    python tools/replay_ohlcv.py --file candles.json  [--entry-index 10]       ([[ts,o,h,l,c,v], ...])
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from bot.config import load_config  # noqa: E402
from bot.db import Journal  # noqa: E402
from bot.engine import Engine  # noqa: E402
from bot.execution.paper import PaperExecutor  # noqa: E402
from bot.market import ReplayMarket  # noqa: E402
from bot.risk import RiskManager  # noqa: E402
from bot.sources.geckoterminal import fetch_ohlcv, parse_ohlcv  # noqa: E402
from bot.wallets import WalletBook  # noqa: E402


def candles_to_path(candles, step=60):
    """Chaque bougie devient 4 points dans l'ordre pessimiste : ouverture, plus bas, plus haut, clôture."""
    pts = []
    for ts, o, h, l, c, _v in candles:
        q = step / 4.0
        pts += [[ts, o], [ts + q, l], [ts + 2 * q, h], [ts + 3 * q, c]]
    return pts


def replay(candles, cfg, entry_index=0, size_sol=0.1, liquidity_usd=100000.0):
    """Entre à l'ouverture de la bougie `entry_index`, puis applique les sorties du moteur jusqu'à la fin."""
    path = candles_to_path(candles)
    market = ReplayMarket({"sol_usd": 1.0, "tokens": {"X": {"price_path": path, "liquidity_usd": liquidity_usd}}},
                          validate=False)
    cfg["sim"]["tick_s"] = 15
    cfg["sim"]["tx_fail_prob"] = 0.0
    j = Journal()
    eng = Engine(cfg, market, WalletBook("none.txt", enforce_j7_freshness=False), j,
                 PaperExecutor(cfg, market, 10.0), RiskManager(cfg))
    t0 = candles[entry_index][0]
    pos, why = eng.broker.buy("X", "X", size_sol, t0, [])
    if pos is None:
        return {"error": why}
    pos.risk_sol = size_sol * cfg.exit.stop_loss_pct / 100
    eng.positions.append(pos)
    eng._last_tick = t0
    eng.advance_to(candles[-1][0] + 60)
    done = eng.closed[0] if eng.closed else None
    return {"entry_price": pos.entry_price, "closed": bool(done), "exit_reason": done.exit_reason if done else "ouvert",
            "pnl_pct": 100 * ((done.proceeds_sol if done else pos.proceeds_sol) - size_sol) / size_sol if done else None,
            "peak_vs_entry_pct": 100 * (pos.peak_price / pos.entry_price - 1),
            "trough_vs_entry_pct": 100 * (pos.trough_price / pos.entry_price - 1)}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--pool")
    ap.add_argument("--file")
    ap.add_argument("--entry-index", type=int, default=0)
    ap.add_argument("--config", default="config.toml")
    a = ap.parse_args()
    if a.file:
        candles = parse_ohlcv({"data": {"attributes": {"ohlcv_list": json.loads(Path(a.file).read_text())}}})
    elif a.pool:
        candles = fetch_ohlcv(a.pool)
    else:
        raise SystemExit("Donne --pool ou --file")
    if len(candles) < 5:
        raise SystemExit("Pas assez de bougies lisibles.")
    print(json.dumps(replay(candles, load_config(a.config), a.entry_index), indent=1, default=str))


if __name__ == "__main__":
    main()
