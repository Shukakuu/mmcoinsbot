#!/usr/bin/env python3
"""Rejoue les règles du bot réel (stop 25 %, trailing 35 % armé à x3) sur l'historique de prix contenu dans
real_state.pkl, sous plusieurs hypothèses d'exécution. Le but n'est PAS de trouver un chiffre flatteur mais de
mesurer À QUEL POINT le résultat dépend de l'exécution.

Sécurité : le .pkl est chargé par un chargeur qui REFUSE toute classe (donnée pure uniquement).

    python tools/backtest_real_state.py real_state.pkl
Limites : un seul soir (5 h), 57 tokens ; les tokens morts ont pu être purgés de l'état (biais du survivant) ;
les prix sont des cotations au moment des swaps, pas des prix exécutables."""
import io
import pickle
import statistics as st
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from bot.gate import _profit_factor, bootstrap_p_positive  # noqa: E402

THR, SL, TRAIL, ARM = 13000, 0.25, 0.35, 3.0


class SafeUnpickler(pickle.Unpickler):
    def find_class(self, module, name):
        raise pickle.UnpicklingError(f"classe interdite : {module}.{name}")


def load(path):
    return SafeUnpickler(io.BytesIO(Path(path).read_bytes())).load()


def run(state, delay_s=0, fee=0.03, entry_slip=0.0, exit_slip=0.06, capture=1.0):
    """delay_s : 0 = prix au franchissement ; N = 1re cotation >= N s après. capture : part du gain conservée
    sur les trades > x2 (ton meilleur trade : (2,58-1)/(5,75-1) = 0,33)."""
    out = []
    for v in state["tokens"].values():
        ts, mc = v["ts"], v["mc"]
        if len(ts) != len(mc) or not mc:
            continue
        i = next((k for k, x in enumerate(mc) if x >= THR), None)
        if i is None:
            continue
        j = i if delay_s == 0 else next((k for k in range(i, len(ts)) if ts[k] >= ts[i] + delay_s), None)
        if j is None:
            continue
        entry = mc[j] * (1 + entry_slip)
        peak, exit_p = entry, None
        for k in range(j + 1, len(mc)):
            p = mc[k]
            peak = max(peak, p)
            armed = peak >= entry * ARM
            if p <= (peak * (1 - TRAIL) if armed else entry * (1 - SL)):
                exit_p = p
                break
        if exit_p is None:
            exit_p = mc[-1]
        gross = exit_p / entry
        if gross > 2:
            gross = 1 + (gross - 1) * capture
        out.append(((1 - fee) ** 2 * (1 - exit_slip) * gross - 1) * 100)
    return out


SCENARIOS = [
    ("Rêve : aucun coût, rempli au prix du franchissement", dict(fee=0, exit_slip=0)),
    ("Coûts mesurés (3 %/côté, entrée +5,8 %, sortie -6 %), rempli au franchissement", dict(entry_slip=0.058)),
    ("  + gros gagnants capturés à 33 % (ratio observé en réel)", dict(entry_slip=0.058, capture=0.33)),
    ("Entrée +10 s, coûts réels de sortie, capture 33 %", dict(delay_s=10, capture=0.33)),
    ("Entrée +30 s (bot plus lent), capture 33 %", dict(delay_s=30, capture=0.33)),
]


def trigger_analysis(state, delay_s=10, spray_share=0.5):
    """Suivre les wallets de l'ancien bot (entrée `delay_s` s après leur achat, coûts réels, capture 33 %) aurait-il
    rapporté ? Détecte aussi les « arroseurs » : wallets présents sur plus de `spray_share` des tokens."""
    from collections import Counter, defaultdict
    toks = state["tokens"]
    cnt = Counter(w for v in toks.values() for w in v["buys"])
    spray = {w for w, c in cnt.items() if c / len(toks) >= spray_share}
    print(f"\nWallets suivis : {len(cnt)} ; présence par wallet : "
          + ", ".join(f"{w[:6]}…={c}/{len(toks)}" for w, c in cnt.most_common())
          + f"\n→ « arroseurs » (>= {spray_share:.0%} des tokens) : {[w[:6] + '…' for w in sorted(spray)]}")
    groups = defaultdict(list)
    for v in toks.values():
        ts, mc = v["ts"], v["mc"]
        if len(ts) != len(mc) or not mc or not v["buys"]:
            continue
        buys = sorted(v["buys"].items(), key=lambda kv: kv[1])
        t_entry = buys[min(1, len(buys) - 1)][1]
        j = next((k for k, x in enumerate(ts) if x >= t_entry + delay_s), None)
        if j is None or j >= len(mc) - 1:
            continue
        entry, peak, ex = mc[j], mc[j], None
        for k in range(j + 1, len(mc)):
            p = mc[k]
            peak = max(peak, p)
            if p <= (peak * (1 - TRAIL) if peak >= entry * ARM else entry * (1 - SL)):
                ex = p
                break
        g = (ex if ex is not None else mc[-1]) / entry
        if g > 2:
            g = 1 + (g - 1) * 0.33
        r = ((1 - 0.03) ** 2 * (1 - 0.06) * g - 1) * 100
        rare = sum(1 for w, _ in buys if w not in spray)
        groups["TOUS"].append(r)
        groups["au moins un wallet sélectif" if rare else "arroseurs seuls"].append(r)
        groups[f"{len(buys)} acheteur(s)"].append(r)
    print(f"Rendement net par trade, entrée à +{delay_s} s de l'achat (coûts réels, capture 33 %) :")
    for k, r in sorted(groups.items()):
        if len(r) >= 2:
            print(f"   {k:30s} n={len(r):2d}  moyenne {st.mean(r):+6.1f} %  médiane {st.median(r):+6.1f} %  "
                  f"réussite {sum(x > 0 for x in r) / len(r) * 100:3.0f} %  P(espérance>0) {bootstrap_p_positive(r):.0%}")


def main():
    state = load(sys.argv[1] if len(sys.argv) > 1 else "real_state.pkl")
    n_tok = len(state["tokens"])
    print(f"{n_tok} tokens dans l'état. Règles : stop {SL:.0%}, trailing {TRAIL:.0%} armé à x{ARM:g}, seuil {THR:,} $.\n")
    for title, kw in SCENARIOS:
        r = run(state, **kw)
        rest = sorted(r, reverse=True)[3:]
        print(f"{title}\n   n={len(r)}  moyenne={st.mean(r):+6.1f} %  médiane={st.median(r):+6.1f} %  "
              f"réussite={sum(x > 0 for x in r) / len(r) * 100:.0f} %  PF={_profit_factor(r):.2f}  "
              f"PF sans top3={_profit_factor(rest):.2f}  P(espérance>0)={bootstrap_p_positive(r):.0%}")
    trigger_analysis(state)


if __name__ == "__main__":
    main()
