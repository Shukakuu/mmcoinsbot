# memebot : bot prudent de memecoins Solana (simulation / paper trading)

**Objectif : préserver le capital et chercher un petit avantage statistique, pas gagner gros d'un coup.**
Ce projet ne passe AUCUN ordre réel : il simule, journalise et mesure. Python 3.11+, aucune dépendance
pour le bot (seul `j7_sync.py` a besoin de Playwright).

## Démarrage rapide (hors-ligne, 10 secondes)

```bash
python main.py gen-sample      # crée un scénario synthétique de test
python main.py replay -v       # rejoue le scénario et affiche le rapport
python -m unittest discover -s tests -t .   # 151 tests (106 cœur + 45 découverte de wallets)
python main.py replay --config config.microcap.toml   # mêmes trades avec frictions réalistes (~18 %)
python main.py gate --real-csv trades.csv --capital 150   # la porte de promotion sur n'importe quel CSV de trades
```

## Comment le bot décide

```
wallets suivis ─► convergence (>=3 clusters indépendants) ─► filtres éliminatoires ─► score /100
   ─► gestionnaire de risque ─► exécution simulée réaliste ─► sorties automatiques ─► journal + rapport
```

- **Convergence** : des wallets financés par la même source (même `cluster`) comptent pour un seul.
- **Filtres éliminatoires** (donnée inconnue = rejet) : autorités mint/freeze, liquidité, âge de la paire,
  FDV, route de vente et impact à NOTRE taille, niveaux RugCheck, concentration des top holders,
  prix déjà parti (drift), veto X.
- **Risque** : 1 % par trade, 10 % d'exposition max (comptée au coût d'entrée, choix assumé), taille limitée à 0,5 % de la liquidité du pool,
  stop journalier -3 % (appliqué même si le 1er événement du jour est une clôture), pause après 4 pertes, fichier `STOP` = plus aucune entrée, données périmées ou source en panne (disjoncteur après 5 échecs réseau) = pas d'entrée, signal trop vieux = pas d'entrée.
- **Redémarrage** : l'état (cash, positions, risque) est sauvegardé ; le live refuse de démarrer si le journal contient des positions que l'état ne connaît pas.
- **Sorties** : stop -20 %, vente de moitié à x2, trailing 25 % ensuite (plancher = prix d'entrée), sortie
  d'urgence si la liquidité chute de 50 %, sortie si 2 wallets suivis vendent, limite de 12 h.
- **Simulation réaliste** : latence, impact de prix, frais 1 %, pourboire, 8 % de transactions ratées.
- **Wallets** : poids selon leurs résultats observés ; un wallet perdant (>=5 trades) est ignoré.
- **Journal complet** (SQLite) y compris les tokens REJETÉS : le rapport compare ce que deviennent les acceptés
  et les rejetés, pour savoir si les filtres protègent vraiment.

## Ce qui est vérifié, et ce qui ne l'est pas

| | État |
|---|---|
| Logique (filtres, convergence, risque, courtier simulé, sorties, journal, rapport, redémarrage, déterminisme) | ✅ testée (151 tests + scénario) |
| Lecture d'une transaction Solana (`parse_swap`) | ✅ testée sur transactions **synthétiques** |
| Scraper J7 (`j7_sync.py`) | ⚠️ logique testée ; **jamais lancé sur le vrai site** |
| Appels réels : DexScreener, RugCheck, Jupiter, RPC Helius | ⚠️ **écrits mais jamais exécutés** (mon environnement n'a pas internet) : formats lus de façon défensive, à valider au premier lancement |
| Alertes Telegram, verrou Windows (`msvcrt`) | ⚠️ alertes testées avec un faux serveur ; verrou testé sous Linux seulement |
| Routes publiques DexScreener (découverte) | ✅ format vérifié sur une vraie réponse (16/10/2026) |
| `/token-pairs`, RugCheck `/report`, GeckoTerminal, PumpPortal | ⚠️ écrits d'après la documentation, **jamais exécutés** : lance `validate_sources.py` |
| Module X | ❌ interface seulement (`x_signal.py`) ; la version live viendra après validation du cœur |
| Exécution d'ordres réels | ❌ volontairement absente |

**Les résultats du scénario synthétique ne prouvent rien sur la rentabilité**, ils vérifient seulement la mécanique.

## Limites à connaître

1. **Latence du mode live** : le sondage RPC interroge chaque wallet toutes les 2 minutes. C'est trop lent pour
   du snipe ; la vraie solution est un webhook (étape suivante). Le sondage est un point de départ.
2. **Crédits RPC** : le plan gratuit Helius donne 1 000 000 crédits/mois. Le bot estime sa consommation au
   démarrage et s'arrête d'interroger à `max_rpc_calls_per_day`.
3. **Jupiter** : l'ancienne URL gratuite `lite-api.jup.ag` devait être retirée le 31 janvier 2026 au profit de
   `api.jup.ag` avec une clé gratuite (portal.jup.ag). Le bot lit `JUPITER_API_KEY` / `JUPITER_BASE_URL`.
4. **Le test de vente est un test de cotation** (une route de sortie existe, impact à notre taille), pas
   une simulation de transaction complète : à renforcer avant tout argent réel.

## v2 : ce qui a été ajouté après l'échec d'un bot réel

| Problème observé sur le bot réel | Réponse dans `memebot` |
|---|---|
| Frictions de ~18 % avalant l'avantage | **Porte de coût** : le coût aller-retour est estimé (frais, slippage, impact de pool, pourboires fixes) puis **mesuré** en live par cotations achat+vente ; au-dessus de 12 %, le trade est refusé |
| Un seul trade gagnant masquait la perte | Rapport « sans le meilleur trade », **porte de promotion** (`python main.py gate`) : ≥ 200 trades, confiance statistique ≥ 90 % que l'espérance est positive (bootstrap), profit factor ≥ 1,3 **et ≥ 1,0 sans les 3 meilleurs trades**, drawdown ≤ 15 % |
| Code modifié en production, chiffres non comparables | **Empreinte config+code** sur chaque trade ; la porte ne compte que la version la plus récente |
| Sorties réglées au jugé | **MAE / MFE / R-multiple** par trade, par motif de sortie ; **stop à breakeven** après +35 % ; **trailing par paliers** (25 → 18 → 14 → 10 %) |
| Slippage de vente élargi jusqu'à 45 % après échecs | `bot/execution_policy.py` : plafond dur à 20 %, puis position déclarée « bloquée » + alerte (spécification du futur courtier réel) |
| Mises de 20 % du capital | 1 % par trade, mais **voir la limite ci-dessous** |

⚠ **Limite économique à connaître.** Sur Solana, les pourboires et frais de priorité sont fixes (~0,003 SOL par
transaction). Une position de 0,01 SOL (1 % d'un compte d'environ 150 $) coûte **~64 % d'aller-retour** : le
bot refusera donc de trader, et il a raison. La stratégie « 1 % par trade » exige un capital d'au moins quelques
dizaines de SOL, ou une chaîne à frais quasi nuls.

## Leçons d'un bot réel qui a perdu

Voir `ANALYSE_REAL_BOT.md`. En bref : les frictions (~18 % aller-retour sur des micro-caps) ont mangé l'avantage,
et le résultat reposait sur un seul trade. Le rapport affiche donc « sans le meilleur trade », le slippage d'entrée
mesuré et les frictions simulées ; **teste toujours aussi avec `config.microcap.toml`**.

## Découverte automatique de wallets : plus de `wallets.txt` à la main

```bash
export HELIUS_API_KEY=...                 # lecture seule ; jamais dans le code (Windows : set HELIUS_API_KEY=...)
python main.py discover-wallets           # 1re passe : lente, normale ; reprise automatique à chaque lancement
python main.py scout                      # le scout entretient ensuite la liste tout seul (passe quotidienne)
python main.py scout-report               # section « WALLETS SUIVIS » : liste, scores, mouvements des 24 h, crédits
```
**Comment ça marche** : tokens qui ont bien performé (suivi à +6 h du scout ; sur base vierge, amorçage gratuit avec les tokens du flux
DexScreener à +100 % sur 24 h) → pool → acheteurs des premières minutes (candidats) → historique de chaque candidat → métriques →
score 0-1 → `testing` à **poids débutant faible (0,3)** → promu (+0,2, plafond 1,5) si ses signaux gagnent, **dégradé** (poids ÷ 2) puis
**retiré** après 3 signaux perdants d'affilée ou un P&L récent négatif sur 5 signaux. Chaque ajout, retrait, promotion est journalisé
avec sa raison (`wallet_events`). `wallets.txt` reste possible (prioritaire, fusionné avec la base) mais n'est plus nécessaire.

**Métriques** (sur les achats/ventes réels du wallet) : nombre de trades, ancienneté, **P&L réalisé** (achats appariés aux ventes, coût
moyen ; une vente sans achat connu est ignorée), taux de réussite sur les trades clôturés (≥ 80 % vendus), sélectivité (> 12 tokens/jour =
arroseur, exclu), pénalité « premier acheteur systématique » (achats dans les 60 s de la création ≥ 50 % → score × 0,3), régularité (un gain
porté par UN seul trade vaut 0). **Jamais de donnée devinée** : historique illisible ou < 5 trades clôturés = score inconnu = exclu ; si la
date de création des tokens est inconnue, le score est plafonné à 0,8 plutôt que supposé.

**Budget** : lecture seule (3 méthodes RPC autorisées, rien d'autre), throttle 10 req/s (2 req/s en RPC public), plafond mensuel
30 000 crédits (plafond jour = 1 000), compteur **persistant**, consommation journalisée. ⚠ *Hypothèse : 1 crédit par appel RPC, à confirmer sur ton
plan.* À ce rythme, évaluer un wallet coûte ~60 appels : **environ 15 wallets par jour** ; le premier remplissage prend donc des jours, c'est normal.
Sans clé : le module se désactive avec un message clair et le scout continue (RPC public lent en option : `--public-rpc`).

⚠ **Limites à connaître** : (1) *biais du survivant* : les candidats sont des acheteurs précoces de tokens qui ont réussi ; seuls leur historique
réalisé et le test réel de leurs signaux limitent ce biais, ils ne le suppriment pas ; (2) chaque wallet est supposé indépendant (l'origine des
fonds n'est pas analysée) ; (3) 60 transactions par wallet = fenêtre courte pour un wallet très actif ; (4) **rien de tout cela n'a été exécuté
contre le vrai Helius** (pas de réseau dans mon environnement) : le format des réponses est celui du RPC Solana standard, à confirmer au premier
lancement ; (5) le score est un réglage prudent, pas une preuve de talent.

## Mode scout : paper trading FORWARD sur API publiques (sans clé, sans transaction réelle)

```bash
python validate_sources.py            # DexScreener + RugCheck + GeckoTerminal : plus aucun ❌
python main.py scout -v               # tourne 48 à 72 h ; crée un fichier STOP pour interdire toute nouvelle entrée
python main.py scout-report           # rapport : trades, win rate, P&L net, refus + raisons, tailles, revue, porte de promotion
```
Pipeline : flux de découverte DexScreener (`token-profiles` + `token-boosts`, Solana seulement, un instantané toutes les 90 s)
→ données de paire (`/token-pairs/v1/solana/{mint}`) → sécurité RugCheck (`/report`) → filtres éliminatoires → score (avec volume
et pression d'achat) → **sizing dynamique** → entrée simulée au prix réel + coûts → sorties automatiques → **`decisions.jsonl`**
(une ligne par décision, entrée et sortie : horodatage, token, prix d'entrée/sortie, raison). Suivi optionnel de wallets via
PumpPortal (`scout.pumpportal = true`, `pip install websockets`, 5 wallets max).

⚠ **Les flux de découverte sont des promotions payantes** (profils améliorés, boosts) : ni smart money, ni gage de qualité. Le
paper trading mesurera s'ils valent quelque chose ; il est raisonnable de s'attendre à un biais défavorable.
⚠ Sans cotation Jupiter, la « route de vente » est déduite du rapport RugCheck et l'impact de sortie est modélisé : détection de
honeypot **plus faible** qu'en mode complet.
⚠ **Profils de coûts** : `config.paper_spec.toml` reprend le cahier des charges (frais 0,1 %/côté, slippage 1 %) mais c'est très en
dessous des frictions mesurées sur un vrai bot (~18 % aller-retour). Lance aussi le profil par défaut et `config.microcap.toml`, et
compare : un résultat qui n'existe qu'avec le profil flatteur n'existe pas.

## Architecture : décision découplée de l'exécution

```
bot/engine.py            décision (filtres, score, sizing, sorties) : ne connaît QUE l'interface Executor
bot/execution/           Executor (interface unique : buy / sell / equity) ; PaperExecutor (actuel) ;
                         JupiterExecutor = emplacement réservé, NON instanciable, aucun code de transaction
bot/risk/                RiskManager (plafonds, perte max/jour, cooldown, STOP) + sizing.py (sizing dynamique)
```
**Sizing dynamique** : `taille = équité × plafond × solidité(score) × concordance(wallets) × contexte`, puis limitée par la liquidité du
pool, l'impact de sortie (vérifié AVANT l'entrée) et l'exposition restante. Le meilleur signal = 100 % du plafond, jamais plus ; les
pertes réduisent la taille, les gains ne l'augmentent pas. ⚠ Le lien score → taille n'est pas validé statistiquement : seuls les
plafonds protègent. ⚠ Avec peu de capital, les pourboires fixes imposent une taille minimale (10 SOL : toutes les positions à ~0,08 SOL,
aucune marge de variation ; 200 SOL : 0,35 à 0,48 % de l'équité selon le signal).

**Phase de test uniquement** : aucun code ne crée, ne signe ni n'envoie de transaction réelle, ni ne demande de clé privée. Le test
`NoRealTradingGuardTest` scrute tout le code et **échoue** si ça change ; `make_executor(mode="live")` et `JupiterExecutor()` lèvent
`LiveTradingDisabled`.

## Source de signaux rapide : GMGN (clé personnelle)

Axiom n'a pas d'API publique ; **GMGN en a une, officielle** (`gmgn-cli`) : trades des smart money et des KOL, nouveaux tokens
filtrés, sécurité, analyse des bundles. C'est beaucoup plus rapide que le sondage RPC de 2 minutes.

```bash
npm install -g gmgn-cli                       # + clé API sur https://gmgn.ai/ai (réseau IPv4 uniquement)
export GMGN_API_KEY=...                       # source = "auto" : GMGN utilisé dès que la clé existe
python validate_sources.py                    # ligne « GMGN (flux smart money) » : champs prix/horodatage présents ?
```
⚠ **Non testé contre le vrai service** (pas d'internet dans mon environnement) : les noms de champs viennent de la documentation
publique et de descriptions tierces. Si `validate_sources.py` signale ⚠️ ou ❌, envoie-moi sa sortie. Limite connue :
GMGN ne donne pas l'origine des fonds des wallets, donc leur indépendance n'est pas vérifiable.

**Filtre anti-« arroseurs »** (`max_tokens_per_wallet_per_hour = 12`) : sur les données réelles d'un ancien bot, 2 des 4 wallets suivis
avaient acheté 86 % de tous les tokens ; les suivre faisait perdre −22 % par trade et leur « convergence » n'apportait rien. Un wallet qui
achète trop de tokens différents en une heure n'est plus compté comme signal. Seuil à calibrer sur tes données.

## Savoir si le bot « s'est trompé » : `python main.py review`

Pour chaque coin détecté, le bot suit le prix à +1 h et +6 h, même quand il a rejeté le coin. `review` affiche une
ligne par coin : décision, mouvement ensuite, verdict (✅ bonne entrée, ❌ erreur, ✅ bon rejet, ⚠️ occasion manquée,
🛡️ rejet de sécurité), et le résultat réalisé si une position a été prise. Les rejets de sécurité (honeypot, mint
actif, RugCheck danger) ne comptent pas comme occasions manquées : un honeypot qui « monte » est le piège.
**Un coin n'apparaît qu'après un signal** : le déclencheur est l'achat par au moins 3 groupes de wallets suivis
indépendants (voir `wallets.txt`), PAS la lecture du site Axiom (qui n'a pas d'API). Avec un `wallets.txt` vide, le bot
ne détecte rien.

Procédure réelle :
1. remplis `wallets.txt` (5 à 15 adresses copiées d'Axiom Tracker ou J7, ou via `j7_sync.py`) ;
2. `python validate_sources.py` : plus aucun ❌ ;
3. `python main.py live -v` pendant 24 à 48 h (les résultats à +6 h n'arrivent que 6 h après chaque signal) ;
4. `python main.py review --db journal.db`, puis `report` et `gate`.

## Avant le premier lancement live : `validate_sources.py`

Rien de ce qui touche au réseau n'a pu être exécuté dans mon environnement. Lance donc ceci chez toi :

```bash
export HELIUS_API_KEY=...  JUPITER_API_KEY=...     # Windows : set HELIUS_API_KEY=...
python validate_sources.py --wallet UNE_ADRESSE_DE_TON_wallets.txt
```
Il teste DexScreener, RugCheck, la lecture on-chain du mint, les cotations Jupiter (aller-retour mesuré) et la lecture
des transactions d'un wallet, puis affiche la **forme** des réponses (clés et types, jamais de valeurs ni de clés API).
Si une ligne est ❌ ou ⚠️, envoie-moi la sortie complète : je corrigerai d'après les vraies réponses.
Tant qu'il reste un ❌, ne lance pas `python main.py live`.

Au démarrage du live : **verrou d'instance unique** (`journal.db.lock`, deux bots sur le même journal sont refusés),
**alertes Telegram** optionnelles (`TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` : entrées, sorties, entrées bloquées,
position sans prix, sources dégradées ; le token est masqué dans tous les logs).

## Lancer en live (paper trading) quand tu es prêt

```bash
export HELIUS_API_KEY=...        # clé gratuite dashboard.helius.dev (ne la partage jamais)
export JUPITER_API_KEY=...       # clé gratuite portal.jup.ag
python main.py live -v
```
Il faut un `wallets.txt` rempli (à la main ou via `j7_sync.py`, voir plus bas). Premier lancement : surveille les
logs, et vérifie que les décisions affichées sont cohérentes avec ce que tu vois sur DexScreener/RugCheck.

## Règles avant d'envisager de l'argent réel

- au moins 200 trades simulés, plusieurs semaines, résultat **positif net de frais** (profit factor > 1,3, drawdown acceptable) ;
- les tokens rejetés ne doivent pas faire mieux que les acceptés ;
- wallet dédié avec un petit solde, jamais ton wallet principal ; aucune clé privée dans le code.

## J7Tracker : `j7_sync.py`

Met à jour `wallets.txt` depuis ta page J7 (session de navigateur, aucun mot de passe). Voir l'en-tête du fichier :

```bash
pip install playwright && playwright install chromium
python j7_sync.py --login --url "URL_DE_TA_PAGE_J7"
python j7_sync.py --once --dry-run --show-browser --url "URL_DE_TA_PAGE_J7"
python j7_sync.py --interval 10 --verify-rpc "https://api.mainnet-beta.solana.com" --url "URL_DE_TA_PAGE_J7"
```
Le bot ignore automatiquement les wallets `source=j7` si `j7_sync_status.json` a plus de 2 h.
Astuce : ajoute à la main `cluster=NOM` aux wallets que tu sais liés entre eux.

## Structure

```
main.py            commandes : gen-sample, replay, live, report, gate
validate_sources.py  vérifie les vrais services avant le premier live
config.toml        réglages
bot/               engine, convergence, filters, scoring, risk, paper, report, market, safety, wallets...
bot/sources/       rpc_poll.py (live) ; replay via ReplayMarket
tests/test_core.py (106) + tests/test_discovery.py (45)
config.microcap.toml frictions mesurées sur un vrai bot (aller-retour ~18 %)
bot/alerts.py (Telegram), bot/lock.py (instance unique), bot/health.py (disjoncteur)
bot/costs.py         estimation du coût aller-retour ; bot/gate.py : porte de promotion ; bot/fingerprint.py ; bot/execution_policy.py
ANALYSE_REAL_BOT.md   pourquoi un bot réel a perdu, et ce qui en a été tiré
j7_sync.py         synchronisation de wallets.txt depuis J7Tracker
```
