#!/usr/bin/env python3
"""
j7_sync.py - Synchronise wallets.txt avec la liste de wallets affichée sur J7Tracker.

Principe : un navigateur (Playwright) ouvre la page J7 où TES wallets sont listés,
avec ta session déjà connectée, puis on extrait toutes les adresses Solana valides.
Aucun mot de passe ni clé privée n'est jamais utilisé par ce script.

Usage :
    python j7_sync.py --login --url <page_j7_avec_tes_wallets>   # 1re fois : tu te connectes
    python j7_sync.py --once  --url <page_j7_avec_tes_wallets>   # une synchro
    python j7_sync.py --interval 10 --url <...>                  # toutes les 10 minutes
    python j7_sync.py --selftest                                 # test local sans réseau
"""
import argparse
import json
import logging
import os
import re
import sys
import tempfile
import time
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

log = logging.getLogger("j7_sync")

# --------------------------------------------------------------------------
# Adresses Solana : validation base58 (32 octets) + filtres anti-faux-positifs
# --------------------------------------------------------------------------
B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
B58_MAP = {c: i for i, c in enumerate(B58)}
ADDR_RE = re.compile(r"(?<![1-9A-HJ-NP-Za-km-z])[1-9A-HJ-NP-Za-km-z]{32,44}(?![1-9A-HJ-NP-Za-km-z])")

SYSTEM_PROGRAM = "11111111111111111111111111111111"
# Programmes / mints très courants qui ne sont pas des wallets de traders
KNOWN_NON_WALLETS = {
    SYSTEM_PROGRAM,
    "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",   # Token program
    "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb",   # Token-2022
    "So11111111111111111111111111111111111111112",   # wSOL
    "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",  # USDC
    "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB",  # USDT
    "ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL",  # Associated token program
    "MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr",   # Memo
    "ComputeBudget111111111111111111111111111111",
    "JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4",   # Jupiter v6
    "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8",  # Raydium AMM
    "6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P",   # pump.fun
}


def is_solana_address(s: str) -> bool:
    """Vrai si s est du base58 qui décode exactement en 32 octets."""
    try:
        n = 0
        for c in s:
            n = n * 58 + B58_MAP[c]
    except KeyError:
        return False
    body = n.to_bytes((n.bit_length() + 7) // 8, "big") if n else b""
    pad = len(s) - len(s.lstrip("1"))
    return pad + len(body) == 32


def extract_addresses(text: str) -> set:
    found = set()
    for m in ADDR_RE.findall(text):
        if m in KNOWN_NON_WALLETS:
            continue
        if m.endswith("pump"):  # mints pump.fun = token, pas wallet
            continue
        if is_solana_address(m):
            found.add(m)
    return found


# --------------------------------------------------------------------------
# Vérification optionnelle via RPC : on écarte ce qui n'est pas un wallet
# --------------------------------------------------------------------------
def filter_wallets_via_rpc(addresses, rpc_url):
    """Garde les comptes détenus par le System Program (vrais wallets) ou inexistants.
    Écarte mints, comptes de token, pools, programmes."""
    addrs = sorted(addresses)
    kept = set()
    for i in range(0, len(addrs), 100):
        batch = addrs[i:i + 100]
        payload = json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "getMultipleAccounts",
            "params": [batch, {"encoding": "base64", "dataSlice": {"offset": 0, "length": 0}}],
        }).encode()
        req = urllib.request.Request(rpc_url, payload, {"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=20) as r:
            values = json.load(r)["result"]["value"]
        for a, v in zip(batch, values):
            if v is None or v.get("owner") == SYSTEM_PROGRAM:
                kept.add(a)
    return kept


# --------------------------------------------------------------------------
# Lecture de la page J7 avec Playwright (session persistante)
# --------------------------------------------------------------------------
def _grab(page, selector):
    if selector:
        return page.locator(selector).evaluate_all("els => els.map(e => e.outerHTML).join('\\n')")
    return page.content()


def scrape_page(url, profile_dir, headless, selector, scrolls, wait_ms):
    from playwright.sync_api import sync_playwright  # import tardif : pas requis pour --selftest

    chunks = []
    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(
            str(profile_dir), headless=headless, viewport={"width": 1400, "height": 900}
        )
        try:
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            page.goto(url, wait_until="domcontentloaded", timeout=60000)
            page.wait_for_timeout(wait_ms)
            # Les longues listes sont souvent "virtualisées" : on capture à chaque défilement
            for _ in range(scrolls):
                chunks.append(_grab(page, selector))
                page.mouse.wheel(0, 2500)
                page.wait_for_timeout(700)
            chunks.append(_grab(page, selector))
        finally:
            ctx.close()
    return "\n".join(chunks)


def interactive_login(url, profile_dir):
    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(str(profile_dir), headless=False)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.goto(url)
        input("Connecte-toi à J7Tracker dans la fenêtre, ouvre la page de tes wallets, "
              "puis appuie sur Entrée ici... ")
        ctx.close()
    log.info("Session enregistrée dans %s", profile_dir)


# --------------------------------------------------------------------------
# Fusion avec wallets.txt (les lignes manuelles ne sont jamais modifiées)
# --------------------------------------------------------------------------
TAG_RE = re.compile(r"(\w+)=(\S+)")
HEADER = (
    "# wallets.txt - une adresse par ligne.\n"
    "# Lignes sans 'source=j7' : ajoutées à la main, jamais modifiées par le script.\n"
    "# Lignes 'source=j7' : gérées automatiquement par j7_sync.py.\n"
)


def parse_lines(lines):
    entries = []
    for raw in lines:
        s = raw.rstrip("\n")
        body, _, comment = s.partition("#")
        addr = body.strip()
        if not addr:
            entries.append({"raw": s, "addr": None})
            continue
        entries.append({"raw": s, "addr": addr, "tags": dict(TAG_RE.findall(comment))})
    return entries


def merge(existing_lines, found, today, grace_days):
    """Retourne (nouvelles_lignes, ajoutés, retirés)."""
    entries = parse_lines(existing_lines)
    present = {e["addr"] for e in entries if e["addr"]}
    out, added, removed = [], [], []
    for e in entries:
        if not e["addr"] or e["tags"].get("source") != "j7":
            out.append(e["raw"])  # commentaire, ligne vide ou wallet manuel : intact
            continue
        a, first = e["addr"], e["tags"].get("first_seen", today.isoformat())
        if a in found:
            out.append(f"{a}  # source=j7 first_seen={first} last_seen={today.isoformat()}")
            continue
        try:
            last = datetime.fromisoformat(e["tags"].get("last_seen", first)).date()
        except ValueError:
            last = today
        if (today - last) > timedelta(days=grace_days):
            removed.append(a)
        else:
            out.append(e["raw"])  # absent récemment : on garde pendant le délai de grâce
    for a in sorted(found - present):
        out.append(f"{a}  # source=j7 first_seen={today.isoformat()} last_seen={today.isoformat()}")
        added.append(a)
    return out, added, removed


def atomic_write(path: Path, content: str):
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=".wallets_", suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(content)
    os.replace(tmp, path)


def write_status(path: Path, **kw):
    data = {}
    if path.exists():
        try:
            data = json.loads(path.read_text())
        except json.JSONDecodeError:
            pass
    data.update(kw)
    path.write_text(json.dumps(data, indent=2))


# --------------------------------------------------------------------------
# Une synchronisation complète
# --------------------------------------------------------------------------
def sync_once(args):
    out_path = Path(args.output)
    status_path = out_path.with_name("j7_sync_status.json")
    now = datetime.now(timezone.utc)
    try:
        text = scrape_page(args.url, args.profile, not args.show_browser,
                           args.selector, args.scrolls, args.wait_ms)
        found = extract_addresses(text)
        if args.verify_rpc and found:
            found = filter_wallets_via_rpc(found, args.verify_rpc)

        existing = out_path.read_text(encoding="utf-8").splitlines() if out_path.exists() else HEADER.splitlines()
        prev_j7 = sum(1 for e in parse_lines(existing) if e["addr"] and e["tags"].get("source") == "j7")

        # Garde-fous : page vide / non connecté / design changé => on ne touche à rien
        if not found:
            raise RuntimeError("0 adresse trouvée (non connecté ? mauvaise page ? design changé ?)")
        if prev_j7 >= 5 and len(found) < prev_j7 * 0.5 and not args.force:
            raise RuntimeError(f"chute suspecte : {len(found)} trouvées contre {prev_j7} connues "
                               "(utilise --force si c'est voulu)")

        new_lines, added, removed = merge(existing, found, now.date(), args.grace_days)
        if args.dry_run:
            log.info("[dry-run] +%d -%d (%d trouvées)", len(added), len(removed), len(found))
        else:
            atomic_write(out_path, "\n".join(new_lines) + "\n")
            log.info("OK : %d trouvées, +%d ajoutées, -%d retirées", len(found), len(added), len(removed))
            write_status(status_path, last_success=now.isoformat(), found=len(found),
                         added=len(added), removed=len(removed), last_error=None)
        return True
    except Exception as e:  # noqa: BLE001
        log.error("Synchro échouée, wallets.txt NON modifié : %s", e)
        write_status(status_path, last_error=str(e), last_error_at=now.isoformat())
        return False


# --------------------------------------------------------------------------
# Auto-test (sans réseau ni navigateur)
# --------------------------------------------------------------------------
def selftest():
    w1 = "9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM"
    w2 = "DfMxre4cKmvogbLrPigxmibVTTQDuzjdXojWzjCXXhzj"
    html = f"""<a href="/wallet/{w1}">{w1}</a> <td>{w2}</td>
               <span>{SYSTEM_PROGRAM}</span><span>EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v</span>
               <span>7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU</span>
               <span>{'A' * 40}</span><span>Gh9ZwEmdLJ8DscKNTkTqPbNwLNNBjuSzaG9Vp2KGtKJr</span>
               <span>{'1' * 5}abcpump</span>"""
    found = extract_addresses(html)
    assert w1 in found and w2 in found, found
    assert SYSTEM_PROGRAM not in found
    assert not any(a.endswith("pump") for a in found)
    assert not any(set(a) == {"A"} for a in found)

    today = datetime(2026, 10, 12).date()
    lines = HEADER.splitlines() + [
        "MANUAL1111111111111111111111111111111111111  # copie perso",
        f"{w1}  # source=j7 first_seen=2026-10-01 last_seen=2026-10-11",
        "OLDwallet1111111111111111111111111111111111  # source=j7 first_seen=2026-09-01 last_seen=2026-09-20",
        "RECENT111111111111111111111111111111111111  # source=j7 first_seen=2026-10-05 last_seen=2026-10-11",
    ]
    out, added, removed = merge(lines, {w1, w2}, today, grace_days=3)
    txt = "\n".join(out)
    assert "MANUAL1111" in txt                      # manuel conservé
    assert f"{w1}  # source=j7 first_seen=2026-10-01 last_seen=2026-10-12" in txt  # mis à jour
    assert "OLDwallet" not in txt and "OLDwallet1111111111111111111111111111111111" in removed
    assert "RECENT1111" in txt                      # délai de grâce
    assert w2 in added
    print("selftest OK :", len(found), "adresses valides extraites ; fusion correcte")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--url", default="https://j7tracker.io",
                    help="page J7 qui affiche TES wallets (important !)")
    ap.add_argument("--output", default="wallets.txt")
    ap.add_argument("--profile", default="./browser_profile", help="dossier de session navigateur")
    ap.add_argument("--selector", default=None, help="sélecteur CSS du conteneur de la liste (optionnel)")
    ap.add_argument("--login", action="store_true", help="ouvre un navigateur pour te connecter")
    ap.add_argument("--once", action="store_true", help="une seule synchro puis quitter")
    ap.add_argument("--interval", type=int, default=10, help="minutes entre deux synchros")
    ap.add_argument("--grace-days", type=int, default=3, help="jours avant de retirer un wallet disparu")
    ap.add_argument("--scrolls", type=int, default=8)
    ap.add_argument("--wait-ms", type=int, default=4000)
    ap.add_argument("--verify-rpc", default=None, help="URL RPC Solana pour écarter mints/pools")
    ap.add_argument("--show-browser", action="store_true", help="affiche le navigateur (debug)")
    ap.add_argument("--dry-run", action="store_true", help="n'écrit rien")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    if args.selftest:
        return selftest()
    if args.login:
        return interactive_login(args.url, args.profile)
    if args.once:
        sys.exit(0 if sync_once(args) else 1)
    while True:
        sync_once(args)
        time.sleep(args.interval * 60)


if __name__ == "__main__":
    main()
