"""PaperExecutor : exécution SIMULÉE au prix réel du marché, avec latence, impact de prix, frais, pourboire et échecs."""
import random

from ..models import Position
from .base import Executor


class PaperExecutor(Executor):
    mode = "paper"

    def __init__(self, cfg, market, start_sol):
        self.s = cfg.sim
        self.market = market
        self.cash = float(start_sol)
        self.rng = random.Random(self.s.seed)
        self._next_id = 1

    def _impact(self, value_sol, liq_usd):
        # pool à produit constant : impact ~ 2 x taille / liquidité totale
        return min(0.95, 2.0 * value_sol * self.market.sol_usd / liq_usd)

    def buy(self, mint, symbol, size_sol, ts, wallets):
        s = self.s
        if self.rng.random() < s.tx_fail_prob:
            return None, "tx_failed"
        t = ts + s.latency_s
        price, liq = self.market.price_at(mint, t), self.market.liquidity_usd_at(mint, t)
        if not price or not liq:
            return None, "no_market_data"
        if size_sol > self.cash:
            return None, "insufficient_cash"
        fill = price * (1 + self._impact(size_sol, liq) + s.base_slippage_bps / 1e4)
        net = size_sol - size_sol * s.fee_pct / 100 - s.tip_sol
        if net <= 0:
            return None, "size_below_costs"
        tokens = net / fill
        self.cash -= size_sol
        pos = Position(id=self._next_id, mint=mint, symbol=symbol, open_ts=ts, entry_price=fill,
                       tokens_initial=tokens, tokens_remaining=tokens, cost_sol=size_sol,
                       entry_liquidity_usd=liq, wallets=list(wallets), peak_price=fill, trough_price=fill)
        self._next_id += 1
        return pos, "ok"

    def sell(self, pos, fraction, ts):
        s = self.s
        if self.rng.random() < s.tx_fail_prob:
            return False, 0.0, None
        t = ts + s.latency_s
        price, liq = self.market.price_at(pos.mint, t), self.market.liquidity_usd_at(pos.mint, t)
        if not price or not liq:
            return False, 0.0, None
        tokens = pos.tokens_remaining * fraction
        imp = self._impact(tokens * price, liq)
        fill = price * max(0.0, 1 - imp - s.base_slippage_bps * s.sell_slippage_mult / 1e4)
        gross = tokens * fill
        proceeds = max(0.0, gross - gross * s.fee_pct / 100 - s.tip_sol)
        pos.tokens_remaining -= tokens
        pos.proceeds_sol += proceeds
        self.cash += proceeds
        if pos.tokens_remaining <= 1e-12:
            pos.tokens_remaining, pos.closed = 0.0, True
        return True, proceeds, fill

    def equity(self, ts, positions):
        """Équité PRUDENTE : positions ouvertes valorisées nettes d'impact, slippage, frais et pourboire de sortie."""
        total = self.cash
        for p in positions:
            price, liq = self.market.price_at(p.mint, ts), self.market.liquidity_usd_at(p.mint, ts)
            if price and liq and p.tokens_remaining > 0:
                v = p.tokens_remaining * price
                s = self.s
                net = v * (1 - self._impact(v, liq) - s.base_slippage_bps * s.sell_slippage_mult / 1e4)
                total += max(0.0, net * (1 - s.fee_pct / 100) - s.tip_sol)
        return total


PaperBroker = PaperExecutor      # ancien nom, conservé pour la compatibilité
