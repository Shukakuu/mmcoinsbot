"""Interface UNIQUE d'exécution. Le moteur de décision ne connaît que cette interface : simulation aujourd'hui,
réel demain, sans réécrire la logique de décision.

PHASE ACTUELLE = TEST UNIQUEMENT : aucune implémentation de ce projet ne crée, ne signe ni n'envoie de transaction
réelle, et aucune ne demande de clé privée. Un test automatique (tests/test_core.py::NoRealTradingGuardTest)
scrute le code et échoue si ça change."""
from abc import ABC, abstractmethod


class LiveTradingDisabled(RuntimeError):
    """Levée dès qu'on tente d'utiliser l'exécution réelle pendant la phase de test."""


class Executor(ABC):
    mode = "abstract"
    cash = 0.0
    _next_id = 1

    def export_state(self):
        """État à sauvegarder pour un redémarrage (cash, prochain identifiant)."""
        return {"cash": self.cash, "next_id": self._next_id}

    def import_state(self, st):
        self.cash, self._next_id = st["cash"], st["next_id"]

    @abstractmethod
    def buy(self, mint, symbol, amount_sol, ts, wallets):
        """Achète pour amount_sol. Retourne (Position | None, raison)."""

    @abstractmethod
    def sell(self, pos, fraction, ts):
        """Vend `fraction` (0-1] de la position. Retourne (succès, SOL reçus, prix de remplissage | None)."""

    @abstractmethod
    def equity(self, ts, positions):
        """Équité prudente (cash + positions valorisées nettes des coûts de sortie)."""
