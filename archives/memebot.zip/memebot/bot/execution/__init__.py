from .base import Executor, LiveTradingDisabled
from .jupiter import JupiterExecutor
from .paper import PaperBroker, PaperExecutor


def make_executor(cfg, market, mode="paper"):
    """Seul le mode 'paper' est autorisé dans cette phase."""
    if mode != "paper":
        raise LiveTradingDisabled(f"mode '{mode}' refusé : phase de TEST uniquement.")
    return PaperExecutor(cfg, market, cfg.capital.start_sol)


__all__ = ["Executor", "LiveTradingDisabled", "JupiterExecutor", "PaperExecutor", "PaperBroker", "make_executor"]
