"""JupiterExecutor : emplacement RÉSERVÉ pour l'exécution réelle (Jupiter + Jito, wallet dédié).

Volontairement NON IMPLÉMENTÉ et NON INSTANCIABLE pendant la phase de test : il ne contient aucun code de
construction, de signature ni d'envoi de transaction, et ne demande aucune clé. Le jour où le rapport de paper
trading aura passé la porte de promotion (`python main.py gate`), l'implémenter ici, derrière la même interface
`Executor`, avec les règles de bot/execution_policy.py (plafonds de slippage, position « bloquée » + alerte)."""
from .base import Executor, LiveTradingDisabled

MESSAGE = ("Exécution réelle désactivée : phase de TEST uniquement. Aucune transaction n'est créée, signée ni "
           "envoyée, et aucune clé n'est demandée. Voir bot/execution/jupiter.py.")


class JupiterExecutor(Executor):
    mode = "live-disabled"

    def __init__(self, *args, **kwargs):
        raise LiveTradingDisabled(MESSAGE)

    def buy(self, mint, symbol, amount_sol, ts, wallets):
        raise LiveTradingDisabled(MESSAGE)

    def sell(self, pos, fraction, ts):
        raise LiveTradingDisabled(MESSAGE)

    def equity(self, ts, positions):
        raise LiveTradingDisabled(MESSAGE)
