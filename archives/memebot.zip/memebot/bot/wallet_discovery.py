"""Découverte automatique de wallets : trouve, évalue et entretient seul la liste des wallets à suivre.

Source : Helius (HELIUS_API_KEY en variable d'environnement, jamais dans le code) ou, en option, le RPC public (lent).
LECTURE SEULE : une liste blanche de 3 méthodes RPC de lecture ; aucune clé privée, aucune transaction.
Sans clé ni RPC : le module se désactive avec un message clair et le reste du scout continue sans lui.

Pipeline (résumable, un « travail » à la fois, borné par un budget de crédits persistant) :
  token qui a bien performé (tableau `watch`) -> pool DexScreener -> signatures du pool jusqu'au début de son histoire
  -> acheteurs des premières minutes (= candidats « pending ») -> historique de chaque candidat -> métriques -> score
  -> testing (poids débutant faible) -> promotion / dégradation / retrait selon ses signaux.

⚠ Biais connu : les candidats sont des acheteurs précoces de tokens qui ont réussi (biais du survivant). Seuls l'historique
RÉALISÉ du wallet et le test réel de ses signaux (poids débutant) limitent ce biais ; ils ne le suppriment pas.
⚠ Hypothèse de coût : 1 crédit par appel RPC (credits_per_call), à confirmer sur ton plan Helius."""
import logging
import os
import time
from datetime import datetime, timezone

from .http import HttpError, RateLimiter, post_json
from .sources.dexscreener import pair_fields
from .sources.rpc_poll import parse_swap
from .wallet_scoring import Verdict, compute_metrics, score_wallet

log = logging.getLogger("wallet_discovery")
ALLOWED_METHODS = {"getSignaturesForAddress", "getTransaction", "getAccountInfo"}     # lecture seule, rien d'autre
PUBLIC_RPC = "https://api.mainnet-beta.solana.com"


class BudgetExceeded(RuntimeError):
    pass


class ReadOnlyRpc:
    """RPC en lecture seule, throttlé, avec budget de crédits journalier et mensuel persistant."""

    def __init__(self, url, rps, journal, cfg, label="helius", now_fn=time.time, post=post_json):
        self.url, self.j, self.d, self.label, self.now, self.post = url, journal, cfg.discovery, label, now_fn, post
        self.limiter = RateLimiter(rps)
        self.daily_cap = int(self.d.monthly_credit_budget / 30)

    def _state(self):
        t = self.now()
        day, month = int(t // 86400), datetime.fromtimestamp(t, timezone.utc).strftime("%Y-%m")
        st = self.j.kv_get("wd_credits", {"day": day, "day_used": 0, "month": month, "month_used": 0})
        if st["day"] != day:
            st["day"], st["day_used"] = day, 0
        if st["month"] != month:
            st["month"], st["month_used"] = month, 0
        return st

    def usage(self):
        st = self._state()
        return {"today": st["day_used"], "daily_cap": self.daily_cap, "month": st["month_used"],
                "monthly_budget": self.d.monthly_credit_budget}

    def remaining_today(self):
        u = self.usage()
        return max(0, min(u["daily_cap"] - u["today"], u["monthly_budget"] - u["month"]))

    def rpc(self, method, params):
        if method not in ALLOWED_METHODS:
            raise ValueError(f"méthode RPC non autorisée (lecture seule) : {method}")
        cost = self.d.credits_per_call
        st = self._state()
        if st["day_used"] + cost > self.daily_cap:
            raise BudgetExceeded(f"plafond journalier de crédits atteint ({st['day_used']}/{self.daily_cap})")
        if st["month_used"] + cost > self.d.monthly_credit_budget:
            raise BudgetExceeded(f"plafond mensuel de crédits atteint ({st['month_used']}/{self.d.monthly_credit_budget})")
        self.limiter.wait()
        st["day_used"] += cost
        st["month_used"] += cost
        self.j.kv_set("wd_credits", st)                      # on compte AVANT l'appel : un échec réseau consomme quand même
        r = self.post(self.url, {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
        if "error" in r:
            raise RuntimeError(f"RPC {method} : {str(r['error'])[:120]}")
        return r["result"]


def _signer(tx):
    k = tx["transaction"]["message"]["accountKeys"][0]
    return k["pubkey"] if isinstance(k, dict) else k


class WalletDiscovery:
    def __init__(self, cfg, journal, registry, rpc, dex, now_fn=time.time, enabled=True, why=""):
        self.cfg, self.j, self.reg, self.rpc, self.dex, self.now_fn = cfg, journal, registry, rpc, dex, now_fn
        self.d = cfg.discovery
        self.enabled, self.why = enabled, why
        self._warned = False

    @classmethod
    def from_env(cls, cfg, journal, registry, dex, public_rpc=False, post=post_json):
        """Helius si HELIUS_API_KEY existe ; sinon RPC public SI demandé (option) ; sinon module désactivé proprement."""
        d = cfg.discovery
        if not d.enabled:
            return cls(cfg, journal, registry, None, dex, enabled=False, why="désactivé dans la configuration")
        key = os.getenv("HELIUS_API_KEY")
        if key:
            rpc = ReadOnlyRpc(f"https://mainnet.helius-rpc.com/?api-key={key}", d.helius_rps, journal, cfg, "helius", post=post)
            return cls(cfg, journal, registry, rpc, dex)
        if public_rpc or d.public_rpc_fallback:
            rpc = ReadOnlyRpc(PUBLIC_RPC, d.public_rps, journal, cfg, "public", post=post)
            log.warning("Découverte de wallets via le RPC PUBLIC (lent, limité) : une clé Helius est recommandée.")
            return cls(cfg, journal, registry, rpc, dex)
        return cls(cfg, journal, registry, None, dex, enabled=False,
                   why="HELIUS_API_KEY absente et RPC public non activé (option --public-rpc) : le scout continue sans découverte de wallets")

    # ------------------------------------------------------------------ tokens candidats
    def creation_map(self):
        out = {m: v["created_ts"] for m, v in self.j.kv_get("wd_token_meta", {}).items() if v.get("created_ts")}
        import json
        for mint, det in self.j.c.execute("SELECT mint,detail FROM candidates"):
            try:
                ts = json.loads(det or "{}").get("pair_created_ts")
            except ValueError:
                ts = None
            if ts:
                out.setdefault(mint, ts)
        return out

    def next_token(self):
        done = set(self.j.kv_get("wd_tokens_done", {}))
        winners = [r[0] for r in self.j.c.execute(
            "SELECT mint FROM watch GROUP BY mint HAVING MAX(COALESCE(r_6h, r_1h)) >= 50 "
            "ORDER BY MAX(COALESCE(r_6h, r_1h)) DESC")]
        active = self.reg.active_addresses()
        from_wallets = []
        if active:
            q = ",".join("?" * len(active))
            from_wallets = [r[0] for r in self.j.c.execute(
                f"SELECT mint FROM events WHERE side='buy' AND wallet IN ({q}) GROUP BY mint ORDER BY MAX(ts) DESC LIMIT 50", active)]
        return next((m for m in winners + from_wallets if m not in done), None) or self.bootstrap_candidate()

    def bootstrap_candidate(self):
        """Amorçage d'une base VIERGE (le suivi à +6 h du scout n'a encore rien produit) : tokens du flux de découverte
        DexScreener qui ont pris au moins +100 % sur 24 h avec une liquidité suffisante. Gratuit (aucun crédit Helius).
        ⚠ Biais du survivant maximal : ce sont des gagnants connus après coup ; l'évaluation de l'historique réalisé de chaque
        acheteur et le test réel de ses signaux (poids débutant) servent justement à limiter ce biais."""
        st = self.j.kv_get("wd_bootstrap", {"ts": 0, "queue": []})
        now = self.now_fn()
        done = set(self.j.kv_get("wd_tokens_done", {}))
        remaining = [m for m in st["queue"] if m not in done]
        if not remaining and now - st["ts"] >= 6 * 3600:             # tout est traité : nouvel instantané, au plus toutes les 6 h
            st["ts"] = now
            try:
                feed = self.dex.discovery()
            except Exception as e:  # noqa: BLE001
                log.warning("amorçage : découverte indisponible (%s)", e)
                feed = []
            picked = []
            for c in feed[:30]:
                try:
                    pair = self.dex.pairs(c["mint"])
                except Exception:  # noqa: BLE001
                    continue
                f = pair_fields(pair, now) if pair else None
                if f and (f["price_change_h24_pct"] or 0) >= 100 and (f["liquidity_usd"] or 0) >= self.cfg.filters.min_liquidity_usd:
                    picked.append(c["mint"])
            st["queue"] = picked
            log.info("amorçage : %d token(s) gagnants sur 24 h retenus parmi %d", len(picked), len(feed[:30]))
        nxt = next((m for m in st["queue"] if m not in done), None)
        self.j.kv_set("wd_bootstrap", st)
        return nxt

    def _mark_done(self, mint, reason):
        done = self.j.kv_get("wd_tokens_done", {})
        done[mint] = reason
        self.j.kv_set("wd_tokens_done", done)

    def early_buyers(self, mint, pair, created_ts_hint=None):
        """Acheteurs des premières minutes d'un pool. None si le début de l'histoire est hors de portée (jamais deviné)."""
        sigs, before, complete = [], None, False
        for _ in range(self.d.max_sig_pages):
            opts = {"limit": 1000}
            if before:
                opts["before"] = before
            page = self.rpc.rpc("getSignaturesForAddress", [pair, opts])
            sigs += page
            if len(page) < 1000:
                complete = True
                break
            before = page[-1]["signature"]
        if not complete:
            return None, "history_too_long"
        ok = sorted((s for s in sigs if s.get("err") is None and s.get("blockTime")), key=lambda s: s["blockTime"])
        if not ok:
            return None, "no_history"
        t0 = ok[0]["blockTime"]
        early = [s for s in ok if s["blockTime"] <= t0 + self.d.early_window_min * 60][:self.d.early_txs_per_token]
        buyers = []
        for s in early:
            tx = self.rpc.rpc("getTransaction", [s["signature"], {"encoding": "jsonParsed", "maxSupportedTransactionVersion": 0}])
            if not tx:
                continue
            w = _signer(tx)
            p = parse_swap(tx, w)
            if p and p["side"] == "buy" and p["mint"] == mint and w not in buyers:
                buyers.append(w)
            if len(buyers) >= self.d.max_wallets_per_token:
                break
        return (buyers, t0), "ok"

    def process_token(self, mint):
        try:
            pair = self.dex.pairs(mint)
        except Exception as e:  # noqa: BLE001
            log.warning("paire DexScreener indisponible pour %s : %s", mint[:8], e)
            return f"token {mint[:8]} : paire indisponible (réessayé plus tard)"
        if not pair or not pair.get("pairAddress"):
            self._mark_done(mint, "no_pair")
            return f"token {mint[:8]} : aucune paire exploitable"
        meta = self.j.kv_get("wd_token_meta", {})
        meta[mint] = {"pair": pair["pairAddress"], "created_ts": (pair.get("pairCreatedAt") or 0) / 1000.0 or None}
        self.j.kv_set("wd_token_meta", meta)
        res, why = self.early_buyers(mint, pair["pairAddress"])
        if res is None:
            self._mark_done(mint, why)
            return f"token {mint[:8]} : écarté ({why}, historique irrécupérable : rien n'est deviné)"
        buyers, _t0 = res
        added = sum(1 for w in buyers if self.reg.add_pending(w, mint, self.now_fn()))
        self._mark_done(mint, f"ok:{len(buyers)}")
        return f"token {mint[:8]} : {len(buyers)} acheteurs précoces, {added} nouveaux candidats"

    # ------------------------------------------------------------------ évaluation d'un wallet
    def evaluate_wallet(self, addr):
        now = self.now_fn()
        sigs = self.rpc.rpc("getSignaturesForAddress", [addr, {"limit": 1000}])
        if not sigs:
            return Verdict("unknown", "no_history", None)
        times = [s["blockTime"] for s in sigs if s.get("blockTime")]
        if not times:
            return Verdict("unknown", "no_block_times", None)
        age_days, complete = (now - min(times)) / 86400.0, len(sigs) < 1000
        ok = [s for s in sigs if s.get("err") is None][:self.d.max_txs_per_wallet]
        events, failures = [], 0
        for s in ok:
            tx = self.rpc.rpc("getTransaction", [s["signature"], {"encoding": "jsonParsed", "maxSupportedTransactionVersion": 0}])
            if not tx:
                failures += 1
                continue
            p = parse_swap(tx, addr)
            if p and p["ts"]:
                from .models import WalletEvent
                events.append(WalletEvent(ts=p["ts"], wallet=addr, side=p["side"], mint=p["mint"],
                                          sol_amount=p["sol_amount"], token_amount=p["token_amount"], sig=p["sig"]))
        if ok and failures / len(ok) > 0.3:
            return Verdict("unknown", "history_unreadable", None)            # trop de transactions illisibles : rien n'est deviné
        if not events:
            return Verdict("unknown", "no_swaps_found", None, {"age_days": age_days})
        return score_wallet(compute_metrics(events, self.creation_map(), age_days, complete, self.d), self.d)

    # ------------------------------------------------------------------ boucle
    def _log_usage(self):
        u = self.rpc.usage()
        log.info("découverte de wallets : crédits %d/%d aujourd'hui, %d/%d ce mois", u["today"], u["daily_cap"],
                 u["month"], u["monthly_budget"])

    def step(self):
        """Un travail (évaluer un wallet OU traiter un token). None si rien à faire ou budget épuisé."""
        if not self.enabled:
            return None
        if self.rpc.remaining_today() <= 0:
            return None
        try:
            due = self.reg.due_for_eval(self.now_fn(), 1)
            if due:
                v = self.evaluate_wallet(due[0])
                self.reg.apply_verdict(due[0], v, self.now_fn())
                self._log_usage()
                return f"wallet {due[0][:8]}… : {v.status} ({v.reason}) score={v.score}"
            mint = self.next_token()
            if mint:
                msg = self.process_token(mint)
                self._log_usage()
                return msg
        except BudgetExceeded as e:
            log.info("découverte de wallets en pause : %s", e)
            return None
        except (HttpError, RuntimeError) as e:
            log.warning("découverte de wallets : erreur réseau/RPC (%s), réessai plus tard", e)
            return None
        return None

    def tick(self, now=None):
        """Appelé par le scout : passe quotidienne d'entretien + un travail de découverte par appel."""
        now = now or self.now_fn()
        events = []
        if now - self.j.kv_get("wd_last_maintenance", 0) >= 86400:
            events = self.reg.maintenance(now)
            self.j.kv_set("wd_last_maintenance", now)
            for a, action, why, old, new in events:
                log.info("wallet %s… %s (%s) : poids %.2f -> %.2f", a[:8], action, why, old, new)
        if not self.enabled:
            if not self._warned:
                self._warned = True
                log.warning("Découverte de wallets désactivée : %s", self.why)
            return events
        self.step()
        return events
