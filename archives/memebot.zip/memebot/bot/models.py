from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class WalletEvent:
    ts: float
    wallet: str
    side: str                      # "buy" | "sell"
    mint: str
    sol_amount: float
    token_amount: Optional[float] = None
    sig: str = ""

    @property
    def price_sol(self) -> Optional[float]:
        if self.token_amount and self.token_amount > 0:
            return self.sol_amount / self.token_amount
        return None


@dataclass
class TokenInfo:
    """Photo d'un token. None = INCONNU (le bot rejette quand une donnée critique est inconnue)."""
    mint: str
    symbol: str = ""
    price_sol: Optional[float] = None
    liquidity_usd: Optional[float] = None
    fdv_usd: Optional[float] = None
    pair_age_min: Optional[float] = None
    mint_authority_active: Optional[bool] = None
    freeze_authority_active: Optional[bool] = None
    top10_pct: Optional[float] = None
    rugcheck_levels: Optional[List[str]] = None
    rugcheck_risks: List[str] = field(default_factory=list)
    sell_quote_ok: Optional[bool] = None
    sell_impact_pct: Optional[float] = None
    roundtrip_cost_pct: Optional[float] = None   # coût aller-retour (mesuré en live si possible, sinon estimé)
    x_flags: Optional[List[str]] = None
    volume_h1_usd: Optional[float] = None
    buys_h1: Optional[int] = None
    sells_h1: Optional[int] = None
    price_change_h1_pct: Optional[float] = None
    price_change_m5_pct: Optional[float] = None


@dataclass
class Position:
    id: int
    mint: str
    symbol: str
    open_ts: float
    entry_price: float
    tokens_initial: float
    tokens_remaining: float
    cost_sol: float
    entry_liquidity_usd: float
    wallets: List[str]
    proceeds_sol: float = 0.0
    peak_price: float = 0.0
    tp1_done: bool = False
    closed: bool = False
    close_ts: Optional[float] = None
    exit_reason: str = ""
    decision_price: Optional[float] = None   # prix vu à la décision (pour mesurer le slippage d'entrée)
    blind_since: Optional[float] = None      # depuis quand on n'a plus de prix pour cette position
    trough_price: Optional[float] = None     # plus bas atteint (MAE)
    risk_sol: float = 0.0                    # perte visée si le stop s'exécute (pour le R-multiple)
    config_hash: str = ""                    # empreinte config+code au moment de l'entrée
    equity_at_entry: float = 0.0             # équité au moment de l'entrée (pour la distribution des tailles)

    @property
    def remaining_cost_sol(self) -> float:
        return self.cost_sol * (self.tokens_remaining / self.tokens_initial) if self.tokens_initial else 0.0
