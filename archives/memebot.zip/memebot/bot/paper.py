"""Compatibilité : l'exécution simulée vit maintenant dans bot/execution/."""
from .execution.paper import PaperBroker, PaperExecutor  # noqa: F401
