"""memebot : bot de trading de memecoins Solana, prudent, en simulation par défaut."""
