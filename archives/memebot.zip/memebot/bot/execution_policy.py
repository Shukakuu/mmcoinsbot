"""Règles d'exécution pour le futur courtier RÉEL (spécification testable, indépendante de la chaîne).
Tirées des défauts observés sur un bot réel : un slippage de vente qui s'élargissait à chaque échec jusqu'à 45 %
revenait à vendre n'importe où ; un trade a perdu la trace de 20 % de sa position."""

BUY_MAX_SLIPPAGE = 0.05      # 5 % : au-delà, on ne prend pas le trade
SELL_BASE_SLIPPAGE = 0.08
SELL_STEP = 0.04
SELL_HARD_CAP = 0.20         # JAMAIS plus : si ça ne passe pas à 20 %, on déclare la position "bloquée" et on alerte
MAX_SELL_ATTEMPTS = 4


def buy_min_out(expected_tokens, slippage=BUY_MAX_SLIPPAGE, price_ceiling_tokens=0):
    """Minimum de tokens accepté : slippage borné ET plancher imposé par le prix maximal décidé
    (la transaction devient impossible au-dessus du plafond, au lieu d'être seulement vérifiée avant)."""
    return max(int(expected_tokens * (1 - min(slippage, BUY_MAX_SLIPPAGE))), int(price_ceiling_tokens))


def sell_slippage_for_attempt(attempt, base=SELL_BASE_SLIPPAGE, step=SELL_STEP, cap=SELL_HARD_CAP):
    """attempt = 0 pour le premier essai. Élargissement plafonné."""
    return min(cap, base + step * attempt)


def next_sell_action(attempt):
    """'retry' tant qu'il reste des essais, sinon 'stuck' (alerte + intervention humaine)."""
    return "retry" if attempt + 1 < MAX_SELL_ATTEMPTS else "stuck"


def realized_vs_expected_gap(expected_eth, received_eth):
    """Écart en % entre le prix affiché et le produit réel d'une vente (à journaliser à chaque vente)."""
    return 100.0 * (1 - received_eth / expected_eth) if expected_eth else 0.0
