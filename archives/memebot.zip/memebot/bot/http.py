"""Petit client HTTP (bibliothèque standard uniquement) avec nouvelles tentatives et limiteur de débit."""
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from urllib.parse import urlparse

from .health import HEALTH


class HttpError(Exception):
    pass


_TOKEN_RE = re.compile(r"/bot\d+:[A-Za-z0-9_-]+")


def mask(url):
    """URL sans paramètres de requête (clés API Helius/Jupiter) et sans token Telegram, pour les messages d'erreur."""
    return _TOKEN_RE.sub("/bot<masqué>", url.split("?")[0])


def _request(url, data=None, headers=None, timeout=15, retries=2):
    hdrs = {"User-Agent": "memebot/0.1", "Accept": "application/json"}
    hdrs.update(headers or {})
    body = None
    if data is not None:
        body = json.dumps(data).encode()
        hdrs["Content-Type"] = "application/json"
    last = None
    svc = urlparse(url).netloc
    for i in range(retries + 1):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, body, hdrs), timeout=timeout) as r:
                out = json.load(r)
            HEALTH.ok(svc)
            return out
        except urllib.error.HTTPError as e:
            last = e
            if e.code in (429, 500, 502, 503, 504):
                if i < retries:
                    time.sleep(1.5 * (i + 1))
                    continue
                HEALTH.fail(svc)
            else:
                HEALTH.ok(svc)            # le serveur répond : ce n'est pas une panne
            raise HttpError(f"HTTP {e.code} sur {mask(url)}") from e
        except (urllib.error.URLError, TimeoutError) as e:
            last = e
            if i < retries:
                time.sleep(1.5 * (i + 1))
                continue
            HEALTH.fail(svc)
            raise HttpError(f"réseau ({mask(url)}) : {e}") from e
    raise HttpError(str(last))


def get_json(url, params=None, headers=None, **kw):
    if params:
        url += ("&" if "?" in url else "?") + urllib.parse.urlencode(params)
    return _request(url, headers=headers, **kw)


def post_json(url, data, headers=None, **kw):
    return _request(url, data=data, headers=headers, **kw)


class RateLimiter:
    def __init__(self, per_second):
        self.min_interval = 1.0 / per_second
        self._last = 0.0

    def wait(self):
        d = self.min_interval - (time.time() - self._last)
        if d > 0:
            time.sleep(d)
        self._last = time.time()
