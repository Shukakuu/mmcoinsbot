"""Sources de prix / infos token : ReplayMarket (tests hors-ligne) et LiveMarket (DexScreener + sécurité)."""
import bisect
import time

from .models import TokenInfo

WSOL = "So11111111111111111111111111111111111111112"


class ReplayMarket:
    """Rejoue un scénario JSON. Aucune donnée réseau."""

    REQUIRED = ("price_path", "fdv_usd", "pair_created_ts", "mint_authority_active",
                "freeze_authority_active", "rugcheck_levels", "sell_quote_ok")

    def __init__(self, data, validate=True, require_top10=False):
        self.sol_usd = float(data.get("sol_usd", 150.0))
        self.tokens = data["tokens"]
        if validate:
            self._validate(require_top10)
        self._ts = {m: [p[0] for p in t["price_path"]] for m, t in self.tokens.items()}

    def _validate(self, require_top10):
        """Un scénario incomplet désactiverait des filtres EN SILENCE : on refuse de démarrer."""
        errors = []
        for mint, t in self.tokens.items():
            miss = [k for k in self.REQUIRED if t.get(k) is None]
            if "liquidity_usd" not in t and "liquidity_path" not in t:
                miss.append("liquidity_usd|liquidity_path")
            if require_top10 and t.get("top10_pct") is None:
                miss.append("top10_pct")
            if miss:
                errors.append(f"{mint}: clés manquantes {miss}")
        if errors:
            raise ValueError("Scénario incomplet (filtres désactivés en silence sinon) :\n  " + "\n  ".join(errors))

    @staticmethod
    def _step(points, ts):
        keys = [p[0] for p in points]
        i = bisect.bisect_right(keys, ts) - 1
        return points[i][1] if i >= 0 else None

    def price_at(self, mint, ts):
        t = self.tokens.get(mint)
        if not t:
            return None
        i = bisect.bisect_right(self._ts[mint], ts) - 1
        return t["price_path"][i][1] if i >= 0 else None

    def liquidity_usd_at(self, mint, ts):
        t = self.tokens.get(mint)
        if not t:
            return None
        path = t.get("liquidity_path")
        return self._step(path, ts) if path else t.get("liquidity_usd")

    def info(self, mint, ts, size_sol):
        t = self.tokens[mint]
        price, liq = self.price_at(mint, ts), self.liquidity_usd_at(mint, ts)
        p0 = t["price_path"][0][1]
        impact = (2.0 * size_sol * self.sol_usd / liq * 100.0) if liq else None
        return TokenInfo(
            mint=mint, symbol=t.get("symbol", ""), price_sol=price, liquidity_usd=liq,
            fdv_usd=t["fdv_usd"] * price / p0 if price and t.get("fdv_usd") else None,
            pair_age_min=(ts - t["pair_created_ts"]) / 60.0 if t.get("pair_created_ts") else None,
            mint_authority_active=t.get("mint_authority_active"),
            freeze_authority_active=t.get("freeze_authority_active"),
            top10_pct=t.get("top10_pct"), rugcheck_levels=t.get("rugcheck_levels"),
            sell_quote_ok=t.get("sell_quote_ok"), sell_impact_pct=impact)


class LiveMarket:
    """Données réelles (DexScreener, route /token-pairs/v1/solana/{mint}). Format de cette route NON vérifié depuis mon
    environnement : à confirmer avec validate_sources.py."""

    def __init__(self, safety, cache_ttl=8.0, max_lag_s=150.0, client=None, model_exit=False):
        from .sources.dexscreener import DexClient
        self.client = client or DexClient()
        self.max_lag = max_lag_s
        self.safety = safety
        self.model_exit = model_exit     # True : impact/route de vente MODÉLISÉS (pas de cotation Jupiter)
        self.sol_usd = 150.0
        self.ttl = cache_ttl
        self._cache = {}

    def _pair(self, mint):
        c = self._cache.get(mint)
        if c and time.time() - c[0] < self.ttl:
            return c[1]
        best = self.client.pairs(mint)
        self._cache[mint] = (time.time(), best)
        if best and best.get("priceUsd") and best.get("priceNative"):
            self.sol_usd = float(best["priceUsd"]) / float(best["priceNative"])
        return best

    def _pair_safe(self, mint, ts):
        """En live on ne peut lire QUE le présent : une requête sur un instant plus ancien que max_lag renvoie None
        (inconnu) au lieu d'un prix actuel déguisé en prix passé. Une panne réseau renvoie aussi None : la gestion des
        positions ne doit jamais planter."""
        from .http import HttpError
        if ts is not None and ts < time.time() - self.max_lag:
            return None
        try:
            return self._pair(mint)
        except HttpError:
            return None

    def price_at(self, mint, ts=None):
        p = self._pair_safe(mint, ts)
        return float(p["priceNative"]) if p and p.get("priceNative") else None

    def liquidity_usd_at(self, mint, ts=None):
        p = self._pair_safe(mint, ts)
        return (p.get("liquidity") or {}).get("usd") if p else None

    def info(self, mint, ts, size_sol):
        from .sources.dexscreener import pair_fields
        p = self._pair(mint)
        info = TokenInfo(mint=mint)
        if p:
            f = pair_fields(p)
            for k in ("symbol", "price_sol", "liquidity_usd", "fdv_usd", "pair_age_min", "volume_h1_usd", "buys_h1",
                      "sells_h1", "price_change_h1_pct", "price_change_m5_pct"):
                setattr(info, k, f[k])
        self.safety.fill(info, size_sol)
        if self.model_exit and info.liquidity_usd and self.sol_usd:
            info.sell_impact_pct = 2.0 * size_sol * self.sol_usd / info.liquidity_usd * 100.0   # modèle produit constant
        return info
