"""Signal X (Twitter) : sert surtout de FILTRE DE REJET. Interface + versions de test.

La version live (API officielle X, payante à l'usage) n'est PAS encore écrite : elle viendra
après validation du cœur du bot. Voir README pour le budget.
"""


class NullX:
    def flags(self, mint, info):
        return []


class MockX:
    """Pour les tests / la simulation : flags prédéfinis par token."""
    def __init__(self, flags_by_mint):
        self.flags_by_mint = flags_by_mint

    def flags(self, mint, info):
        return list(self.flags_by_mint.get(mint, []))
