"""Alertes Telegram (optionnelles). Sans TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID : ne fait rien.
Le token ne doit JAMAIS apparaître dans un log (voir bot/http.py : masquage)."""
import logging
import os
import time

from .http import HttpError, post_json

log = logging.getLogger("alerts")


class Notifier:
    def __init__(self, token=None, chat_id=None):
        self.token = token or os.getenv("TELEGRAM_BOT_TOKEN")
        self.chat_id = chat_id or os.getenv("TELEGRAM_CHAT_ID")
        self._last = {}

    @property
    def enabled(self):
        return bool(self.token and self.chat_id)

    def send(self, text, key=None, min_interval=0.0):
        """key + min_interval : n'envoie pas deux fois la même alerte dans l'intervalle (anti-spam)."""
        now = time.time()
        if key is not None and now - self._last.get(key, -1e18) < min_interval:
            return False
        if key is not None:
            self._last[key] = now
        if not self.enabled:
            return False
        try:
            post_json(f"https://api.telegram.org/bot{self.token}/sendMessage",
                      {"chat_id": self.chat_id, "text": text[:3500]}, retries=1)
            return True
        except HttpError as e:
            log.warning("alerte non envoyée : %s", e)
            return False
