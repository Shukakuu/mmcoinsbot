"""Coût aller-retour ESTIMÉ d'un trade. C'est la leçon n°1 d'un bot réel qui a perdu : ses frictions
(~18 %) dépassaient son avantage. Ici, un trade dont le coût dépasse le plafond est REFUSÉ avant d'être pris."""


def estimate_roundtrip_cost_pct(cfg, size_sol, liquidity_usd, sol_usd):
    """Frais x2 + slippage de base + impact de pool des deux côtés + pourboires fixes (en % de la taille).
    Les pourboires fixes écrasent les petites positions : 0,006 SOL de pourboires = 6 % d'une position de 0,1 SOL."""
    s = cfg.sim
    if not size_sol or size_sol <= 0 or not liquidity_usd or not sol_usd:
        return 100.0
    impact_each_side = 2.0 * size_sol * sol_usd / liquidity_usd * 100.0
    fixed = 2.0 * s.tip_sol / size_sol * 100.0
    return 2.0 * s.fee_pct + s.base_slippage_bps * (1.0 + s.sell_slippage_mult) / 100.0 + 2.0 * impact_each_side + fixed
