"""Configuration : valeurs par défaut prudentes, surchargées par config.toml (Python 3.11+)."""
import copy
import tomllib
from pathlib import Path

DEFAULTS = {
    "capital": {"start_sol": 10.0},                      # capital SIMULÉ
    "risk": {
        "max_position_pct": 1.0,          # % de l'équité par trade
        "max_liquidity_share_pct": 0.5,   # taille max = 0,5 % de la liquidité du pool
        "min_position_sol": 0.01,
        "max_open_positions": 5,
        "max_total_exposure_pct": 10.0,
        "daily_loss_limit_pct": 3.0,      # stop du jour si perte réalisée >= 3 % de l'équité de départ du jour
        "max_consecutive_losses": 4,
        "cooldown_minutes": 60,
    },
    "sizing": {
        "min_strength": 0.3,              # le signal le plus faible qui passe mise 30 % du plafond ; le plus fort 100 %
        "no_wallet_factor": 0.7,          # sans signal de wallets (découverte seule) : taille réduite
    },
    "entry": {
        "min_wallets": 3,                 # clusters INDÉPENDANTS qui doivent acheter le même token
        "window_minutes": 15,
        "max_drift_pct": 25.0,            # on n'entre pas si le prix a déjà pris > 25 % depuis le 1er achat
        "min_score": 60.0,
        "refire_hours": 6,
        "max_tokens_per_wallet_per_hour": 12,   # un wallet qui achète >= 12 tokens DIFFÉRENTS par heure arrose : ses achats ne sont plus un signal
        "max_signal_age_s": 180,          # signal plus vieux que ça => on ne le copie pas (le prix a déjà bougé)
    },
    "filters": {
        "min_liquidity_usd": 20000,
        "min_fdv_usd": 100000,
        "max_fdv_usd": 20000000,
        "min_pair_age_min": 10,
        "max_pair_age_hours": 48,
        "max_sell_impact_pct": 3.0,
        "max_top10_pct": 40.0,
        "require_top10": False,
        "require_rugcheck": True,
        "block_rugcheck_levels": ["danger"],
        "max_roundtrip_cost_pct": 12.0,   # coût aller-retour estimé > 12 % => trade refusé (frais, slippage, impact, pourboires)
    },
    "exit": {
        "stop_loss_pct": 20.0,
        "take_profit_1_mult": 2.0,
        "take_profit_1_fraction": 0.5,
        "trailing_stop_pct": 25.0,        # trailing de base, actif après le TP1 (plancher = prix d'entrée)
        "trail_tiers": [[2.0, 25.0], [3.0, 18.0], [5.0, 14.0], [10.0, 10.0]],  # [multiple du pic, trailing %] : se resserre quand ça monte
        "breakeven_trigger_pct": 35.0,    # si le prix a pris +35 %, on ne laisse plus ce trade finir perdant
        "breakeven_floor_pct": 8.0,       # plancher au-dessus du prix d'entrée (couvre les frictions)
        "max_hold_hours": 12,
        "exit_on_wallet_sells": 2,
        "liquidity_drop_exit_pct": 50.0,  # sortie d'urgence si la liquidité chute de 50 %
    },
    "sim": {
        "latency_s": 2.0,
        "fee_pct": 1.0,
        "base_slippage_bps": 100,
        "sell_slippage_mult": 1.5,
        "tx_fail_prob": 0.08,
        "tip_sol": 0.003,
        "seed": 42,
        "tick_s": 60,
    },
    "gate": {"min_trades": 200, "min_p_positive": 0.90, "min_profit_factor": 1.3,
             "min_pf_without_top3": 1.0, "max_drawdown_pct": 15.0},
    "discovery": {                            # découverte automatique de wallets (python main.py discover-wallets)
        "enabled": True,
        "public_rpc_fallback": False,         # opt-in : RPC public (lent, limité) si HELIUS_API_KEY est absente
        "helius_rps": 10, "public_rps": 2,    # throttle (requêtes/s)
        "monthly_credit_budget": 30000,       # plafond mensuel de crédits pour CE module ; plafond jour = budget / 30
        "credits_per_call": 1,                # hypothèse : 1 crédit par appel RPC standard (à confirmer sur ton plan)
        "max_txs_per_wallet": 60,             # transactions lues par wallet évalué (les plus récentes)
        "max_sig_pages": 5,                   # pages de 1000 signatures pour retrouver le début d'un token
        "early_window_min": 30, "early_txs_per_token": 30, "max_wallets_per_token": 15, "tokens_per_pass": 5,
        "min_age_days": 14, "min_closed_trades": 5,
        "max_tokens_per_day": 12,             # au-delà : arroseur (aligné sur entry.max_tokens_per_wallet_per_hour)
        "sniper_window_s": 60, "sniper_share_max": 0.5,
        "min_score": 0.6,
        "starter_weight": 0.3, "max_weight": 1.5, "promote_step": 0.2,
        "degrade_after_losses": 3, "recent_window": 5,
        "reeval_excluded_days": 14, "reeval_unknown_days": 3,
    },
    "scout": {
        "discovery_interval_s": 90,       # un instantané des flux de découverte toutes les 90 s
        "tick_s": 20,
        "max_new_per_tick": 6,            # limite d'appels : respecte ~300 req/min de DexScreener
        "retry_after_min": 10,            # un token rejeté car trop récent est réexaminé une fois après 10 min
        "max_retries": 2,
        "pumpportal": False,              # suivi des wallets de wallets.txt via PumpPortal (optionnel, 5 max, nécessite `pip install websockets`)
        "pumpportal_max_keys": 5,
        "jsonl_path": "decisions.jsonl",
    },
    "health": {"max_consecutive_failures": 5, "blind_alert_s": 300},
    "x": {"enabled": False, "veto_flags": ["new_account", "bot_shill", "impersonation", "phishing_link"]},
    "wallets": {"path": "wallets.txt", "max_j7_age_min": 120, "enforce_j7_freshness": True},
    "live": {
        "source": "auto",                 # "gmgn" (clé GMGN_API_KEY + gmgn-cli), "rpc" (Helius) ou "auto" (gmgn si la clé existe)
        "chain": "sol",
        "gmgn_poll_interval_s": 15,
        "rpc_wallets_per_poll": 1,
        "wallet_poll_interval_s": 120,
        "max_rpc_calls_per_day": 30000,
        "rpc_rps": 5,
        "loop_sleep_s": 2,
    },
}


class Cfg(dict):
    """dict avec accès par attributs : cfg.risk.max_open_positions"""
    def __getattr__(self, k):
        try:
            v = self[k]
        except KeyError as e:
            raise AttributeError(k) from e
        return Cfg(v) if isinstance(v, dict) else v


def _merge(base, over):
    for k, v in over.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _merge(base[k], v)
        else:
            base[k] = v


def load_config(path=None) -> Cfg:
    cfg = copy.deepcopy(DEFAULTS)
    if path and Path(path).exists():
        with open(path, "rb") as f:
            _merge(cfg, tomllib.load(f))
    return Cfg(cfg)
