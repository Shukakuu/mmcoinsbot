"""Journal JSONL : une ligne JSON par événement (décision, entrée, sortie), lisible par n'importe quel outil."""
import json
from datetime import datetime, timezone


class JsonlLog:
    def __init__(self, path):
        self.path = path

    def write(self, **rec):
        ts = rec.get("ts")
        if ts is not None:
            rec["iso"] = datetime.fromtimestamp(ts, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
