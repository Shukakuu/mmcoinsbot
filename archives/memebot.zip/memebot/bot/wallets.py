"""Lecture de wallets.txt, grappes (clusters), poids des wallets selon leurs résultats réels."""
import json
import re
from datetime import datetime, timezone
from pathlib import Path

TAG_RE = re.compile(r"(\w+)=(\S+)")
PROBATION_TRADES = 5   # en dessous : poids neutre (on ne sait pas encore)


class WalletBook:
    def __init__(self, path, status_path=None, max_j7_age_min=120, enforce_j7_freshness=True, journal=None, registry=None):
        self.path = Path(path)
        self.status_path = Path(status_path) if status_path else self.path.with_name("j7_sync_status.json")
        self.max_j7_age_min = max_j7_age_min
        self.enforce = enforce_j7_freshness
        self.journal = journal
        self.registry = registry          # wallets découverts automatiquement (table `wallets`) ; wallets.txt reste possible
        self.wallets = {}           # addr -> {"source":..., "cluster":...}
        self.stats = journal.get_wallet_stats() if journal else {}
        self._open = {}             # (wallet, mint) -> [tokens, cost_sol]
        self.reload()

    def reload(self):
        """wallets.txt (s'il existe, rétrocompatible) + wallets suivis automatiquement (base). Le fichier est prioritaire :
        un wallet listé à la main garde sa source, son cluster et sa logique de poids."""
        dynamic = {a: m for a, m in self.wallets.items() if m.get("source") == "gmgn"}
        self.wallets = dict(dynamic)
        if self.path.exists():
            for line in self.path.read_text(encoding="utf-8").splitlines():
                body, _, comment = line.partition("#")
                addr = body.strip()
                if not addr:
                    continue
                tags = dict(TAG_RE.findall(comment))
                self.wallets[addr] = {"source": tags.get("source", "manual"), "cluster": tags.get("cluster", addr)}
        if self.registry:
            self.registry.refresh()
            for addr in self.registry.active_addresses():
                self.wallets.setdefault(addr, {"source": "auto", "cluster": addr})

    def register(self, addr, source="gmgn"):
        """Ajoute (en mémoire seulement) un wallet vu dans un flux externe. Chaque wallet inconnu est son propre cluster :
        GMGN ne fournit pas l'origine des fonds, donc l'indépendance supposée est une limite connue."""
        if addr not in self.wallets:
            self.wallets[addr] = {"source": source, "cluster": addr}

    # --- fraîcheur de la source J7 -------------------------------------------------
    def j7_fresh(self, now_ts=None):
        if not self.enforce:
            return True
        try:
            last = json.loads(self.status_path.read_text()).get("last_success")
            age = ((now_ts or datetime.now(timezone.utc).timestamp())
                   - datetime.fromisoformat(last).timestamp()) / 60.0
            return age <= self.max_j7_age_min
        except Exception:
            return False   # pas de statut = on ne fait pas confiance

    def active(self, now_ts=None):
        fresh = self.j7_fresh(now_ts)
        return {w for w, m in self.wallets.items() if m["source"] != "j7" or fresh}

    def cluster(self, wallet):
        return self.wallets.get(wallet, {}).get("cluster", wallet)

    # --- poids selon les résultats observés ------------------------------------------
    def weight(self, wallet):
        src = self.wallets.get(wallet, {}).get("source")
        if self.registry and src not in ("manual", "j7") and self.registry.known(wallet):
            return self.registry.weight(wallet)       # poids débutant / promu / dégradé ; 0 si exclu, inconnu ou retiré
        n, wins, s = self.stats.get(wallet, (0, 0, 0.0))
        if n < PROBATION_TRADES:
            return 1.0
        avg = s / n
        if avg <= 0:
            return 0.0      # wallet dont les résultats observés sont négatifs : ignoré
        return 1.0 + min(0.5, avg / 100.0)

    def observe(self, ev):
        """Suit les allers-retours de chaque wallet pour mesurer sa performance RÉELLE."""
        price = ev.price_sol
        if price is None or ev.token_amount is None:
            return
        key = (ev.wallet, ev.mint)
        if ev.side == "buy":
            pos = self._open.setdefault(key, [0.0, 0.0])
            pos[0] += ev.token_amount
            pos[1] += ev.sol_amount
        elif key in self._open and self._open[key][0] > 0:
            tokens, cost = self._open[key]
            frac = min(1.0, ev.token_amount / tokens)
            cost_part = cost * frac
            pnl_pct = 100.0 * (ev.sol_amount - cost_part) / cost_part if cost_part > 0 else 0.0
            self._open[key] = [tokens - ev.token_amount, cost - cost_part]
            if self._open[key][0] <= 1e-12:
                del self._open[key]
            n, wins, s = self.stats.get(ev.wallet, (0, 0, 0.0))
            self.stats[ev.wallet] = (n + 1, wins + (1 if pnl_pct > 0 else 0), s + pnl_pct)
            if self.journal:
                self.journal.upsert_wallet_stats(ev.wallet, *self.stats[ev.wallet])
