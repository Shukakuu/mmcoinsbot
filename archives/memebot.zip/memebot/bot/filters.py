"""Filtres ÉLIMINATOIRES. Règle : une donnée critique inconnue = rejet (fail closed)."""


def apply_filters(sig, info, drift_pct, cfg, signal_age_s=None):
    f, x = cfg.filters, cfg.x
    r = []

    def unknown(name):
        r.append(f"unknown:{name}")

    if info.mint_authority_active is None:
        unknown("mint_authority")
    elif info.mint_authority_active:
        r.append("mint_authority_active")
    if info.freeze_authority_active is None:
        unknown("freeze_authority")
    elif info.freeze_authority_active:
        r.append("freeze_authority_active")

    if info.liquidity_usd is None:
        unknown("liquidity")
    elif info.liquidity_usd < f.min_liquidity_usd:
        r.append("low_liquidity")

    if info.fdv_usd is not None:
        if info.fdv_usd < f.min_fdv_usd:
            r.append("fdv_too_low")
        elif info.fdv_usd > f.max_fdv_usd:
            r.append("fdv_too_high")

    if info.pair_age_min is None:
        unknown("pair_age")
    elif info.pair_age_min < f.min_pair_age_min:
        r.append("pair_too_new")
    elif info.pair_age_min > f.max_pair_age_hours * 60:
        r.append("pair_too_old")

    if info.sell_quote_ok is None:
        unknown("sell_route")
    elif not info.sell_quote_ok:
        r.append("no_sell_route(honeypot?)")
    if info.sell_impact_pct is None:
        unknown("sell_impact")
    elif info.sell_impact_pct > f.max_sell_impact_pct:
        r.append("high_sell_impact")

    if info.rugcheck_levels is None:
        if f.require_rugcheck:
            unknown("rugcheck")
    else:
        for lvl in f.block_rugcheck_levels:
            if lvl in info.rugcheck_levels:
                r.append(f"rugcheck_{lvl}")

    if info.roundtrip_cost_pct is not None and info.roundtrip_cost_pct > f.max_roundtrip_cost_pct:
        r.append("high_roundtrip_cost")

    if info.top10_pct is None:
        if f.require_top10:
            unknown("top10")
    elif info.top10_pct > f.max_top10_pct:
        r.append("top10_concentrated")

    if drift_pct is None:
        unknown("drift")          # sans prix de référence, impossible de savoir si on arrive après le pump
    elif drift_pct > cfg.entry.max_drift_pct:
        r.append("late_entry_drift")

    if signal_age_s is not None and signal_age_s > cfg.entry.max_signal_age_s:
        r.append("signal_too_old")

    for flag in (info.x_flags or []):
        if flag in x.veto_flags:
            r.append(f"x_veto:{flag}")
    return r
