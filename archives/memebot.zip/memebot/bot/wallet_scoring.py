"""Métriques et score d'un wallet, à partir de ses achats/ventes RÉELS (fonctions pures, sans réseau).

Règles de rigueur :
 - on ne compte que le P&L RÉALISÉ (achats appariés à des ventes), au coût moyen ;
 - une vente dont l'achat n'est pas dans l'historique lu est IGNORÉE (jamais de coût deviné) ;
 - historique insuffisant ou illisible => score INCONNU => wallet exclu (jamais de valeur devinée) ;
 - « premier acheteur systématique » (sniper / créateur probable) = PÉNALITÉ, jamais un bonus ;
 - le score est un réglage prudent, pas une preuve de talent : un wallet qui a eu de la chance sur un petit échantillon existe."""
from dataclasses import dataclass, field
from typing import Optional

CLOSED_SHARE = 0.8        # un trade est « clôturé » quand >= 80 % des tokens achetés ont été vendus
FULL_CONFIDENCE_TRADES = 15


@dataclass
class Verdict:
    status: str                 # "eligible" | "excluded" | "unknown"
    reason: str
    score: Optional[float]
    metrics: dict = field(default_factory=dict)
    components: dict = field(default_factory=dict)


def _clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def compute_metrics(events, creation_ts, age_days, age_complete, d):
    """events : WalletEvent (ts, side, mint, sol_amount, token_amount). creation_ts : {mint: ts de création connue}."""
    ev = sorted(events, key=lambda e: e.ts)
    pos, unmatched, sold_cost_total = {}, 0, 0.0
    for e in ev:
        p = pos.setdefault(e.mint, {"bought": 0.0, "tokens": 0.0, "cost": 0.0, "realized": 0.0, "sold": 0.0})
        if e.side == "buy":
            p["bought"] += e.token_amount or 0.0
            p["tokens"] += e.token_amount or 0.0
            p["cost"] += e.sol_amount
        else:
            if p["tokens"] <= 1e-12 or not e.token_amount:
                unmatched += 1                       # vente sans achat connu : coût inconnu => ignorée
                continue
            sold = min(e.token_amount, p["tokens"])
            cost_part = p["cost"] * (sold / p["tokens"])
            p["realized"] += e.sol_amount * (sold / e.token_amount) - cost_part
            p["cost"] -= cost_part
            p["tokens"] -= sold
            p["sold"] += sold
            sold_cost_total += cost_part
    closed = [p["realized"] for p in pos.values() if p["bought"] > 0 and p["sold"] >= CLOSED_SHARE * p["bought"]]
    realized = sum(p["realized"] for p in pos.values())
    wins = [x for x in closed if x > 0]
    buys = [e for e in ev if e.side == "buy"]
    span_days = max(((ev[-1].ts - ev[0].ts) / 86400.0) if ev else 0.0, 1.0)
    known = [e for e in buys if e.mint in creation_ts]
    sniper = (sum(1 for e in known if 0 <= e.ts - creation_ts[e.mint] <= d.sniper_window_s) / len(known)
              if len(known) >= 5 else None)
    return {
        "n_trades": len(ev), "n_closed": len(closed), "unmatched_sells": unmatched,
        "realized_pnl_sol": realized,
        "realized_return": (realized / sold_cost_total) if sold_cost_total > 0 else None,
        "win_rate": (len(wins) / len(closed)) if closed else None,
        "max_win_share": (max(wins) / sum(wins)) if wins else None,
        "tokens_per_day": len({e.mint for e in buys}) / span_days,
        "sniper_share": sniper, "age_days": age_days, "age_complete": bool(age_complete),
    }


def score_wallet(m, d):
    """Verdict d'un wallet à partir de ses métriques. Score normalisé 0-1."""
    if m["age_days"] is None:
        return Verdict("unknown", "age_unknown", None, m)
    if m["age_days"] < d.min_age_days:
        return Verdict("excluded", "too_young", None, m)
    if m["tokens_per_day"] > d.max_tokens_per_day:
        return Verdict("excluded", "sprayer", 0.0, m)
    if m["n_closed"] < d.min_closed_trades or m["realized_return"] is None or m["win_rate"] is None:
        return Verdict("unknown", "too_few_closed_trades", None, m)
    comp = {
        "pnl": _clamp((m["realized_return"] + 0.2) / 0.8),                       # -20 % -> 0 ; +60 % -> 1
        "regularity": _clamp(1.0 - (m["max_win_share"] or 1.0)),                 # gain porté par UN seul trade -> 0
        "win_rate": _clamp((m["win_rate"] - 0.3) / 0.4),                         # 30 % -> 0 ; 70 % -> 1
        "selectivity": 1.0 if m["tokens_per_day"] <= 4 else
        _clamp((d.max_tokens_per_day - m["tokens_per_day"]) / (d.max_tokens_per_day - 4)),
    }
    raw = 0.35 * comp["pnl"] + 0.25 * comp["regularity"] + 0.20 * comp["win_rate"] + 0.20 * comp["selectivity"]
    conf = min(1.0, m["n_closed"] / FULL_CONFIDENCE_TRADES)
    score = raw * (0.5 + 0.5 * conf)                                              # petit échantillon : score tiré vers le bas
    flags = []
    if m["sniper_share"] is not None and m["sniper_share"] >= d.sniper_share_max:
        score *= 0.3
        flags.append("sniper")
    elif m["sniper_share"] is None:
        score = min(score, 0.8)                                                   # création des tokens inconnue : confiance plafonnée
        flags.append("sniper_unknown")
    comp["confidence"] = conf
    score = round(score, 3)
    if score >= d.min_score:
        return Verdict("eligible", ",".join(flags) or "ok", score, m, comp)
    return Verdict("excluded", "sniper" if "sniper" in flags else "low_score", score, m, comp)
