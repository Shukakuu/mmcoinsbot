"""Empreinte (config + code) : chaque trade est étiqueté avec l'empreinte sous laquelle il a été pris.
Changer un réglage ou une ligne de code change l'empreinte => l'échantillon de validation repart de zéro.
(Un bot réel a été modifié ~10 fois en 5 jours en production : ses chiffres ne prouvaient plus rien.)"""
import hashlib
import json
from pathlib import Path


def fingerprint(cfg):
    h = hashlib.sha256()
    h.update(json.dumps(cfg, sort_keys=True, default=str).encode())
    for f in sorted(Path(__file__).parent.rglob("*.py")):
        h.update(f.name.encode())
        h.update(f.read_bytes())
    return h.hexdigest()[:12]
