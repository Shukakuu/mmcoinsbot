"""Rapport d'évaluation : l'objectif est de savoir si l'avantage existe VRAIMENT, frais compris."""
import json
import statistics
from collections import Counter


def _max_drawdown(start, pnls):
    eq = peak = start
    dd = 0.0
    for p in pnls:
        eq += p
        peak = max(peak, eq)
        dd = max(dd, (peak - eq) / peak * 100 if peak else 0)
    return dd


def wallets_section(journal):
    """Wallets suivis automatiquement : liste, scores, mouvements récents, consommation de crédits."""
    c = journal.c
    if not c.execute("SELECT COUNT(*) FROM wallets").fetchone()[0]:
        return []
    L = ["", "WALLETS SUIVIS AUTOMATIQUEMENT"]
    counts = dict(c.execute("SELECT status,COUNT(*) FROM wallets GROUP BY status"))
    L.append("  Statuts : " + ", ".join(f"{k}={v}" for k, v in sorted(counts.items())))
    rows = c.execute("SELECT address,status,score,weight,realized_pnl_sol,win_rate,tokens_per_day,signals_won,signals_lost "
                     "FROM wallets WHERE status IN ('testing','tracked','degraded') AND weight>0 "
                     "ORDER BY weight DESC, score DESC LIMIT 15").fetchall()
    if rows:
        L.append("  adresse       statut     score  poids  P&L réalisé  réussite  tokens/j  signaux G/P")
        for a, st, sc, w, pnl, wr, tpd, won, lost in rows:
            L.append(f"  {a[:6]}…{a[-4:]}  {st:9s}  {sc if sc is not None else 0:.2f}   {w:.2f}  "
                     f"{(pnl or 0):+9.2f} SOL  {(wr or 0) * 100:5.0f} %  {tpd or 0:7.1f}  {won}/{lost}")
    else:
        L.append("  (aucun wallet suivi pour l'instant)")
    reasons = c.execute("SELECT reason,COUNT(*) FROM wallets WHERE status IN ('excluded','unknown','removed') "
                        "GROUP BY reason ORDER BY 2 DESC LIMIT 6").fetchall()
    if reasons:
        L.append("  Écartés : " + ", ".join(f"{r.split(' ')[0]}={n}" for r, n in reasons))
    last = c.execute("SELECT MAX(ts) FROM wallet_events").fetchone()[0]
    if last:
        ev = c.execute("SELECT ts,address,action,reason,old_weight,new_weight FROM wallet_events WHERE ts>=? "
                       "AND action!='candidate' ORDER BY ts", (last - 86400,)).fetchall()
        L.append(f"  Mouvements des dernières 24 h ({len(ev)}) :")
        for ts, a, action, why, old, new in ev[-12:]:
            L.append(f"    {action:11s} {a[:6]}…{a[-4:]}  poids {old or 0:.2f}→{new or 0:.2f}  ({why[:60]})")
    cr = journal.kv_get("wd_credits")
    if cr:
        L.append(f"  Crédits RPC de la découverte : {cr['day_used']} aujourd'hui, {cr['month_used']} ce mois")
    return L


def build_report(journal, start_sol, open_positions=None, cfg=None):
    c = journal.c
    rows = c.execute("SELECT mint,symbol,pnl_sol,pnl_pct,exit_reason,close_ts FROM positions "
                     "WHERE close_ts IS NOT NULL ORDER BY close_ts").fetchall()
    L = ["=" * 60, "RAPPORT (simulation)", "=" * 60]
    n = len(rows)
    L.append(f"Trades fermés : {n}")
    if n:
        pnls = [r[2] for r in rows]
        wins = [p for p in pnls if p > 0]
        losses = [p for p in pnls if p <= 0]
        pf = (sum(wins) / -sum(losses)) if losses and sum(losses) < 0 else float("inf")
        L += [f"Résultat net        : {sum(pnls):+.4f} SOL ({sum(pnls) / start_sol * 100:+.2f} % du capital de départ)",
              f"Taux de réussite    : {len(wins) / n * 100:.0f} %",
              f"Espérance / trade   : {statistics.mean(pnls):+.4f} SOL ({statistics.mean(r[3] for r in rows):+.1f} %)",
              f"Gain moyen / perte moyenne : {statistics.mean(wins) if wins else 0:+.4f} / "
              f"{statistics.mean(losses) if losses else 0:+.4f} SOL",
              f"Profit factor       : {pf:.2f}",
              f"Drawdown max        : {_max_drawdown(start_sol, pnls):.2f} %"]
        L.append("Par motif de sortie (n, taux de réussite, résultat moyen) :")
        for reason in sorted({r[4] for r in rows}):
            g = [r for r in rows if r[4] == reason]
            L.append(f"  {reason:20s} n={len(g):3d}  réussite={sum(x[2] > 0 for x in g) / len(g) * 100:3.0f} %  "
                     f"moyen={statistics.mean(x[3] for x in g):+6.1f} %")
        det = c.execute("SELECT pnl_sol,mae_pct,mfe_pct,r_multiple,config_hash FROM positions "
                        "WHERE close_ts IS NOT NULL").fetchall()
        rs = [d[3] for d in det if d[3] is not None]
        if rs:
            L.append(f"R-multiple moyen : {statistics.mean(rs):+.2f} R (1 R = la perte visée au stop ; > 0 = on gagne plus qu'on ne risque)")
        for label, grp in (("gagnants", [d for d in det if d[0] > 0]), ("perdants", [d for d in det if d[0] <= 0])):
            ms = [d[1] for d in grp if d[1] is not None]
            fs = [d[2] for d in grp if d[2] is not None]
            if ms and fs:
                L.append(f"  {label:9s}: pire excursion (MAE) médiane {statistics.median(ms):+.0f} %, "
                         f"meilleure excursion (MFE) médiane {statistics.median(fs):+.0f} %")
        L.append("  (MFE élevée chez les perdants = on laisse repartir les gains : sorties à resserrer ; "
                 "MAE profonde chez les gagnants = stop trop large ou trop serré)")
        hashes = {d[4] for d in det if d[4]}
        if len(hashes) > 1:
            L.append(f"⚠ {len(hashes)} versions de config/code différentes dans ce journal : la porte de promotion "
                     "ne comptera que la plus récente.")
        top = max(pnls)
        if n >= 3 and top > 0:
            L.append(f"Sans le meilleur trade ({top:+.4f} SOL) : {sum(pnls) - top:+.4f} SOL  "
                     "← si ce chiffre est négatif, le résultat repose sur UN coup de chance.")
        slips = [r[0] for r in c.execute("SELECT entry_slip_pct FROM positions WHERE close_ts IS NOT NULL "
                                         "AND entry_slip_pct IS NOT NULL")]
        if slips:
            L.append(f"Slippage d'entrée (prix rempli vs prix à la décision) : médiane {statistics.median(slips):+.1f} %, "
                     f"max {max(slips):+.1f} %")
        if n < 200:
            L.append(f"⚠ Échantillon trop petit ({n} < 200 trades) : aucune conclusion statistique possible.")
    if cfg is not None:
        sm = cfg.sim
        rt = 2 * sm.fee_pct + sm.base_slippage_bps * (1 + sm.sell_slippage_mult) / 100
        sizes = [r[0] for r in c.execute("SELECT cost_sol FROM positions WHERE close_ts IS NOT NULL")]
        avg = statistics.mean(sizes) if sizes else start_sol * cfg.risk.max_position_pct / 100
        tips = 2 * sm.tip_sol / avg * 100
        L.append(f"Frictions simulées aller-retour : {rt:.1f} % (frais + slippage) + {tips:.1f} % de pourboires fixes "
                 f"(taille moyenne {avg:.3f} SOL) = {rt + tips:.1f} % : un trade doit gagner plus que ça pour compter.")
    for p in (open_positions or []):
        L.append(f"Position ouverte : {p.symbol} coût {p.cost_sol:.3f} SOL")

    L += ["", "Décisions sur les candidats :"]
    dec = Counter(r[0] for r in c.execute("SELECT decision FROM candidates"))
    L.append("  " + ", ".join(f"{k}={v}" for k, v in dec.most_common()) if dec else "  (aucun)")
    reasons = Counter()
    for (dec_, rs) in c.execute("SELECT decision,reasons FROM candidates WHERE decision!='enter'"):
        for r in json.loads(rs):
            reasons[r] += 1
    if reasons:
        L.append("Raisons de rejet : " + ", ".join(f"{k}={v}" for k, v in reasons.most_common()))

    ex = c.execute("SELECT ts,symbol,mint,reasons FROM candidates WHERE decision='reject' ORDER BY id DESC LIMIT 8").fetchall()
    if ex:
        L += ["", "Derniers tokens REFUSÉS (avec raison) :"]
        for _ts, sym, mint, rs in ex:
            L.append(f"  {(sym or mint[:10]):12s} {', '.join(json.loads(rs))[:70]}")
    span = c.execute("SELECT MIN(ts),MAX(ts),COUNT(*) FROM candidates").fetchone()
    if span and span[2]:
        n_err = c.execute("SELECT COUNT(*) FROM candidates WHERE decision='data_error'").fetchone()[0]
        L.append(f"Période couverte : {(span[1] - span[0]) / 3600:.1f} h, {span[2]} décisions (dont {n_err} erreurs de données)")
    sizes = c.execute("SELECT size_pct,cost_sol FROM positions WHERE size_pct IS NOT NULL").fetchall()
    if sizes:
        pcts = [x[0] for x in sizes]
        L += ["", f"DISTRIBUTION DES TAILLES DE POSITION ({len(sizes)} positions)",
              f"  % de l'équité : min {min(pcts):.2f} %, médiane {statistics.median(pcts):.2f} %, max {max(pcts):.2f} % ; "
              f"en SOL : {min(x[1] for x in sizes):.3f} → {max(x[1] for x in sizes):.3f}"]
        top = max(max(pcts), 1e-9)
        edges = [top * i / 5 for i in range(6)]
        for i in range(5):
            n = sum(1 for p in pcts if edges[i] <= p < edges[i + 1] or (i == 4 and p == edges[5]))
            L.append(f"  {edges[i]:5.2f}-{edges[i + 1]:5.2f} % | {'█' * n} {n}")
        if max(pcts) - min(pcts) < 0.05 * max(pcts):
            L.append("  ⚠ tailles quasi identiques : les frais fixes (pourboires) imposent une taille minimale proche du "
                     "plafond ; le sizing dynamique n'a de marge qu'avec un capital plus grand.")

    L += wallets_section(journal)
    L += ["", "Les filtres protègent-ils ? (variation du prix après la décision, médiane)"]
    for label, cond in (("acceptés", "decision='enter'"), ("rejetés ", "decision='reject'")):
        w = c.execute(f"SELECT r_1h,r_6h FROM watch WHERE {cond}").fetchall()
        if w:
            m1 = statistics.median(x[0] for x in w if x[0] is not None) if any(x[0] is not None for x in w) else None
            m6 = statistics.median(x[1] for x in w if x[1] is not None) if any(x[1] is not None for x in w) else None
            fmt = lambda v: "n/a" if v is None else f"{v:+.0f} %"
            L.append(f"  {label} (n={len(w)}) : +1h {fmt(m1)}, +6h {fmt(m6)}")
    L.append("  → si les rejetés font aussi bien que les acceptés, les filtres coûtent des gains sans protéger.")
    return "\n".join(L)
