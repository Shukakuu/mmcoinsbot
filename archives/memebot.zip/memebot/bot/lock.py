"""Verrou d'instance unique : deux bots sur le même journal = comptabilité fausse (cas rencontré sur un bot réel).
Verrou de fichier géré par le système d'exploitation : libéré automatiquement si le processus meurt
(pas de fichier PID périmé). Windows : msvcrt, non testé dans mon environnement (Linux)."""
import os


class InstanceLock:
    def __init__(self, path):
        self.path = path
        self._fh = None

    def acquire(self):
        self._fh = open(self.path, "a+")
        try:
            if os.name == "nt":
                import msvcrt
                self._fh.seek(0)
                msvcrt.locking(self._fh.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self._fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self._fh.close()
            self._fh = None
            return False
        self._fh.seek(0)
        self._fh.truncate()
        self._fh.write(str(os.getpid()))
        self._fh.flush()
        return True

    def release(self):
        if self._fh:
            try:
                if os.name == "nt":
                    import msvcrt
                    self._fh.seek(0)
                    msvcrt.locking(self._fh.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(self._fh.fileno(), fcntl.LOCK_UN)
            finally:
                self._fh.close()
                self._fh = None
