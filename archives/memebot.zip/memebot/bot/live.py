"""Mode LIVE en PAPER TRADING : vraies données, ordres fictifs. Aucune clé privée n'est utilisée."""
import logging
import os
import time

from .db import Journal
from .alerts import Notifier
from .engine import Engine
from .health import HEALTH
from .lock import InstanceLock
from .market import LiveMarket
from .paper import PaperBroker
from .risk import RiskManager
from .safety import SafetyChecker
from .sources.gmgn import GmgnSource
from .sources.rpc_poll import RpcPollSource
from .wallets import WalletBook

log = logging.getLogger("live")


def run_live(cfg, db_path):
    key = os.getenv("HELIUS_API_KEY")
    if not key:
        raise SystemExit("Définis la variable d'environnement HELIUS_API_KEY (clé gratuite sur dashboard.helius.dev).")
    rpc = f"https://mainnet.helius-rpc.com/?api-key={key}"
    lock = InstanceLock(str(db_path) + ".lock")
    if not lock.acquire():
        raise SystemExit(f"Une autre instance utilise déjà {db_path} (verrou {db_path}.lock) : arrêt, pour ne pas fausser la comptabilité.")
    j = Journal(db_path)
    book = WalletBook(cfg.wallets.path, max_j7_age_min=cfg.wallets.max_j7_age_min,
                      enforce_j7_freshness=cfg.wallets.enforce_j7_freshness, journal=j)
    market = LiveMarket(SafetyChecker(rpc))
    broker = PaperBroker(cfg, market, cfg.capital.start_sol)
    risk = RiskManager(cfg, enforce_stop_file=True)
    notifier = Notifier()
    log.info("Alertes Telegram : %s", "activées" if notifier.enabled else "désactivées (TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID absents)")
    engine = Engine(cfg, market, book, j, broker, risk, now_fn=time.time, notifier=notifier)
    notifier.send(f"🚀 memebot démarré (paper trading), empreinte {engine.fingerprint}")
    HEALTH.threshold = cfg.health.max_consecutive_failures
    if engine.load_state():
        log.info("Reprise d'un état existant (journal %s).", db_path)
    elif j.c.execute("SELECT COUNT(*) FROM events").fetchone()[0]:
        log.warning("Journal non vide sans état sauvegardé : comptabilité repartie de %s SOL.", cfg.capital.start_sol)
    name = cfg.live.source if cfg.live.source != "auto" else ("gmgn" if os.getenv("GMGN_API_KEY") else "rpc")
    if name == "gmgn":
        src = GmgnSource(book, cfg, lambda: market.sol_usd)
        log.info("Source de signaux : GMGN (smart money + KOL), sondage toutes les %ss", cfg.live.gmgn_poll_interval_s)
    else:
        src = RpcPollSource(rpc, lambda: book.active(time.time()), cfg, j)
        est = src.estimate_calls_per_day(len(book.active(time.time())))
        log.info("Source de signaux : RPC Helius ; %d wallets actifs ; ~%d appels RPC/jour estimés (budget %d)",
                 len(book.active(time.time())), est, cfg.live.max_rpc_calls_per_day)
        if est > cfg.live.max_rpc_calls_per_day:
            log.warning("Estimation au-dessus du budget : allonge wallet_poll_interval_s ou réduis les wallets.")
    log.info("Paper trading démarré. Crée un fichier STOP dans ce dossier pour interdire toute nouvelle entrée.")
    last_beat = 0.0
    while True:
        book.reload()
        try:
            for ev in src.poll():
                engine.handle_event(ev)
        except Exception as e:  # noqa: BLE001
            log.error("erreur source : %s (aucune nouvelle entrée tant que ça dure)", e)
        try:
            engine.advance_to(time.time())          # sorties et suivi : ne doit JAMAIS faire tomber la boucle
        except Exception as e:  # noqa: BLE001
            log.error("erreur de gestion des positions : %s", e)
        if time.time() - last_beat >= 300:
            engine.heartbeat(time.time())
            engine.save_state()
            last_beat = time.time()
        time.sleep(cfg.live.loop_sleep_s)
