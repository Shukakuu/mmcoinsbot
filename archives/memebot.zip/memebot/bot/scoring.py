"""Score 0-100 pour les tokens qui ont passé TOUS les filtres éliminatoires."""
import math


def _age_points(age, cfg):
    """Rampe douce : 0 au minimum d'âge, 10 à 40 min, plateau jusqu'à 12 h, puis baisse vers 4 à l'âge max."""
    lo, hi = cfg.filters.min_pair_age_min, cfg.filters.max_pair_age_hours * 60
    if age <= lo:
        return 0.0
    if age < 40:
        return 10.0 * (age - lo) / max(40 - lo, 1)
    if age <= 720:
        return 10.0
    return max(4.0, 10.0 - 6.0 * (age - 720) / max(hi - 720, 1))


def _momentum_points(info):
    """0-20 pts : volume horaire rapporté à la liquidité, pression d'achat, tendance. None si aucune donnée.
    ⚠ pondération non validée statistiquement."""
    have = [info.volume_h1_usd, info.buys_h1, info.sells_h1, info.price_change_h1_pct]
    if all(v is None for v in have):
        return None
    pts = 0.0
    if info.volume_h1_usd is not None and info.liquidity_usd:
        pts += 8.0 * min(1.0, info.volume_h1_usd / info.liquidity_usd)
    if info.buys_h1 is not None and info.sells_h1 is not None and info.buys_h1 + info.sells_h1 >= 20:
        bp = info.buys_h1 / (info.buys_h1 + info.sells_h1)
        pts += 8.0 * min(1.0, max(0.0, (bp - 0.45) / 0.25))
    if info.price_change_h1_pct is not None and -10.0 <= info.price_change_h1_pct <= 100.0:
        pts += 4.0                                  # tendance saine ; au-delà de +100 % en 1 h : on ne chasse pas
    return pts


def score_candidate(sig, info, drift_pct, cfg):
    f = cfg.filters
    parts = {}
    has_wallets = sig.eff_weight > 0
    parts["convergence"] = 40.0 * (1.0 - math.exp(-sig.eff_weight / 2.5)) if has_wallets else 0.0   # 3 wallets ~28, 5 ~35, 8 ~38
    safety = 0.0
    if info.rugcheck_levels is not None:
        warns = sum(1 for lvl in info.rugcheck_levels if lvl == "warn")
        safety = max(0.0, 25.0 - 8.0 * warns)
    parts["safety"] = safety
    liq = max(info.liquidity_usd or 1.0, 1.0)
    ratio = min(1.0, max(0.0, math.log10(liq / f.min_liquidity_usd)))   # 1.0 à 10x le minimum
    parts["liquidity"] = 15.0 * ratio
    d = max(drift_pct or 0.0, 0.0)
    parts["drift"] = 10.0 * max(0.0, 1.0 - d / cfg.entry.max_drift_pct)
    parts["age"] = _age_points(info.pair_age_min or 0.0, cfg)
    minor = [fl for fl in (info.x_flags or []) if fl not in cfg.x.veto_flags]
    parts["x_penalty"] = -5.0 * len(minor)
    mom = _momentum_points(info)
    if mom is not None:
        parts["momentum"] = mom
    # normalisation : on rapporte à ce qui était MESURABLE (pas de pénalité pour un signal de wallets ou un volume absents)
    max_available = (40.0 if has_wallets else 0.0) + 25.0 + 15.0 + 10.0 + 10.0 + (20.0 if mom is not None else 0.0)
    return round(100.0 * sum(parts.values()) / max_available, 1), parts
