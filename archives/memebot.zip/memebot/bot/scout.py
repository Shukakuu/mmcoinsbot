"""Mode « scout » : paper trading FORWARD sur données réelles publiques (DexScreener + RugCheck, wallets optionnels).
Aucune transaction réelle, aucune clé privée : toutes les entrées/sorties sont simulées au prix réel du marché."""
import logging
import time
from collections import deque

from .alerts import Notifier
from .convergence import Signal
from .db import Journal
from .engine import Engine
from .execution import make_executor
from .health import HEALTH
from .jsonl import JsonlLog
from .lock import InstanceLock
from .market import LiveMarket
from .risk import RiskManager
from .safety import SafetyChecker
from .sources.dexscreener import DexClient
from .sources.pumpportal import PumpPortalSource
from .wallet_discovery import WalletDiscovery
from .wallets import WalletBook
from .wallets_registry import WalletRegistry

log = logging.getLogger("scout")


class Scout:
    def __init__(self, cfg, engine, dex, journal, now_fn=time.time, discovery=None):
        self.cfg, self.engine, self.dex, self.j, self.now_fn = cfg, engine, dex, journal, now_fn
        self.discovery = discovery
        self.queue = deque()
        self.seen = set(journal.kv_get("scout_seen", []))
        self.retry = {}               # mint -> (pas avant ts, n)
        self._last_discovery = 0.0

    def _discover(self, now):
        self._last_discovery = now
        try:
            cands = self.dex.discovery()
        except Exception as e:  # noqa: BLE001
            log.warning("découverte indisponible : %s", e)
            return 0
        new = [c for c in cands if c["mint"] not in self.seen]
        for c in new:
            self.seen.add(c["mint"])
            self.queue.append(c)
        self.j.kv_set("scout_seen", sorted(self.seen)[-5000:])
        return len(new)

    def _evaluate(self, c, now):
        try:
            price = self.engine.market.price_at(c["mint"], now)
        except Exception:  # noqa: BLE001
            price = None
        sig = Signal(mint=c["mint"], first_ts=now, first_price=price, last_ts=now, wallets=[], clusters=0,
                     eff_weight=0.0, total_sol=0.0)
        decision, reasons = self.engine.evaluate_signal(sig, now, source=f"discovery:{c['source']}")
        n = c.get("retries", 0)
        if "pair_too_new" in reasons and n < self.cfg.scout.max_retries:
            c["retries"] = n + 1
            self.retry[c["mint"]] = (now + self.cfg.scout.retry_after_min * 60, c)
        return decision, reasons

    def tick(self):
        now = self.now_fn()
        if now - self._last_discovery >= self.cfg.scout.discovery_interval_s:
            self._discover(now)
        for mint, (when, c) in list(self.retry.items()):
            if now >= when:
                del self.retry[mint]
                self.queue.append(c)
        done = 0
        while self.queue and done < self.cfg.scout.max_new_per_tick:
            self._evaluate(self.queue.popleft(), now)
            done += 1
        self.engine.advance_to(now)
        if self.discovery:
            try:
                self.discovery.tick(now)                 # entretien quotidien + un travail de découverte (borné par le budget)
                self.engine.book.reload()                # prend en compte les ajouts / retraits
            except Exception as e:  # noqa: BLE001
                log.warning("découverte de wallets : %s (le scout continue)", e)
        return done


def run_scout(cfg, db_path):
    lock = InstanceLock(str(db_path) + ".lock")
    if not lock.acquire():
        raise SystemExit(f"Une autre instance utilise déjà {db_path} : arrêt.")
    j = Journal(db_path)
    HEALTH.threshold = cfg.health.max_consecutive_failures
    dex = DexClient()
    market = LiveMarket(SafetyChecker(mode="rugcheck_only"), client=dex, model_exit=True)
    registry = WalletRegistry(j, cfg)
    book = WalletBook(cfg.wallets.path, max_j7_age_min=cfg.wallets.max_j7_age_min,
                      enforce_j7_freshness=cfg.wallets.enforce_j7_freshness, journal=j, registry=registry)
    discovery = WalletDiscovery.from_env(cfg, j, registry, dex)
    log.info("Découverte automatique de wallets : %s", "active" if discovery.enabled else f"désactivée ({discovery.why})")
    broker = make_executor(cfg, market, "paper")             # seul le mode "paper" existe dans cette phase
    risk = RiskManager(cfg, enforce_stop_file=True)
    notifier = Notifier()
    engine = Engine(cfg, market, book, j, broker, risk, now_fn=time.time, notifier=notifier,
                    jsonl=JsonlLog(cfg.scout.jsonl_path))
    if engine.load_state():
        log.info("Reprise d'un état existant (journal %s).", db_path)
    scout = Scout(cfg, engine, dex, j, discovery=discovery)
    pp = None
    if cfg.scout.pumpportal:
        ordered = [r["address"] for r in registry.tracked()] + sorted(book.wallets)
        keys = list(dict.fromkeys(ordered))[:cfg.scout.pumpportal_max_keys]
        pp = PumpPortalSource(keys)
        log.info("PumpPortal : %s", f"suivi de {len(keys)} wallet(s)" if pp.start() else "non démarré")
    log.info("Scout démarré (PAPER TRADING, aucune transaction réelle). Journal %s, décisions %s. "
             "Crée un fichier STOP pour interdire toute nouvelle entrée.", db_path, cfg.scout.jsonl_path)
    notifier.send(f"🔭 scout démarré (paper trading), empreinte {engine.fingerprint}")
    last_beat = 0.0
    while True:
        try:
            if pp:
                for ev in pp.poll():
                    engine.handle_event(ev)
            scout.tick()
        except Exception as e:  # noqa: BLE001
            log.error("erreur de boucle : %s (la gestion des positions continue)", e)
            try:
                engine.advance_to(time.time())
            except Exception as e2:  # noqa: BLE001
                log.error("erreur de gestion des positions : %s", e2)
        if time.time() - last_beat >= 300:
            engine.heartbeat(time.time())
            engine.save_state()
            last_beat = time.time()
        time.sleep(cfg.scout.tick_s)
