"""Journal SQLite : on enregistre TOUT (événements, décisions, rejets, trades, résultats)."""
import json
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS events(ts REAL, wallet TEXT, side TEXT, mint TEXT, sol REAL, tokens REAL, sig TEXT);
CREATE TABLE IF NOT EXISTS candidates(id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, mint TEXT, symbol TEXT,
    decision TEXT, score REAL, reasons TEXT, detail TEXT);
CREATE TABLE IF NOT EXISTS trades(id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, pos_id INTEGER, mint TEXT,
    side TEXT, reason TEXT, sol REAL, tokens REAL, price REAL);
CREATE TABLE IF NOT EXISTS positions(id INTEGER PRIMARY KEY, mint TEXT, symbol TEXT, open_ts REAL, close_ts REAL,
    cost_sol REAL, proceeds_sol REAL, pnl_sol REAL, pnl_pct REAL, exit_reason TEXT, wallets TEXT, entry_slip_pct REAL,
    mae_pct REAL, mfe_pct REAL, r_multiple REAL, config_hash TEXT, size_pct REAL);
CREATE TABLE IF NOT EXISTS watch(mint TEXT, ts0 REAL, decision TEXT, reasons TEXT, price0 REAL, r_1h REAL, r_6h REAL);
CREATE TABLE IF NOT EXISTS wallet_stats(wallet TEXT PRIMARY KEY, n INTEGER, wins INTEGER, sum_pnl_pct REAL);
CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS wallets(address TEXT PRIMARY KEY, status TEXT, reason TEXT, score REAL, weight REAL,
    n_trades INTEGER, n_closed INTEGER, realized_pnl_sol REAL, win_rate REAL, age_days REAL, age_complete INTEGER,
    tokens_per_day REAL, sniper_share REAL, source_token TEXT, first_seen_ts REAL, last_eval_ts REAL, next_eval_ts REAL,
    signals_won INTEGER DEFAULT 0, signals_lost INTEGER DEFAULT 0, consec_losses INTEGER DEFAULT 0,
    recent_pnls TEXT DEFAULT '[]', stage INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS wallet_events(ts REAL, address TEXT, action TEXT, reason TEXT, old_weight REAL, new_weight REAL);
"""


class Journal:
    def __init__(self, path=":memory:"):
        self.c = sqlite3.connect(path)
        self.c.executescript(SCHEMA)

    def log_event(self, ev):
        self.c.execute("INSERT INTO events VALUES (?,?,?,?,?,?,?)",
                       (ev.ts, ev.wallet, ev.side, ev.mint, ev.sol_amount, ev.token_amount, ev.sig))
        self.c.commit()

    def log_candidate(self, ts, mint, symbol, decision, score, reasons, detail):
        cur = self.c.execute("INSERT INTO candidates(ts,mint,symbol,decision,score,reasons,detail) VALUES (?,?,?,?,?,?,?)",
                             (ts, mint, symbol, decision, score, json.dumps(reasons), json.dumps(detail, default=str)))
        self.c.commit()
        return cur.lastrowid

    def log_trade(self, ts, pos_id, mint, side, reason, sol, tokens, price):
        self.c.execute("INSERT INTO trades(ts,pos_id,mint,side,reason,sol,tokens,price) VALUES (?,?,?,?,?,?,?,?)",
                       (ts, pos_id, mint, side, reason, sol, tokens, price))
        self.c.commit()

    def log_position(self, p):
        pnl = p.proceeds_sol - p.cost_sol
        slip = 100.0 * (p.entry_price / p.decision_price - 1) if p.decision_price else None
        mae = 100.0 * (p.trough_price / p.entry_price - 1) if p.trough_price and p.entry_price else None
        mfe = 100.0 * (p.peak_price / p.entry_price - 1) if p.peak_price and p.entry_price else None
        r_mult = pnl / p.risk_sol if p.risk_sol else None
        self.c.execute("INSERT OR REPLACE INTO positions VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                       (p.id, p.mint, p.symbol, p.open_ts, p.close_ts, p.cost_sol, p.proceeds_sol, pnl,
                        100.0 * pnl / p.cost_sol if p.cost_sol else 0.0, p.exit_reason, json.dumps(p.wallets), slip,
                        mae, mfe, r_mult, p.config_hash,
                        100.0 * p.cost_sol / p.equity_at_entry if p.equity_at_entry else None))
        self.c.commit()

    def log_watch(self, mint, ts0, decision, reasons, price0, r1, r6):
        self.c.execute("INSERT INTO watch VALUES (?,?,?,?,?,?,?)",
                       (mint, ts0, decision, json.dumps(reasons), price0, r1, r6))
        self.c.commit()

    def get_wallet_stats(self):
        return {w: (n, wins, s) for w, n, wins, s in
                self.c.execute("SELECT wallet,n,wins,sum_pnl_pct FROM wallet_stats")}

    def upsert_wallet_stats(self, wallet, n, wins, s):
        self.c.execute("INSERT OR REPLACE INTO wallet_stats VALUES (?,?,?,?)", (wallet, n, wins, s))
        self.c.commit()

    def kv_get(self, k, default=None):
        r = self.c.execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
        return json.loads(r[0]) if r else default

    def kv_set(self, k, v):
        self.c.execute("INSERT OR REPLACE INTO kv VALUES (?,?)", (k, json.dumps(v)))
        self.c.commit()
