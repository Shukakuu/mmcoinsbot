"""Générateur de scénarios SYNTHÉTIQUES pour tester la mécanique du bot.
ATTENTION : les résultats sur ces données ne prouvent RIEN sur la rentabilité réelle ;
ils servent uniquement à vérifier que filtres, sorties et coupe-circuits se comportent comme prévu."""
import json
import random
from datetime import datetime, timezone

BASE = datetime(2026, 10, 1, tzinfo=timezone.utc).timestamp()
WALLETS = {  # adresse fictive -> cluster
    "WalletA1": "A", "WalletA2": "A", "WalletA3": "A", "WalletB": "B", "WalletC": "C",
    "WalletD": "D", "WalletE": "E", "WalletF": "F",
}


def _path(t0, anchors, rng, p0=0.00001, minutes=720):
    pts = []
    for m in range(0, minutes + 1):
        for (m1, x1), (m2, x2) in zip(anchors, anchors[1:]):
            if m1 <= m <= m2:
                x = x1 + (x2 - x1) * ((m - m1) / (m2 - m1) if m2 > m1 else 1)
                break
        else:
            x = anchors[-1][1]
        pts.append([t0 + m * 60, p0 * x * (1 + rng.uniform(-0.015, 0.015))])
    return pts


def generate(seed=7):
    rng = random.Random(seed)
    tokens, events = {}, []

    def add(name, hour, anchors, buyers, sells=(), liq=80000, liq_path=None, **flags):
        t0 = BASE + hour * 3600
        mint = f"MINT_{name}"
        path = _path(t0, anchors, rng)
        tok = {"symbol": name, "price_path": path, "liquidity_usd": liq, "fdv_usd": 1_500_000,
               "pair_created_ts": t0, "mint_authority_active": False, "freeze_authority_active": False,
               "rugcheck_levels": ["info"], "sell_quote_ok": True}
        if liq_path:
            tok["liquidity_path"] = [[t0 + m * 60, v] for m, v in liq_path]
        tok.update(flags)
        tokens[mint] = tok

        def price_at(minute):
            return path[min(int(minute), len(path) - 1)][1]
        for wallet, minute, sol in buyers:
            p = price_at(minute)
            events.append({"ts": t0 + minute * 60, "wallet": wallet, "side": "buy", "mint": mint,
                           "sol_amount": sol, "price_sol": p})
        for wallet, minute, sol_frac in sells:
            p = price_at(minute)
            events.append({"ts": t0 + minute * 60, "wallet": wallet, "side": "sell", "mint": mint,
                           "sol_amount": 0, "price_sol": p, "sell_all": True})

    triple = lambda a, b, c: [(a, 20, 3.0), (b, 24, 2.5), (c, 28, 4.0)]
    add("RUNNER_A", 0, [(0, 1), (20, 1.5), (28, 1.6), (60, 2.4), (120, 3.8), (180, 4.5), (240, 3.0), (400, 1.8), (720, 1.0)],
        triple("WalletB", "WalletC", "WalletD"), sells=[("WalletB", 230, 1), ("WalletC", 235, 1)])
    add("SLOW_BLEED", 1, [(0, 1), (20, 1.3), (28, 1.35), (60, 1.1), (120, 0.9), (300, 0.5), (720, 0.2)],
        triple("WalletB", "WalletE", "WalletF"), sells=[("WalletE", 100, 1)])
    add("RUG", 2, [(0, 1), (25, 2.0), (30, 2.2), (50, 2.5), (60, 2.5), (61, 0.05), (720, 0.02)],
        triple("WalletC", "WalletD", "WalletE"), liq_path=[(0, 60000), (60, 60000), (61, 3000), (720, 3000)])
    add("HONEYPOT", 3, [(0, 1), (28, 1.4), (720, 3.0)], triple("WalletB", "WalletC", "WalletF"), sell_quote_ok=False)
    add("MINT_ACTIVE", 4, [(0, 1), (28, 1.4), (720, 2.0)], triple("WalletB", "WalletD", "WalletE"),
        mint_authority_active=True)
    add("SAME_CLUSTER", 5, [(0, 1), (28, 1.5), (180, 3.0), (720, 2.0)], triple("WalletA1", "WalletA2", "WalletA3"))
    add("LATE_DRIFT", 6, [(0, 1), (20, 1.0), (24, 1.1), (27, 1.7), (180, 2.5), (720, 1.0)],
        [("WalletB", 20, 3.0), ("WalletC", 24, 2.5), ("WalletD", 27, 4.0)])
    add("LOW_LIQ", 7, [(0, 1), (28, 1.5), (180, 3.0), (720, 1.0)], triple("WalletC", "WalletE", "WalletF"), liq=6000)
    add("RUNNER_B", 8, [(0, 1), (20, 1.2), (30, 1.25), (90, 1.9), (150, 2.7), (240, 2.0), (720, 1.2)],
        triple("WalletB", "WalletD", "WalletF"))
    add("BAIT", 9, [(0, 1), (28, 1.8), (60, 0.4), (720, 0.1)], [("WalletE", 20, 8.0)])
    add("RC_DANGER", 10, [(0, 1), (28, 1.4), (300, 2.4), (720, 1.5)], triple("WalletB", "WalletC", "WalletE"),
        rugcheck_levels=["warn", "danger"])
    add("LOSER_C", 11, [(0, 1), (20, 1.0), (30, 1.05), (70, 0.95), (120, 0.7), (720, 0.3)],
        triple("WalletD", "WalletE", "WalletF"))
    add("RUNNER_D", 30, [(0, 1), (20, 1.3), (30, 1.4), (100, 2.0), (200, 3.2), (300, 2.0), (720, 1.1)],
        triple("WalletB", "WalletC", "WalletF"))

    # conversion des ventes : on calcule token_amount pour que le prix soit cohérent
    out_events = []
    held = {}
    for e in sorted(events, key=lambda x: x["ts"]):
        price = e["price_sol"]
        if e["side"] == "buy":
            tok = e["sol_amount"] / price
            held[(e["wallet"], e["mint"])] = held.get((e["wallet"], e["mint"]), 0) + tok
            e["token_amount"] = tok
        else:
            tok = held.pop((e["wallet"], e["mint"]), 0)
            if tok <= 0:
                continue
            e["token_amount"] = tok
            e["sol_amount"] = tok * price
        e.pop("sell_all", None)
        out_events.append(e)
    return {"sol_usd": 150.0, "tokens": tokens, "events": out_events}


def write_scenario(path, wallets_path):
    data = generate()
    with open(path, "w") as f:
        json.dump(data, f)
    with open(wallets_path, "w") as f:
        f.write("# wallets de démonstration (fictifs)\n")
        for w, c in WALLETS.items():
            f.write(f"{w}  # source=manual cluster={c}\n")
    return data
