"""Moteur : relie sources, convergence, filtres, score, risque, exécution simulée et journal.
Le même code sert pour la rediffusion (replay) et pour le live."""
import logging
from dataclasses import asdict

from .convergence import ConvergenceDetector
from .costs import estimate_roundtrip_cost_pct
from .fingerprint import fingerprint
from .filters import apply_filters
from .health import HEALTH
from .models import Position
from .scoring import score_candidate
from .x_signal import NullX

log = logging.getLogger("engine")
HOURS = (1, 6)


def trail_pct_for(peak_mult, tiers, base):
    """Trailing qui se resserre quand le pic monte : tier = [multiple du pic, trailing %]."""
    pct = base
    for mult, p in sorted(tiers):
        if peak_mult >= mult:
            pct = p
    return pct


class Engine:
    def __init__(self, cfg, market, book, journal, broker, risk, x=None, now_fn=None, notifier=None, jsonl=None):
        self.cfg, self.market, self.book, self.j = cfg, market, book, journal
        self.broker, self.risk = broker, risk
        self.x = x or NullX()
        self.notifier = notifier
        self.jsonl = jsonl
        self._notified_blocks = set()
        self.now_fn = now_fn          # live : time.time ; replay : None (l'horloge = celle des événements)
        self.det = ConvergenceDetector(cfg, book)
        self.start_sol = cfg.capital.start_sol
        self.fingerprint = fingerprint(cfg)
        self.positions = []           # positions ouvertes
        self.closed = []
        self.watch = []               # suivi contrefactuel : tokens acceptés ET rejetés
        self.now = None
        self._last_tick = None

    def _jlog(self, **rec):
        if self.jsonl:
            self.jsonl.write(**rec)

    def _notify(self, text, key=None, min_interval=0.0):
        if self.notifier:
            self.notifier.send(text, key=key, min_interval=min_interval)

    # ------------------------------------------------------------------ persistance (live)
    def save_state(self):
        self.j.kv_set("engine_state", {
            **self.broker.export_state(), "start_sol": self.start_sol,
            "positions": [asdict(p) for p in self.positions], "risk": self.risk.to_state(),
            "fired": self.det.fired})

    def load_state(self):
        """Reprend la comptabilité d'un run précédent. REFUSE de démarrer si le journal contient des
        positions ouvertes que l'état ne connaît pas (sinon : double comptabilité, chiffres faux)."""
        st = self.j.kv_get("engine_state")
        open_rows = self.j.c.execute("SELECT COUNT(*) FROM positions WHERE close_ts IS NULL").fetchone()[0]
        if st is None:
            if open_rows:
                raise RuntimeError(f"Le journal contient {open_rows} position(s) ouverte(s) mais aucun état "
                                   "sauvegardé : démarrage refusé. Utilise un nouveau fichier de journal.")
            return False
        if len(st["positions"]) != open_rows:
            raise RuntimeError(f"Incohérence : état = {len(st['positions'])} position(s) ouverte(s), journal = "
                               f"{open_rows}. Démarrage refusé, vérifie le journal.")
        self.broker.import_state(st)
        self.start_sol = st.get("start_sol", self.start_sol)
        self.positions = [Position(**p) for p in st["positions"]]
        self.risk.from_state(st["risk"])
        self.det.fired = dict(st.get("fired", {}))
        log.info("État repris : cash %.4f SOL, %d position(s) ouverte(s)", self.broker.cash, len(self.positions))
        return True

    def heartbeat(self, ts):
        """Photo de l'état à journaliser régulièrement : sert à comprendre a posteriori pourquoi
        le bot a (ou n'a pas) tradé."""
        eq = self.broker.equity(ts, self.positions)
        r = self.risk
        log.info("HEARTBEAT équité=%.4f SOL (départ %.2f) positions=%d pnl_jour=%.4f pertes_consécutives=%d "
                 "pause_jusqu'à=%s sources_dégradées=%s", eq, self.start_sol, len(self.positions), r.day_pnl,
                 r.consec, "oui" if ts < r.cooldown_until else "non", HEALTH.degraded() or "aucune")
        if HEALTH.degraded():
            self._notify(f"⚠ Sources de données dégradées : {', '.join(HEALTH.degraded())} (plus d'entrées)",
                         key="degraded", min_interval=3600)
        return eq

    # ------------------------------------------------------------------ entrée des événements
    def handle_event(self, ev):
        self.advance_to(ev.ts)
        self.j.log_event(ev)
        self.book.observe(ev)
        if ev.wallet not in self.book.active(ev.ts):
            return
        if ev.side == "buy":
            sig = self.det.on_buy(ev)
            if sig:
                self._evaluate(sig, ev.ts)
        else:
            self.det.on_sell(ev)

    def advance_to(self, ts):
        """Fait avancer l'horloge par pas réguliers : sorties de positions et suivi des rejets."""
        step = self.cfg.sim.tick_s
        if self._last_tick is None:
            self._last_tick = ts
        t = self._last_tick
        while t + step <= ts:
            t += step
            self.now = t
            self._check_positions(t)
            self._track_watch(t)
        self._last_tick = t
        self.now = ts

    # ------------------------------------------------------------------ décision d'entrée
    def evaluate_signal(self, sig, ts, source="wallets"):
        """Point d'entrée UNIQUE des décisions, quelle que soit l'origine du signal (wallets, découverte...)."""
        equity = self.broker.equity(ts, self.positions)
        size_est = equity * self.cfg.risk.max_position_pct / 100
        try:
            info = self.market.info(sig.mint, ts, size_est)
            info.x_flags = self.x.flags(sig.mint, info)
        except Exception as e:  # noqa: BLE001  (panne d'API : fail closed, jamais de plantage)
            log.error("données indisponibles pour %s : %s", sig.mint[:8], e)
            self.j.log_candidate(ts, sig.mint, "", "data_error", 0.0, [f"data_error:{str(e)[:80]}"], {})
            self._jlog(type="decision", ts=ts, source=source, mint=sig.mint, decision="data_error",
                       reasons=[f"data_error:{str(e)[:80]}"])
            return "data_error", [f"data_error:{str(e)[:80]}"]
        price = info.price_sol
        if info.roundtrip_cost_pct is None:             # pas de mesure réelle : on utilise l'estimation
            info.roundtrip_cost_pct = estimate_roundtrip_cost_pct(self.cfg, size_est, info.liquidity_usd,
                                                                  self.market.sol_usd)
        drift = ((price / sig.first_price - 1) * 100) if (price and sig.first_price) else None
        age = (self.now_fn() - sig.last_ts) if self.now_fn else 0.0
        reasons = apply_filters(sig, info, drift, self.cfg, signal_age_s=age)
        score, parts = score_candidate(sig, info, drift, self.cfg)
        detail = {"wallets": sig.wallets, "clusters": sig.clusters, "drift_pct": drift, "score_parts": parts,
                  "liq": info.liquidity_usd, "sell_impact": info.sell_impact_pct, "signal_age_s": age,
                  "roundtrip_cost_pct": info.roundtrip_cost_pct,
                  "pair_created_ts": (ts - info.pair_age_min * 60) if info.pair_age_min is not None else None}

        decision = "reject"
        if not reasons and score < self.cfg.entry.min_score:
            reasons = [f"score_below_{self.cfg.entry.min_score:g}"]
        if not reasons:
            j7 = any(m["source"] == "j7" for m in self.book.wallets.values())
            data_ok = (self.book.j7_fresh(ts) if j7 else True) and not HEALTH.degraded()
            ok, why, size = self.risk.check_entry(ts, equity, self.positions, info.liquidity_usd,
                                                  self.market.sol_usd, data_ok, score=score, eff_weight=sig.eff_weight)
            detail["sizing"] = self.risk.last_sizing
            if not ok:
                decision, reasons = "skip_risk", [why]
                bk = (int(ts // 86400), why)
                if why in ("daily_loss_limit", "cooldown_after_losses", "data_stale", "kill_switch_file") \
                        and bk not in self._notified_blocks:
                    self._notified_blocks.add(bk)
                    self._notify(f"⛔ Entrées bloquées : {why}", key=f"block:{bk}")
            else:
                pos, why = self.broker.buy(sig.mint, info.symbol, size, ts, sig.wallets)
                if pos is None:
                    decision, reasons = "buy_failed", [why]
                else:
                    decision = "enter"
                    pos.decision_price = price
                    pos.risk_sol = size * self.cfg.exit.stop_loss_pct / 100
                    pos.config_hash = self.fingerprint
                    pos.equity_at_entry = equity
                    self.positions.append(pos)
                    self.j.log_trade(ts, pos.id, pos.mint, "buy", "entry", size, pos.tokens_initial, pos.entry_price)
                    self.j.log_position(pos)            # ligne "ouverte" (close_ts NULL) dès l'entrée
                    self.save_state()
                    self._notify(f"🟢 ENTRÉE {info.symbol or sig.mint[:8]} {size:.3f} SOL (score {score}, "
                                 f"coût A/R estimé {info.roundtrip_cost_pct:.1f} %)", key=f"entry:{pos.id}")
                    log.info("ENTRÉE %s taille=%.3f SOL prix=%.3g slippage_entrée=%+.1f%% score=%s",
                             info.symbol or sig.mint[:6], size, pos.entry_price,
                             100 * (pos.entry_price / price - 1) if price else 0.0, score)
        self.j.log_candidate(ts, sig.mint, info.symbol, decision, score, reasons, detail)
        self._jlog(type="decision", ts=ts, source=source, mint=sig.mint, symbol=info.symbol, decision=decision,
                   reasons=reasons, score=score, price_sol=price, liquidity_usd=info.liquidity_usd,
                   size_sol=(self.risk.last_sizing.get("size_sol") if decision == "enter" else None),
                   sizing=detail.get("sizing") if decision == "enter" else None, roundtrip_cost_pct=info.roundtrip_cost_pct)
        if price:
            self.watch.append({"mint": sig.mint, "ts0": ts, "price0": price, "decision": decision,
                               "reasons": reasons, "r": {}})
        return decision, reasons

    _evaluate = evaluate_signal      # ancien nom

    # ------------------------------------------------------------------ gestion des sorties
    def _check_positions(self, t):
        e = self.cfg.exit
        alert_s = self.cfg.health.blind_alert_s
        for pos in list(self.positions):
            price = self.market.price_at(pos.mint, t)
            liq = self.market.liquidity_usd_at(pos.mint, t)
            if not price:
                # on est AVEUGLE sur une position ouverte : à signaler fort, c'est un risque
                if pos.blind_since is None:
                    pos.blind_since = t
                elif t - pos.blind_since >= alert_s and int(t - pos.blind_since) % (alert_s * 2) < self.cfg.sim.tick_s:
                    log.error("ALERTE : plus de prix pour %s depuis %ds, position non surveillée",
                              pos.symbol or pos.mint[:8], t - pos.blind_since)
                    self._notify(f"👁 Plus de prix pour {pos.symbol or pos.mint[:8]} depuis {int(t - pos.blind_since)} s : "
                                 "position non surveillée !", key=f"blind:{pos.id}", min_interval=1800)
                continue
            pos.blind_since = None
            pos.peak_price = max(pos.peak_price, price)
            pos.trough_price = min(pos.trough_price or price, price)
            reason, frac = None, 1.0
            if liq is not None and liq < pos.entry_liquidity_usd * (1 - e.liquidity_drop_exit_pct / 100):
                reason = "liquidity_collapse"
            elif (not pos.tp1_done and pos.peak_price >= pos.entry_price * (1 + e.breakeven_trigger_pct / 100)
                  and price <= pos.entry_price * (1 + e.breakeven_floor_pct / 100)):
                reason = "breakeven_stop"
            elif price <= pos.entry_price * (1 - e.stop_loss_pct / 100) and not pos.tp1_done:
                reason = "stop_loss"
            elif not pos.tp1_done and price >= pos.entry_price * e.take_profit_1_mult:
                reason, frac = "take_profit_1", e.take_profit_1_fraction
            elif pos.tp1_done and price <= max(pos.entry_price, pos.peak_price * (1 - trail_pct_for(
                    pos.peak_price / pos.entry_price, e.trail_tiers, e.trailing_stop_pct) / 100)):
                reason = "trailing_stop"
            elif self.det.sellers_since(pos.mint, pos.wallets, pos.open_ts) >= e.exit_on_wallet_sells:
                reason = "smart_wallets_sold"
            elif t - pos.open_ts >= e.max_hold_hours * 3600:
                reason = "time_stop"
            if not reason:
                continue
            ok, proceeds, fill = self.broker.sell(pos, frac, t)
            if not ok:
                log.warning("vente %s échouée (%s), nouvel essai au prochain pas", pos.symbol, reason)
                continue
            self.j.log_trade(t, pos.id, pos.mint, "sell", reason, proceeds, 0.0, fill)
            self._jlog(type="partial_exit" if not pos.closed else "exit", ts=t, mint=pos.mint, symbol=pos.symbol,
                       reason=reason, entry_price=pos.entry_price, exit_price=fill, proceeds_sol=proceeds,
                       pnl_sol=(pos.proceeds_sol - pos.cost_sol) if pos.closed else None,
                       pnl_pct=(100 * (pos.proceeds_sol - pos.cost_sol) / pos.cost_sol) if pos.closed else None)
            if reason == "take_profit_1":
                pos.tp1_done = True
            if pos.closed:
                pos.close_ts, pos.exit_reason = t, reason
                self.positions.remove(pos)
                self.closed.append(pos)
                self.j.log_position(pos)
                self.risk.on_close(t, pos.proceeds_sol - pos.cost_sol, self.broker.equity(t, self.positions))
                reg = getattr(self.book, "registry", None)
                if reg:                                  # le résultat est attribué aux wallets qui ont déclenché le signal
                    reg.record_signal_outcome(pos.wallets, 100 * (pos.proceeds_sol - pos.cost_sol) / pos.cost_sol, t)
                pnl = pos.proceeds_sol - pos.cost_sol
                log.info("SORTIE %s %s pnl=%.4f SOL", pos.symbol, reason, pnl)
                self._notify(f"{'🟢' if pnl > 0 else '🔴'} SORTIE {pos.symbol or pos.mint[:8]} ({reason}) "
                             f"{pnl:+.4f} SOL ({100 * pnl / pos.cost_sol:+.0f} %)", key=f"exit:{pos.id}")
            self.save_state()

    # ------------------------------------------------------------------ suivi contrefactuel
    def _track_watch(self, t):
        """Prix lu à l'instant EXACT ts0+h dans les deux modes (en live, le marché renvoie None s'il
        ne peut pas lire cet instant, au lieu d'un prix actuel déguisé : la métrique reste honnête)."""
        for w in self.watch:
            for h in HOURS:
                due = w["ts0"] + h * 3600
                if h not in w["r"] and t >= due:
                    p = self.market.price_at(w["mint"], due)
                    w["r"][h] = (p / w["price0"] - 1) * 100 if p else None
            if len(w["r"]) == len(HOURS) and not w.get("saved"):
                self.j.log_watch(w["mint"], w["ts0"], w["decision"], w["reasons"], w["price0"],
                                 w["r"][1], w["r"][6])
                w["saved"] = True

    def finish(self, ts):
        self.advance_to(ts)
        # les positions encore ouvertes restent ouvertes : le rapport les compte à la valeur prudente
        for pos in self.positions:
            self.j.log_position(pos)
        self.save_state()
