"""Registre des wallets découverts automatiquement (table `wallets` + journal `wallet_events`).

Cycle de vie : pending -> (évaluation) -> testing (poids débutant faible) -> tracked (poids qui monte si ses signaux gagnent)
-> degraded (poids divisé par 2) -> removed ; ou excluded / unknown (réévalués plus tard).
Chaque mouvement est journalisé avec sa raison. Rien n'est deviné : un wallet inconnu ou exclu a un poids de 0."""
import json

ACTIVE = ("testing", "tracked", "degraded")


class WalletRegistry:
    def __init__(self, journal, cfg):
        self.j, self.d = journal, cfg.discovery
        self._cache = {}
        self.refresh()

    # ---------------------------------------------------------------- lecture (cache : appelé à chaque événement)
    def refresh(self):
        self._cache = {a: (w, st) for a, w, st in self.j.c.execute("SELECT address,weight,status FROM wallets")}

    def weight(self, addr):
        w, st = self._cache.get(addr, (0.0, "unknown"))
        return w if st in ACTIVE else 0.0

    def known(self, addr):
        return addr in self._cache

    def active_addresses(self):
        return [a for a, (w, st) in self._cache.items() if st in ACTIVE and w > 0]

    def get(self, addr):
        cur = self.j.c.execute("SELECT * FROM wallets WHERE address=?", (addr,))
        row = cur.fetchone()
        return dict(zip([c[0] for c in cur.description], row)) if row else None

    def tracked(self):
        cur = self.j.c.execute("SELECT * FROM wallets WHERE status IN ('testing','tracked','degraded') AND weight>0 "
                               "ORDER BY weight DESC, score DESC")
        cols = [c[0] for c in cur.description]
        return [dict(zip(cols, r)) for r in cur.fetchall()]

    def counts(self):
        return dict(self.j.c.execute("SELECT status,COUNT(*) FROM wallets GROUP BY status").fetchall())

    def events_since(self, ts):
        return self.j.c.execute("SELECT ts,address,action,reason,old_weight,new_weight FROM wallet_events "
                                "WHERE ts>=? ORDER BY ts", (ts,)).fetchall()

    # ---------------------------------------------------------------- écriture
    def _event(self, ts, addr, action, reason, old, new):
        self.j.c.execute("INSERT INTO wallet_events VALUES (?,?,?,?,?,?)", (ts, addr, action, reason, old, new))

    def add_pending(self, addr, source_token, ts):
        if self.known(addr):
            return False
        self.j.c.execute("INSERT INTO wallets(address,status,reason,weight,source_token,first_seen_ts,next_eval_ts) "
                         "VALUES (?,?,?,?,?,?,?)", (addr, "pending", f"found_on:{(source_token or '')[:8]}", 0.0, source_token, ts, ts))
        self._event(ts, addr, "candidate", f"early buyer of {(source_token or '')[:8]}", 0.0, 0.0)
        self.j.c.commit()
        self._cache[addr] = (0.0, "pending")
        return True

    def due_for_eval(self, now, limit=1):
        return [r[0] for r in self.j.c.execute(
            "SELECT address FROM wallets WHERE status IN ('pending','excluded','unknown') AND next_eval_ts<=? "
            "ORDER BY (status='pending') DESC, first_seen_ts LIMIT ?", (now, limit))]

    def apply_verdict(self, addr, v, ts):
        m, d = v.metrics or {}, self.d
        old = self.get(addr) or {}
        if v.status == "eligible":
            status, weight, nxt, action = "testing", d.starter_weight, ts + 7 * 86400, "added"
        elif v.status == "unknown":
            status, weight, nxt, action = "unknown", 0.0, ts + d.reeval_unknown_days * 86400, "not_added"
        else:
            status, weight, nxt, action = "excluded", 0.0, ts + d.reeval_excluded_days * 86400, "not_added"
        if old.get("status") in ACTIVE and v.status != "eligible":      # un wallet suivi qui ne passe plus la réévaluation
            status, weight, action = "removed", 0.0, "removed"
        if old.get("status") in ACTIVE and v.status == "eligible":      # réévaluation réussie : on garde son poids actuel
            status, weight, action = old["status"], old["weight"], "reevaluated"
        self.j.c.execute(
            "UPDATE wallets SET status=?,reason=?,score=?,weight=?,n_trades=?,n_closed=?,realized_pnl_sol=?,win_rate=?,"
            "age_days=?,age_complete=?,tokens_per_day=?,sniper_share=?,last_eval_ts=?,next_eval_ts=? WHERE address=?",
            (status, v.reason, v.score, weight, m.get("n_trades"), m.get("n_closed"), m.get("realized_pnl_sol"),
             m.get("win_rate"), m.get("age_days"), int(bool(m.get("age_complete"))), m.get("tokens_per_day"),
             m.get("sniper_share"), ts, nxt, addr))
        self._event(ts, addr, action, f"{v.status}:{v.reason} score={v.score}", old.get("weight") or 0.0, weight)
        self.j.c.commit()
        self._cache[addr] = (weight, status)

    def record_signal_outcome(self, wallets, pnl_pct, ts):
        """Attribue le résultat d'une position fermée aux wallets qui ont déclenché le signal (suivis automatiquement)."""
        for a in wallets or []:
            row = self.get(a)
            if not row or row["status"] not in ACTIVE:
                continue
            recent = (json.loads(row["recent_pnls"] or "[]") + [pnl_pct])[-10:]
            won, lost = row["signals_won"] + (pnl_pct > 0), row["signals_lost"] + (pnl_pct <= 0)
            consec = 0 if pnl_pct > 0 else row["consec_losses"] + 1
            self.j.c.execute("UPDATE wallets SET signals_won=?,signals_lost=?,consec_losses=?,recent_pnls=? WHERE address=?",
                             (won, lost, consec, json.dumps(recent), a))
        self.j.c.commit()

    def maintenance(self, now):
        """Passe quotidienne : dégrade / retire les wallets qui perdent, promeut ceux dont les signaux gagnent."""
        d, out = self.d, []
        for row in self.tracked():
            a, w = row["address"], row["weight"]
            recent = json.loads(row["recent_pnls"] or "[]")
            last = recent[-d.recent_window:]
            losing_streak = row["consec_losses"] >= d.degrade_after_losses
            negative_recent = len(last) >= d.recent_window and sum(last) < 0
            if losing_streak or negative_recent:
                why = (f"{row['consec_losses']} signaux perdants d'affilée" if losing_streak
                       else f"P&L récent négatif sur {len(last)} signaux ({sum(last):+.1f} %)")
                if row["stage"] == 0:
                    new, st, action = round(w * 0.5, 3), "degraded", "degraded"
                    self.j.c.execute("UPDATE wallets SET weight=?,status=?,stage=1,consec_losses=0,recent_pnls='[]' WHERE address=?",
                                     (new, st, a))
                else:
                    new, st, action = 0.0, "removed", "removed"
                    self.j.c.execute("UPDATE wallets SET weight=0,status='removed' WHERE address=?", (a,))
                self._event(now, a, action, why, w, new)
                out.append((a, action, why, w, new))
                continue
            n = row["signals_won"] + row["signals_lost"]
            if row["stage"] == 0 and n >= 3 and row["signals_won"] / n >= 0.5 and last and sum(last) > 0 and w < d.max_weight:
                new = round(min(d.max_weight, w + d.promote_step), 3)
                self.j.c.execute("UPDATE wallets SET weight=?,status='tracked' WHERE address=?", (new, a))
                why = f"{row['signals_won']}/{n} signaux gagnants, P&L récent {sum(last):+.1f} %"
                self._event(now, a, "promoted", why, w, new)
                out.append((a, "promoted", why, w, new))
        self.j.c.commit()
        self.refresh()
        return out
