"""Revue des décisions : pour CHAQUE coin détecté, qu'a décidé le bot et que s'est-il passé ensuite ?
Répond à « le bot s'est-il trompé ? » : entrées qui ont chuté (erreurs), rejets qui ont explosé (occasions
manquées), rejets qui ont chuté (bons rejets). Basé sur les prix à +1 h et +6 h relevés par le moteur.

Limites : ce sont des variations de prix, pas des gains exécutables (frais et slippage non inclus : c'est
pourquoi le seuil « monté » est de +20 % et non +0 %) ; sur un petit échantillon, aucune conclusion ferme."""
import json

UP_PCT, DOWN_PCT = 20.0, -20.0

# Rejets de SÉCURITÉ : si le prix « monte » après, la hausse n'est généralement pas réalisable (honeypot : impossible
# de revendre ; autorité mint active : le créateur peut diluer ; coût de sortie prohibitif...). Ils ne comptent donc
# pas comme « occasions manquées ».
SAFETY_REASONS = ("no_sell_route", "mint_authority_active", "freeze_authority_active", "rugcheck_", "high_sell_impact",
                  "high_roundtrip_cost", "unknown:")


def _is_safety(reasons):
    return any(str(r).startswith(SAFETY_REASONS) for r in reasons)


def classify(decision, r, up=UP_PCT, down=DOWN_PCT):
    """Retourne (étiquette du mouvement, verdict)."""
    if r is None:
        return "inconnu", "non évalué (prix indisponible)"
    move = "monté" if r >= up else ("chuté" if r <= down else "stable")
    if decision == "enter":
        return move, {"monté": "✅ bonne entrée", "chuté": "❌ erreur (entrée sur un coin qui a chuté)",
                      "stable": "➖ neutre"}[move]
    if decision == "reject":
        return move, {"chuté": "✅ bon rejet", "monté": "⚠️ occasion manquée (rejeté puis monté)",
                      "stable": "➖ neutre"}[move]
    return move, f"non évalué ({decision})"


def review(journal, horizon_h=6, up=UP_PCT, down=DOWN_PCT):
    c = journal.c
    col = "r_6h" if horizon_h == 6 else "r_1h"
    rows = []
    for mint, ts0, decision, reasons, price0, r1, r6 in c.execute(
            "SELECT mint,ts0,decision,reasons,price0,r_1h,r_6h FROM watch ORDER BY ts0"):
        r = r6 if horizon_h == 6 else r1
        cand = c.execute("SELECT symbol,score FROM candidates WHERE mint=? AND ABS(ts-?)<1 ORDER BY id DESC LIMIT 1",
                         (mint, ts0)).fetchone() or ("", None)
        pos = c.execute("SELECT pnl_pct,exit_reason FROM positions WHERE mint=? AND ABS(open_ts-?)<1 "
                        "AND close_ts IS NOT NULL", (mint, ts0)).fetchone()
        move, verdict = classify(decision, r, up, down)
        reasons_l = json.loads(reasons or "[]")
        if decision == "reject" and verdict.startswith("⚠️") and _is_safety(reasons_l):
            verdict = "🛡️ rejet de sécurité (la hausse n'aurait probablement pas été réalisable)"
        rows.append({"mint": mint, "symbol": cand[0], "score": cand[1], "decision": decision,
                     "reasons": reasons_l, "r_1h": r1, "r_6h": r6, "r": r, "move": move,
                     "verdict": verdict, "realized_pct": pos[0] if pos else None, "exit": pos[1] if pos else None})
    return rows


def summarize(rows):
    s = {"bonne_entree": 0, "erreur": 0, "entree_neutre": 0, "bon_rejet": 0, "occasion_manquee": 0,
         "rejet_neutre": 0, "rejet_securite": 0, "non_evalue": 0}
    for r in rows:
        v = r["verdict"]
        key = ("bonne_entree" if v.startswith("✅ bonne") else "erreur" if v.startswith("❌") else
               "bon_rejet" if v.startswith("✅ bon rejet") else "occasion_manquee" if v.startswith("⚠️") else
               "rejet_securite" if v.startswith("🛡️") else
               "non_evalue" if v.startswith("non") else
               "entree_neutre" if r["decision"] == "enter" else "rejet_neutre")
        s[key] += 1
    return s


def format_review(rows, horizon_h=6, up=UP_PCT, down=DOWN_PCT):
    L = ["=" * 78, f"REVUE DES DÉCISIONS (mouvement à +{horizon_h} h ; monté >= +{up:g} %, chuté <= {down:g} %)", "=" * 78]
    if not rows:
        return "\n".join(L + ["Aucune décision avec suivi complet pour l'instant : laisse tourner le bot au moins "
                              f"{horizon_h} h après les premiers signaux."])
    for r in rows:
        rr = "  n/a" if r["r"] is None else f"{r['r']:+5.0f}%"
        real = f"  réalisé {r['realized_pct']:+.0f}% ({r['exit']})" if r["realized_pct"] is not None else ""
        why = f" [{', '.join(r['reasons'])[:46]}]" if r["reasons"] else ""
        L.append(f"{(r['symbol'] or r['mint'])[:12]:12s} {r['decision']:11s} {rr}  {r['verdict']}{real}{why}")
    s = summarize(rows)
    entered = s["bonne_entree"] + s["erreur"] + s["entree_neutre"]
    rejected = s["bon_rejet"] + s["occasion_manquee"] + s["rejet_neutre"] + s["rejet_securite"]
    L += ["", "BILAN",
          f"  Entrées : {entered}  → bonnes {s['bonne_entree']}, erreurs {s['erreur']}, neutres {s['entree_neutre']}",
          f"  Rejets  : {rejected}  → bons rejets {s['bon_rejet']}, occasions manquées {s['occasion_manquee']}, "
          f"rejets de sécurité {s['rejet_securite']}, neutres {s['rejet_neutre']}"]
    if s["bonne_entree"] + s["erreur"]:
        L.append(f"  Précision des entrées (hors neutres) : {s['bonne_entree'] / (s['bonne_entree'] + s['erreur']):.0%}")
    if s["bon_rejet"] + s["occasion_manquee"]:
        L.append(f"  Qualité des rejets (hors neutres)    : {s['bon_rejet'] / (s['bon_rejet'] + s['occasion_manquee']):.0%}")
    L.append(f"  (échantillon : {len(rows)} décisions : en dessous de ~100, ces pourcentages ne prouvent rien)")
    return "\n".join(L)
