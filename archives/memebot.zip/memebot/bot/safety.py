"""Vérifications de sécurité d'un token (LIVE). Chaque contrôle renvoie None si la donnée est
indisponible, et les filtres rejettent alors le token (fail closed).

NON TESTÉ contre les vrais services dans mon environnement (pas d'internet) : formats de réponse
lus de façon défensive ; à valider au premier lancement."""
import logging
import os

from .http import HttpError, get_json, post_json

log = logging.getLogger("safety")
WSOL = "So11111111111111111111111111111111111111112"


class SafetyChecker:
    def __init__(self, rpc_url=None, jupiter_base=None, jupiter_key=None, mode="full"):
        self.mode = mode                   # "full" (RPC + RugCheck + Jupiter) ou "rugcheck_only" (paper trading sur API publiques)
        self._rc_cache = {}
        self.rpc_url = rpc_url
        self.jup_base = (jupiter_base or os.getenv("JUPITER_BASE_URL") or "https://api.jup.ag").rstrip("/")
        self.jup_key = jupiter_key or os.getenv("JUPITER_API_KEY")

    # --- 1. autorités du mint (source de vérité on-chain) ---------------------------------
    def mint_info(self, mint):
        try:
            r = post_json(self.rpc_url, {"jsonrpc": "2.0", "id": 1, "method": "getAccountInfo",
                                         "params": [mint, {"encoding": "jsonParsed"}]})
            info = r["result"]["value"]["data"]["parsed"]["info"]
            return {"mint_authority_active": info.get("mintAuthority") is not None,
                    "freeze_authority_active": info.get("freezeAuthority") is not None,
                    "decimals": int(info["decimals"])}
        except (HttpError, KeyError, TypeError, ValueError) as e:
            log.warning("mint_info(%s) indisponible : %s", mint, e)
            return None

    # --- 2. RugCheck : niveaux de risque ----------------------------------------------------
    def rugcheck(self, mint):
        try:
            r = get_json(f"https://api.rugcheck.xyz/v1/tokens/{mint}/report/summary")
            risks = r.get("risks")
            if risks is None:
                return None
            return [str(x.get("level", "")).lower() for x in risks], [str(x.get("name", "")) for x in risks]
        except (HttpError, AttributeError, TypeError) as e:
            log.warning("rugcheck(%s) indisponible : %s", mint, e)
            return None

    # --- 3. test de vente via Jupiter : route de sortie + impact à NOTRE taille ----------------
    def sell_test(self, mint, decimals, price_sol, size_sol):
        """Cote la vente de la valeur de notre position. Impact calculé nous-mêmes (indépendant
        de la sémantique du champ priceImpactPct)."""
        if not price_sol or decimals is None:
            return None
        tokens_ui = size_sol / price_sol
        headers = {"x-api-key": self.jup_key} if self.jup_key else None
        try:
            q = get_json(f"{self.jup_base}/swap/v1/quote", headers=headers, params={
                "inputMint": mint, "outputMint": WSOL, "amount": int(tokens_ui * 10 ** decimals),
                "slippageBps": 300})
            out_sol = int(q["outAmount"]) / 1e9
            return True, max(0.0, (1 - out_sol / size_sol) * 100.0)
        except HttpError as e:
            # 400/404 = pas de route : traité comme "vente impossible". Autre erreur = inconnu.
            if "HTTP 400" in str(e) or "HTTP 404" in str(e):
                return False, None
            log.warning("sell_test(%s) indisponible : %s", mint, e)
            return None
        except (KeyError, ValueError, TypeError):
            return None

    def roundtrip_test(self, mint, size_sol):
        """Coût aller-retour MESURÉ : cote l'achat de size_sol puis la revente des tokens obtenus.
        Inclut frais et taxes du token (ce qu'une cotation intègre). Non testé contre le réseau."""
        headers = {"x-api-key": self.jup_key} if self.jup_key else None
        try:
            b = get_json(f"{self.jup_base}/swap/v1/quote", headers=headers, params={
                "inputMint": WSOL, "outputMint": mint, "amount": int(size_sol * 1e9), "slippageBps": 300})
            s_ = get_json(f"{self.jup_base}/swap/v1/quote", headers=headers, params={
                "inputMint": mint, "outputMint": WSOL, "amount": int(b["outAmount"]), "slippageBps": 300})
            return max(0.0, (1 - int(s_["outAmount"]) / 1e9 / size_sol) * 100.0)
        except (HttpError, KeyError, ValueError, TypeError) as e:
            log.warning("roundtrip_test(%s) indisponible : %s", mint, e)
            return None

    # --- 2 bis. RugCheck : rapport complet (route /report), mis en cache 10 min -------------------------------
    def rugcheck_report(self, mint, ttl=600):
        """Niveaux de risque, autorités, concentration des holders, drapeau « rugged ». None si indisponible.
        Format NON vérifié depuis mon environnement : lecture défensive (validate_sources.py affiche la forme réelle)."""
        import time
        c = self._rc_cache.get(mint)
        if c and time.time() - c[0] < ttl:
            return c[1]
        try:
            r = get_json(f"https://api.rugcheck.xyz/v1/tokens/{mint}/report")
            risks = r.get("risks")
            if not isinstance(risks, list):
                return None
            tok = r.get("token") or {}
            holders = r.get("topHolders") or []
            pcts = [float(h.get("pct")) for h in holders[:10] if isinstance(h, dict) and h.get("pct") is not None]
            out = {"levels": [str(x.get("level", "")).lower() for x in risks if isinstance(x, dict)],
                   "names": [str(x.get("name", "")) for x in risks if isinstance(x, dict)],
                   "mint_authority_active": (tok.get("mintAuthority") is not None) if "mintAuthority" in tok else
                                            (r.get("mintAuthority") is not None) if "mintAuthority" in r else None,
                   "freeze_authority_active": (tok.get("freezeAuthority") is not None) if "freezeAuthority" in tok else
                                              (r.get("freezeAuthority") is not None) if "freezeAuthority" in r else None,
                   "top10_pct": sum(pcts) if pcts else None, "rugged": bool(r.get("rugged"))}
            self._rc_cache[mint] = (time.time(), out)
            return out
        except (HttpError, AttributeError, TypeError, ValueError) as e:
            log.warning("rugcheck_report(%s) indisponible : %s", mint, e)
            return None

    def fill(self, info, size_sol):
        if self.mode == "rugcheck_only":
            rep = self.rugcheck_report(info.mint)
            if rep:
                info.rugcheck_levels, info.rugcheck_risks = rep["levels"], rep["names"]
                info.mint_authority_active = rep["mint_authority_active"]
                info.freeze_authority_active = rep["freeze_authority_active"]
                info.top10_pct = rep["top10_pct"]
                # Sans cotation Jupiter, la « route de vente » est DÉDUITE (pas de risque critique, pas de rug) :
                # détection de honeypot plus faible qu'en mode complet. Limite assumée, documentée dans le README.
                info.sell_quote_ok = (not rep["rugged"]) and ("danger" not in rep["levels"])
            return

        mi = self.mint_info(info.mint)
        if mi:
            info.mint_authority_active = mi["mint_authority_active"]
            info.freeze_authority_active = mi["freeze_authority_active"]
        rc = self.rugcheck(info.mint)
        if rc:
            info.rugcheck_levels, info.rugcheck_risks = rc
        if mi:
            st = self.sell_test(info.mint, mi["decimals"], info.price_sol, size_sol)
            if st:
                info.sell_quote_ok, info.sell_impact_pct = st
        info.roundtrip_cost_pct = self.roundtrip_test(info.mint, size_sol)   # None => le moteur utilise l'estimation
