"""Source LIVE : surveille les wallets via RPC (getSignaturesForAddress + getTransaction).

⚠ Limites assumées : (1) latence = intervalle de sondage (2 min par défaut), donc PAS adapté au
snipe ; (2) chaque appel consomme des crédits RPC. Le vrai remède à la latence est un webhook
(étape suivante). parse_swap() est testé sur des transactions synthétiques ; le reste n'a pas été
exécuté contre le réseau dans mon environnement."""
import logging
import time

from ..http import RateLimiter, post_json
from ..models import WalletEvent

log = logging.getLogger("rpc_poll")
WSOL = "So11111111111111111111111111111111111111112"
USDC = "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
USDT = "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB"


def _ui(b):
    t = b.get("uiTokenAmount", {})
    return float(t.get("uiAmountString") or t.get("uiAmount") or 0)


def parse_swap(tx, wallet, min_sol=0.001):
    """Déduit achat/vente d'un wallet à partir des variations de soldes. None si ambigu."""
    meta = tx.get("meta") or {}
    if meta.get("err") is not None:
        return None
    msg = tx["transaction"]["message"]
    keys = [k["pubkey"] if isinstance(k, dict) else k for k in msg["accountKeys"]]
    sol = 0.0
    if wallet in keys:
        i = keys.index(wallet)
        sol = (meta["postBalances"][i] - meta["preBalances"][i]) / 1e9
        if i == 0:
            sol += meta.get("fee", 0) / 1e9
    deltas = {}
    for sign, k in ((-1, "preTokenBalances"), (1, "postTokenBalances")):
        for b in meta.get(k) or []:
            if b.get("owner") == wallet:
                deltas[b["mint"]] = deltas.get(b["mint"], 0.0) + sign * _ui(b)
    sol += deltas.pop(WSOL, 0.0)
    for m in (USDC, USDT):
        deltas.pop(m, None)
    moved = {m: d for m, d in deltas.items() if abs(d) > 0}
    if len(moved) != 1:
        return None
    mint, d = next(iter(moved.items()))
    if d > 0 and sol < -min_sol:
        side, amt = "buy", -sol
    elif d < 0 and sol > min_sol:
        side, amt = "sell", sol
    else:
        return None
    return {"side": side, "mint": mint, "sol_amount": amt, "token_amount": abs(d),
            "ts": tx.get("blockTime"), "sig": tx["transaction"]["signatures"][0]}


class RpcPollSource:
    def __init__(self, rpc_url, wallets_fn, cfg, journal):
        self.url, self.wallets_fn, self.cfg, self.j = rpc_url, wallets_fn, cfg, journal
        self.limiter = RateLimiter(cfg.live.rpc_rps)
        self.last_sig = journal.kv_get("last_sig", {})
        self.calls_today, self.day = 0, None
        self._rr = 0
        self._next_poll = {}

    def estimate_calls_per_day(self, n_wallets):
        # 1 appel de signatures par wallet et par intervalle + ~1 getTransaction par transaction (estimée à 20/jour/wallet)
        return int(n_wallets * 86400 / self.cfg.live.wallet_poll_interval_s + n_wallets * 20)

    def _rpc(self, method, params):
        day = int(time.time() // 86400)
        if day != self.day:
            self.day, self.calls_today = day, 0
        if self.calls_today >= self.cfg.live.max_rpc_calls_per_day:
            raise RuntimeError("budget RPC journalier atteint : le bot cesse d'interroger (fail closed)")
        self.limiter.wait()
        self.calls_today += 1
        r = post_json(self.url, {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})
        if "error" in r:
            raise RuntimeError(f"RPC {method} : {r['error']}")
        return r["result"]

    def poll(self):
        wallets = sorted(self.wallets_fn())
        out, now = [], time.time()
        if not wallets:
            return out
        for _ in range(min(self.cfg.live.rpc_wallets_per_poll, len(wallets))):
            w = wallets[self._rr % len(wallets)]
            self._rr += 1
            if now < self._next_poll.get(w, 0):
                continue
            self._next_poll[w] = now + self.cfg.live.wallet_poll_interval_s
            opts = {"limit": 20}
            if self.last_sig.get(w):
                opts["until"] = self.last_sig[w]
            sigs = self._rpc("getSignaturesForAddress", [w, opts])
            if not sigs:
                continue
            first_time = w not in self.last_sig
            self.last_sig[w] = sigs[0]["signature"]
            self.j.kv_set("last_sig", self.last_sig)
            if first_time:
                continue                      # pas de rattrapage de l'historique au démarrage
            for s in reversed([s for s in sigs if s.get("err") is None]):
                tx = self._rpc("getTransaction", [s["signature"], {"encoding": "jsonParsed",
                                                                    "maxSupportedTransactionVersion": 0}])
                p = tx and parse_swap(tx, w)
                if p:
                    out.append(WalletEvent(ts=p["ts"] or now, wallet=w, side=p["side"], mint=p["mint"],
                                           sol_amount=p["sol_amount"], token_amount=p["token_amount"], sig=p["sig"]))
        return sorted(out, key=lambda e: e.ts)
