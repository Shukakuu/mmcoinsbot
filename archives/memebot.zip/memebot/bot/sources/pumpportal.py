"""Suivi OPTIONNEL des wallets de wallets.txt via PumpPortal (WebSocket public).

  wss://pumpportal.fun/api/data   puis   {"method": "subscribeAccountTrade", "keys": [adresses...]}

Nécessite `pip install websockets`. ⚠ NON TESTÉ contre le vrai service dans mon environnement (pas d'internet) ; le format des
messages (txType, mint, traderPublicKey, solAmount, tokenAmount, signature) vient de la documentation publique de PumpPortal.
Couvre les trades pump.fun / pumpswap seulement. Limite d'abonnements (5 sans clé) à confirmer."""
import asyncio
import json
import logging
import threading
import time
from collections import deque

from ..health import HEALTH
from ..models import WalletEvent

log = logging.getLogger("pumpportal")
URL = "wss://pumpportal.fun/api/data"


def parse_trade(msg, now):
    """Message PumpPortal -> WalletEvent. None pour les accusés d'abonnement ou messages inexploitables."""
    if not isinstance(msg, dict):
        return None
    side = str(msg.get("txType", "")).lower()
    if side not in ("buy", "sell") or not msg.get("mint") or not msg.get("traderPublicKey"):
        return None
    try:
        sol = float(msg["solAmount"])
        tok = float(msg["tokenAmount"]) if msg.get("tokenAmount") is not None else None
    except (KeyError, TypeError, ValueError):
        return None
    if sol <= 0:
        return None
    return WalletEvent(ts=now, wallet=msg["traderPublicKey"], side=side, mint=msg["mint"], sol_amount=sol,
                       token_amount=tok, sig=str(msg.get("signature", "")))


class PumpPortalSource:
    def __init__(self, keys, now_fn=time.time, connect=None):
        self.keys = list(keys)
        self.now_fn = now_fn
        self.queue = deque(maxlen=5000)
        self._connect = connect
        self._thread = None

    def start(self):
        if not self.keys:
            log.warning("PumpPortal : aucune adresse à suivre (wallets.txt vide)")
            return False
        if self._connect is None:
            try:
                import websockets
                self._connect = websockets.connect
            except ImportError:
                log.warning("PumpPortal désactivé : `pip install websockets` requis")
                return False
        self._thread = threading.Thread(target=lambda: asyncio.run(self._run()), daemon=True)
        self._thread.start()
        return True

    async def _consume(self, ws):
        await ws.send(json.dumps({"method": "subscribeAccountTrade", "keys": self.keys}))
        HEALTH.ok("pumpportal")
        async for raw in ws:
            try:
                ev = parse_trade(json.loads(raw), self.now_fn())
            except json.JSONDecodeError:
                continue
            if ev:
                self.queue.append(ev)

    async def _run(self):
        while True:
            try:
                async with self._connect(URL) as ws:
                    await self._consume(ws)
            except Exception as e:  # noqa: BLE001
                HEALTH.fail("pumpportal")
                log.warning("PumpPortal déconnecté : %s (nouvelle tentative dans 5 s)", e)
                await asyncio.sleep(5)

    def poll(self):
        out = []
        while self.queue:
            out.append(self.queue.popleft())
        return out
