"""DexScreener (API publique, sans clé) : découverte de tokens et données de paire.

  GET /token-profiles/latest/v1   et   GET /token-boosts/latest/v1      -> liste de {chainId, tokenAddress, ...}
  GET /token-pairs/v1/solana/{mint}                                     -> paires du token (prix, liquidité, volume...)

Le format des deux flux de DÉCOUVERTE a été vérifié sur une réponse réelle (16/10/2026, voir
tests/fixtures/dexscreener_boosts_real_sample.json). Le format de la route des PAIRES n'a pas pu être vérifié depuis
mon environnement : analyse défensive (liste directe ou {"pairs": [...]}), à confirmer avec validate_sources.py.

⚠ Ces flux sont des PROMOTIONS PAYANTES (profils améliorés, boosts) : ce n'est ni de la smart money ni un signal de
qualité. Le paper trading mesurera s'ils valent quelque chose ; la prudence est de s'attendre à un biais défavorable."""
import time

from ..http import RateLimiter, get_json

BASE = "https://api.dexscreener.com"
WSOL = "So11111111111111111111111111111111111111112"
FEEDS = (("profile", "/token-profiles/latest/v1"), ("boost", "/token-boosts/latest/v1"))


def parse_discovery(payload, source, chain="solana"):
    """Extrait les tokens de la chaîne demandée d'un flux de découverte. Dédoublonne par adresse (somme des boosts)."""
    out = {}
    for it in payload if isinstance(payload, list) else []:
        if not isinstance(it, dict) or it.get("chainId") != chain or not isinstance(it.get("tokenAddress"), str):
            continue
        mint = it["tokenAddress"]
        links = it.get("links") or []
        c = out.setdefault(mint, {"mint": mint, "source": source, "boost_amount": 0,
                                  "has_twitter": False, "n_links": 0})
        c["boost_amount"] += int(it.get("amount") or 0)
        c["has_twitter"] = c["has_twitter"] or any(l.get("type") == "twitter" for l in links if isinstance(l, dict))
        c["n_links"] = max(c["n_links"], len(links))
    return list(out.values())


def best_sol_pair(payload):
    """Paire la plus liquide cotée en SOL. Accepte une liste directe ou {"pairs": [...]}."""
    pairs = payload if isinstance(payload, list) else (payload or {}).get("pairs") or []
    sol = [p for p in pairs if isinstance(p, dict) and p.get("chainId") == "solana"
           and (p.get("quoteToken") or {}).get("address") == WSOL]
    return max(sol, key=lambda p: (p.get("liquidity") or {}).get("usd") or 0, default=None)


def pair_fields(pair, now=None):
    """Champs utiles d'une paire. Les valeurs absentes restent None (le moteur traite l'inconnu comme un risque)."""
    now = now or time.time()

    def num(x):
        try:
            return float(x)
        except (TypeError, ValueError):
            return None
    price_native, price_usd = num(pair.get("priceNative")), num(pair.get("priceUsd"))
    h1 = (pair.get("txns") or {}).get("h1") or {}
    return {
        "symbol": (pair.get("baseToken") or {}).get("symbol", ""),
        "price_sol": price_native,
        "sol_usd": (price_usd / price_native) if price_usd and price_native else None,
        "liquidity_usd": num((pair.get("liquidity") or {}).get("usd")),
        "fdv_usd": num(pair.get("fdv")),
        "pair_age_min": (now - pair["pairCreatedAt"] / 1000.0) / 60.0 if pair.get("pairCreatedAt") else None,
        "volume_h1_usd": num((pair.get("volume") or {}).get("h1")),
        "buys_h1": h1.get("buys"), "sells_h1": h1.get("sells"),
        "price_change_h1_pct": num((pair.get("priceChange") or {}).get("h1")),
        "price_change_m5_pct": num((pair.get("priceChange") or {}).get("m5")),
        "price_change_h24_pct": num((pair.get("priceChange") or {}).get("h24")),
    }


class DexClient:
    def __init__(self, get=get_json, pairs_rps=4.0):
        self.get = get
        self.pairs_limiter = RateLimiter(pairs_rps)            # ~240 req/min < 300 autorisées

    def discovery(self):
        merged = {}
        for source, path in FEEDS:
            for c in parse_discovery(self.get(BASE + path), source):
                if c["mint"] in merged:
                    m = merged[c["mint"]]
                    m["boost_amount"] += c["boost_amount"]
                    m["has_twitter"] = m["has_twitter"] or c["has_twitter"]
                    m["source"] = "profile+boost"
                else:
                    merged[c["mint"]] = c
        return list(merged.values())

    def pairs(self, mint):
        self.pairs_limiter.wait()
        return best_sol_pair(self.get(f"{BASE}/token-pairs/v1/solana/{mint}"))
