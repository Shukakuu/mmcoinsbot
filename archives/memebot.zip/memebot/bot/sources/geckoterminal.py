"""GeckoTerminal : bougies OHLCV d'un pool, pour rejouer la mécanique de sortie sur des prix réels récents.

  GET https://api.geckoterminal.com/api/v2/networks/solana/pools/{pool}/ohlcv/{minute|hour|day}?aggregate=1&limit=500

API publique sans clé, limitée (~10 appels/min). NON TESTÉ contre le vrai service dans mon environnement (accès
automatisé refusé à mon outil) : format défensif ({"data": {"attributes": {"ohlcv_list": [[ts,o,h,l,c,v], ...]}}}, du
plus récent au plus ancien)."""
from ..http import RateLimiter, get_json

BASE = "https://api.geckoterminal.com/api/v2"
_limiter = RateLimiter(10 / 60.0)


def parse_ohlcv(payload):
    """Retourne les bougies triées de la plus ancienne à la plus récente : [(ts, o, h, l, c, v)]."""
    try:
        lst = payload["data"]["attributes"]["ohlcv_list"]
        rows = [(int(r[0]), float(r[1]), float(r[2]), float(r[3]), float(r[4]), float(r[5])) for r in lst]
    except (KeyError, TypeError, ValueError, IndexError):
        return []
    return sorted(rows)


def fetch_ohlcv(pool, timeframe="minute", aggregate=1, limit=500, get=get_json, network="solana"):
    _limiter.wait()
    return parse_ohlcv(get(f"{BASE}/networks/{network}/pools/{pool}/ohlcv/{timeframe}",
                           params={"aggregate": aggregate, "limit": limit, "currency": "usd"}))
