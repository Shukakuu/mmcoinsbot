"""Source LIVE rapide : flux de trades « smart money » et KOL de GMGN, via leur CLI officielle (gmgn-cli).

  npm install -g gmgn-cli      # + clé API personnelle sur https://gmgn.ai/ai  ->  GMGN_API_KEY
  (GMGN précise : n'appelle pas les endpoints web directement ; réseau IPv4 uniquement)

⚠ NON TESTÉ contre le vrai service dans mon environnement (pas d'internet). Les noms de champs viennent de la
documentation publique de GMGN et de descriptions tierces (maker, side, base_address, amount_usd ; prix et horodatage
sous des noms probables) : l'analyse est défensive, et `validate_sources.py` affiche la forme réelle des réponses.
Limite connue : GMGN ne donne pas l'origine des fonds des wallets, donc l'indépendance des wallets n'est pas vérifiable ;
le filtre anti-arroseurs (bot/convergence.py) compense en partie."""
import json
import logging
import os
import subprocess
import time
from collections import OrderedDict
from datetime import datetime

from ..health import HEALTH
from ..models import WalletEvent

log = logging.getLogger("gmgn")
SKIP_MINTS = {"So11111111111111111111111111111111111111112",
              "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB"}
TS_KEYS = ("timestamp", "block_time", "time", "ts", "trade_time", "created_at")
PRICE_KEYS = ("price_usd", "base_price_usd", "price", "token_price_usd")


def run_cli(args, timeout=30):
    """Appelle gmgn-cli et renvoie le JSON. Lève RuntimeError en cas d'échec (jamais de clé dans le message)."""
    try:
        out = subprocess.run(["gmgn-cli", *args], capture_output=True, text=True, timeout=timeout, env=os.environ.copy())
    except FileNotFoundError as e:
        raise RuntimeError("gmgn-cli introuvable (npm install -g gmgn-cli)") from e
    except subprocess.TimeoutExpired as e:
        raise RuntimeError("gmgn-cli : délai dépassé") from e
    if out.returncode != 0:
        raise RuntimeError(f"gmgn-cli code {out.returncode} : {out.stderr.strip()[:200]}")
    try:
        return json.loads(out.stdout)
    except json.JSONDecodeError as e:
        raise RuntimeError("gmgn-cli : sortie non JSON") from e


def extract_records(obj):
    """Trouve la liste de trades quelle que soit l'enveloppe ({data:{list:[...]}}, [...], etc.)."""
    if isinstance(obj, list):
        if obj and all(isinstance(x, dict) for x in obj) and any("maker" in x and "base_address" in x for x in obj):
            return obj
        for x in obj:
            r = extract_records(x)
            if r:
                return r
    elif isinstance(obj, dict):
        for v in obj.values():
            r = extract_records(v)
            if r:
                return r
    return []


def parse_ts(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v) / 1000.0 if v > 1e12 else float(v)
    try:
        return float(v) / 1000.0 if float(v) > 1e12 else float(v)
    except (TypeError, ValueError):
        pass
    try:
        return datetime.fromisoformat(str(v).replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def to_event(rec, sol_usd, now):
    """Convertit un enregistrement GMGN en WalletEvent. None si inexploitable."""
    maker, side, mint = rec.get("maker"), str(rec.get("side", "")).lower(), rec.get("base_address")
    if not maker or side not in ("buy", "sell") or not mint or mint in SKIP_MINTS:
        return None
    try:
        usd = float(rec.get("amount_usd"))
    except (TypeError, ValueError):
        return None
    if usd <= 0 or not sol_usd:
        return None
    ts = next((parse_ts(rec[k]) for k in TS_KEYS if rec.get(k) is not None and parse_ts(rec[k]) is not None), None)
    price_usd = next((float(rec[k]) for k in PRICE_KEYS if rec.get(k) not in (None, "", 0, "0")), None)
    sol_amount = usd / sol_usd
    token_amount = (usd / price_usd) if price_usd else None
    sig = str(rec.get("id") or rec.get("tx_hash") or f"{maker}:{mint}:{ts}")
    return WalletEvent(ts=ts if ts is not None else now, wallet=maker, side=side, mint=mint,
                       sol_amount=sol_amount, token_amount=token_amount, sig=sig)


class GmgnSource:
    def __init__(self, book, cfg, sol_usd_fn, runner=run_cli, now_fn=time.time, commands=None):
        self.book, self.cfg, self.sol_usd_fn, self.runner, self.now_fn = book, cfg, sol_usd_fn, runner, now_fn
        chain = cfg.live.chain
        self.commands = commands or [["track", "smartmoney", "--chain", chain, "--limit", "100", "--raw"],
                                     ["track", "kol", "--chain", chain, "--limit", "100", "--raw"]]
        self.seen = OrderedDict()
        self._next = 0.0

    def poll(self):
        now = self.now_fn()
        if now < self._next:
            return []
        self._next = now + self.cfg.live.gmgn_poll_interval_s
        events = []
        for cmd in self.commands:
            try:
                recs = extract_records(self.runner(cmd))
                HEALTH.ok("gmgn")
            except RuntimeError as e:
                HEALTH.fail("gmgn")
                log.warning("GMGN indisponible : %s", e)
                continue
            for rec in recs:
                ev = to_event(rec, self.sol_usd_fn(), now)
                if ev is None or ev.sig in self.seen:
                    continue
                self.seen[ev.sig] = True
                if len(self.seen) > 5000:
                    self.seen.popitem(last=False)
                self.book.register(ev.wallet, "gmgn")
                events.append(ev)
        return sorted(events, key=lambda e: e.ts)
