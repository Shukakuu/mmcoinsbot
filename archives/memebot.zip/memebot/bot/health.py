"""Disjoncteur de santé des sources de données : après N échecs RÉSEAU consécutifs d'un service,
le moteur n'ouvre plus de nouvelle position (les positions ouvertes restent gérées).
Un code 4xx (hors 429) est une vraie réponse du serveur, pas une panne."""


class Health:
    def __init__(self, threshold=5):
        self.threshold = threshold
        self.fails = {}

    def ok(self, service):
        self.fails[service] = 0

    def fail(self, service):
        self.fails[service] = self.fails.get(service, 0) + 1

    def degraded(self):
        return sorted(s for s, n in self.fails.items() if n >= self.threshold)

    def reset(self):
        self.fails.clear()


HEALTH = Health()
