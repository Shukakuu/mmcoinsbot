"""Porte de promotion : le bot n'a le droit d'envisager de l'argent réel que si les résultats SIMULÉS,
nets de frais, passent des critères statistiques (et pas seulement « le total est positif »)."""
import random


def _profit_factor(xs):
    gains, losses = sum(x for x in xs if x > 0), -sum(x for x in xs if x < 0)
    return float("inf") if losses == 0 and gains > 0 else (gains / losses if losses else 0.0)


def bootstrap_p_positive(returns, n=10000, seed=1):
    """Probabilité (par rééchantillonnage) que le rendement moyen par trade soit > 0."""
    rng = random.Random(seed)
    k = len(returns)
    return sum(1 for _ in range(n) if sum(rng.choices(returns, k=k)) > 0) / n


def max_drawdown_pct(pnls, capital):
    eq = peak = capital
    dd = 0.0
    for p in pnls:
        eq += p
        peak = max(peak, eq)
        dd = max(dd, (peak - eq) / peak * 100 if peak else 0.0)
    return dd


DEFAULTS = {"min_trades": 200, "min_p_positive": 0.90, "min_profit_factor": 1.3,
            "min_pf_without_top3": 1.0, "max_drawdown_pct": 15.0}


def evaluate(returns_pct, pnls, capital, **kw):
    """returns_pct : rendement net de chaque trade (en %), ordre chronologique ; pnls : résultats en monnaie."""
    g = {**DEFAULTS, **kw}
    n = len(returns_pct)
    checks = []
    checks.append((f"au moins {g['min_trades']} trades", n >= g["min_trades"], f"{n} trades"))
    if n == 0:
        return False, checks
    mean = sum(returns_pct) / n
    checks.append(("rendement moyen par trade > 0 (net de frais)", mean > 0, f"{mean:+.1f} %"))
    p = bootstrap_p_positive(returns_pct)
    checks.append((f"confiance statistique >= {g['min_p_positive']:.0%} que l'espérance est positive",
                   p >= g["min_p_positive"], f"{p:.0%}"))
    pf = _profit_factor(returns_pct)
    checks.append((f"profit factor >= {g['min_profit_factor']}", pf >= g["min_profit_factor"], f"{pf:.2f}"))
    rest = sorted(returns_pct, reverse=True)[3:]
    pf3 = _profit_factor(rest) if rest else 0.0
    checks.append((f"profit factor >= {g['min_pf_without_top3']} SANS les 3 meilleurs trades",
                   pf3 >= g["min_pf_without_top3"], f"{pf3:.2f}"))
    dd = max_drawdown_pct(pnls, capital)
    checks.append((f"drawdown max <= {g['max_drawdown_pct']:g} %", dd <= g["max_drawdown_pct"], f"{dd:.1f} %"))
    return all(ok for _, ok, _ in checks), checks


def format_gate(passed, checks, title="PORTE DE PROMOTION"):
    L = ["=" * 60, title, "=" * 60]
    for name, ok, val in checks:
        L.append(f"  {'✅' if ok else '❌'} {name} : {val}")
    L.append("")
    L.append("RÉSULTAT : " + ("PASSÉE (étape suivante : très petit capital réel, avec les mêmes garde-fous)"
                             if passed else "NON PASSÉE : pas d'argent réel."))
    return "\n".join(L)
