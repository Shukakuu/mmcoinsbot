"""Sizing DYNAMIQUE : le bot décide lui-même combien miser, en fonction de la solidité du signal, DANS un cadre dur.

    taille = équité x plafond_par_position x solidité(score) x concordance(wallets) x contexte(marché/bot)
             puis limitée par : liquidité du pool, impact de sortie, exposition restante ; et remontée au minimum
             nécessaire pour que les frais fixes restent supportables (sinon refus).

La solidité ne peut JAMAIS dépasser le plafond (le meilleur signal = 100 % du plafond) ; après des pertes, le
contexte réduit la taille (jamais l'inverse : pas de martingale).

⚠ Le lien score -> taille n'est PAS validé statistiquement : seuls les plafonds protègent. Tant que la porte de
promotion n'est pas passée, c'est un réglage prudent, pas une preuve que « plus de score = plus de gain »."""
import math


def _clamp(x, lo=0.0, hi=1.0):
    return max(lo, min(hi, x))


def signal_strength(score, min_score, floor):
    q = _clamp((score - min_score) / max(100.0 - min_score, 1e-9))
    return floor + (1.0 - floor) * q


def concordance(eff_weight, min_wallets, no_wallet_factor):
    """Plus de wallets indépendants d'accord = plus de confiance. Sans signal de wallets (découverte seule) : facteur prudent."""
    if not eff_weight or eff_weight <= 0:
        return no_wallet_factor
    return 0.8 + 0.2 * _clamp((eff_weight - min_wallets) / max(5.0 - min_wallets, 1.0))


def context_factor(day_pnl_pct, consec_losses, drawdown_pct, daily_limit_pct):
    """Réduit la taille quand ça va mal (jamais ne l'augmente) : perte du jour, pertes consécutives, drawdown."""
    f = 1.0
    if day_pnl_pct < 0 and daily_limit_pct > 0:
        f *= max(0.5, 1.0 - 0.5 * abs(day_pnl_pct) / daily_limit_pct)
    if consec_losses >= 2:
        f *= 0.5
    if drawdown_pct > 5.0:
        f *= 0.7
    return _clamp(f, 0.25, 1.0)


def _variable_cost_pct(cfg, size_sol, liquidity_usd, sol_usd):
    s = cfg.sim
    impact_each = 2.0 * size_sol * sol_usd / liquidity_usd * 100.0
    return 2.0 * s.fee_pct + s.base_slippage_bps * (1.0 + s.sell_slippage_mult) / 100.0 + 2.0 * impact_each


def min_size_for_costs(cfg, liquidity_usd, sol_usd, ref_size_sol):
    """Plus petite taille pour laquelle frais fixes (pourboires) + frais variables restent sous le plafond de coût.
    inf si impossible."""
    cap = cfg.filters.max_roundtrip_cost_pct
    var = _variable_cost_pct(cfg, ref_size_sol, liquidity_usd, sol_usd)
    room = cap - var
    if room <= 0:
        return math.inf
    return 2.0 * cfg.sim.tip_sol * 100.0 / room


def dynamic_size(cfg, equity, score, eff_weight, liquidity_usd, sol_usd, exposure_sol,
                 day_pnl_pct=0.0, consec_losses=0, drawdown_pct=0.0):
    """Retourne (taille_SOL ou 0, raison, détails). Les détails sont journalisés pour auditer chaque décision."""
    r, z, e = cfg.risk, cfg.sizing, cfg.entry
    d = {"equity": equity, "score": score}
    if equity <= 0 or not liquidity_usd or not sol_usd:
        return 0.0, "no_equity_or_liquidity", d
    cap_pos = equity * r.max_position_pct / 100.0
    strength = signal_strength(score, e.min_score, z.min_strength)
    conc = concordance(eff_weight, e.min_wallets, z.no_wallet_factor)
    ctx = context_factor(day_pnl_pct, consec_losses, drawdown_pct, r.daily_loss_limit_pct)
    size = cap_pos * strength * conc * ctx
    d.update(cap_position_sol=cap_pos, strength=round(strength, 3), concordance=round(conc, 3), context=round(ctx, 3),
             raw_size_sol=size)

    liq_sol = liquidity_usd / sol_usd
    caps = {"liquidity_share": liq_sol * r.max_liquidity_share_pct / 100.0,
            # liquidité de sortie : l'impact de vente modélisé (2 x taille / liquidité) doit rester sous le plafond
            "exit_impact": cfg.filters.max_sell_impact_pct / 100.0 * liq_sol / 2.0,
            "exposure_room": equity * r.max_total_exposure_pct / 100.0 - exposure_sol}
    for name, cap in caps.items():
        if cap < size:
            size, d["limited_by"] = cap, name
    d["caps"] = {k: round(v, 6) for k, v in caps.items()}

    floor = min_size_for_costs(cfg, liquidity_usd, sol_usd, max(size, 1e-9))
    d["min_size_for_costs"] = floor if floor != math.inf else None
    if floor == math.inf:
        return 0.0, "costs_exceed_cap_at_any_size", d
    if size < floor:
        # on remonte jusqu'au minimum viable si les plafonds le permettent, sinon on refuse
        if floor <= min(cap_pos, *caps.values()):
            size = floor
            d["raised_to_cost_floor"] = True
        else:
            return 0.0, "size_too_small_for_costs", d
    if size < r.min_position_sol:
        return 0.0, "size_too_small", d
    d["size_sol"] = round(size, 6)
    return size, "ok", d
