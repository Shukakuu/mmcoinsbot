"""Gestion du risque : taille de position, plafonds, coupe-circuits. Dans le doute : on ne trade pas."""
import os

from .sizing import dynamic_size


class RiskManager:
    def __init__(self, cfg, enforce_stop_file=False, stop_file="STOP"):
        self.cfg = cfg
        self.enforce_stop_file, self.stop_file = enforce_stop_file, stop_file
        self.day = None
        self.day_start_equity = None
        self.day_pnl = 0.0
        self.consec = 0
        self.cooldown_until = 0.0
        self.peak_equity = 0.0
        self.last_sizing = {}

    def _roll(self, ts, equity=None):
        """Nouveau jour => remise à zéro. L'équité de DÉBUT de journée est reconstituée
        (équité actuelle - pertes/gains déjà réalisés aujourd'hui) : peu importe quel événement
        ouvre la journée (clôture de position, entrée...), le stop journalier s'applique."""
        if equity is not None:
            self.peak_equity = max(self.peak_equity, equity)
        d = int(ts // 86400)
        if d != self.day:
            self.day, self.day_pnl, self.day_start_equity = d, 0.0, None
        if self.day_start_equity is None and equity is not None:
            self.day_start_equity = equity - self.day_pnl

    def on_close(self, ts, pnl_sol, equity=None):
        self._roll(ts)                       # change de jour si besoin, avant d'imputer le résultat
        self.day_pnl += pnl_sol
        self._roll(ts, equity)               # équité passée APRÈS la clôture : on retranche day_pnl
        self.consec = self.consec + 1 if pnl_sol < 0 else 0
        if self.consec >= self.cfg.risk.max_consecutive_losses:
            self.cooldown_until = ts + self.cfg.risk.cooldown_minutes * 60
            self.consec = 0

    def check_entry(self, ts, equity, open_positions, liquidity_usd, sol_usd, data_ok=True, score=None, eff_weight=None):
        """Retourne (autorisé, raison, taille_en_SOL). Avec `score`, la taille est DYNAMIQUE (bot/risk/sizing.py) ;
        sans, taille fixe (anciens appels)."""
        r = self.cfg.risk
        self._roll(ts, equity)
        if self.enforce_stop_file and os.path.exists(self.stop_file):
            return False, "kill_switch_file", 0.0
        if not data_ok:
            return False, "data_stale", 0.0
        if ts < self.cooldown_until:
            return False, "cooldown_after_losses", 0.0
        if self.day_start_equity and self.day_pnl <= -self.day_start_equity * r.daily_loss_limit_pct / 100:
            return False, "daily_loss_limit", 0.0
        if len(open_positions) >= r.max_open_positions:
            return False, "max_open_positions", 0.0
        # NB : l'exposition est comptée au COÛT d'entrée de la part restante (choix assumé, prudent
        # à la baisse seulement) : après un x3, l'exposition réelle dépasse ce que voit ce calcul.
        exposure = sum(p.remaining_cost_sol for p in open_positions)
        if equity <= 0 or exposure / equity * 100 >= r.max_total_exposure_pct:
            return False, "max_exposure", 0.0
        if score is not None:
            day_pct = 100.0 * self.day_pnl / self.day_start_equity if self.day_start_equity else 0.0
            dd = 100.0 * (self.peak_equity - equity) / self.peak_equity if self.peak_equity else 0.0
            size, why, self.last_sizing = dynamic_size(self.cfg, equity, score, eff_weight, liquidity_usd, sol_usd,
                                                       exposure, day_pct, self.consec, dd)
            return (True, "ok", size) if size > 0 else (False, why, 0.0)
        size = equity * r.max_position_pct / 100
        if liquidity_usd and sol_usd:
            size = min(size, liquidity_usd / sol_usd * r.max_liquidity_share_pct / 100)
        room = equity * r.max_total_exposure_pct / 100 - exposure
        size = min(size, room)
        if size < r.min_position_sol:
            return False, "size_too_small", 0.0
        return True, "ok", size

    # --- persistance (redémarrage du mode live) ------------------------------------------
    def to_state(self):
        return {"day": self.day, "day_start_equity": self.day_start_equity, "day_pnl": self.day_pnl,
                "consec": self.consec, "cooldown_until": self.cooldown_until, "peak_equity": self.peak_equity}

    def from_state(self, d):
        self.day, self.day_start_equity = d.get("day"), d.get("day_start_equity")
        self.day_pnl, self.consec = d.get("day_pnl", 0.0), d.get("consec", 0)
        self.cooldown_until = d.get("cooldown_until", 0.0)
        self.peak_equity = d.get("peak_equity", 0.0)
