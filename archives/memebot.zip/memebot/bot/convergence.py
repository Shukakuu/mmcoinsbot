"""Détection de convergence : plusieurs wallets INDÉPENDANTS achètent le même token."""
from collections import defaultdict
from dataclasses import dataclass, field
from typing import List, Optional

from .models import WalletEvent


@dataclass
class Signal:
    mint: str
    first_ts: float
    first_price: Optional[float]
    last_ts: float
    wallets: List[str]
    clusters: int
    eff_weight: float
    total_sol: float


class ConvergenceDetector:
    def __init__(self, cfg, book):
        self.cfg, self.book = cfg, book
        self.buys = defaultdict(list)      # mint -> [WalletEvent]
        self.sells = defaultdict(list)     # mint -> [WalletEvent]
        self.fired = {}                    # mint -> ts du dernier déclenchement
        self.recent = defaultdict(list)    # wallet -> [(ts, mint)] sur 1 h : détection des wallets « arroseurs »

    def is_spray(self, wallet, ts):
        """Un wallet qui achète énormément de tokens DIFFÉRENTS en peu de temps ne sélectionne rien : sa présence
        n'apprend rien (sur les données réelles d'un ancien bot, 2 wallets suivis avaient acheté 86 % de tous les tokens)."""
        lst = [(t, m) for t, m in self.recent[wallet] if t >= ts - 3600]
        self.recent[wallet] = lst
        return len({m for _, m in lst}) >= self.cfg.entry.max_tokens_per_wallet_per_hour

    def on_buy(self, ev: WalletEvent) -> Optional[Signal]:
        self.recent[ev.wallet].append((ev.ts, ev.mint))
        win = self.cfg.entry.window_minutes * 60
        lst = [e for e in self.buys[ev.mint] if e.ts >= ev.ts - win]
        lst.append(ev)
        self.buys[ev.mint] = lst

        per_cluster = {}                   # cluster -> (poids max, wallet)
        for e in lst:
            w = self.book.weight(e.wallet)
            if w <= 0 or self.is_spray(e.wallet, ev.ts):
                continue
            c = self.book.cluster(e.wallet)
            if c not in per_cluster or w > per_cluster[c][0]:
                per_cluster[c] = (w, e.wallet)
        if len(per_cluster) < self.cfg.entry.min_wallets:
            return None
        last_fire = self.fired.get(ev.mint)
        if last_fire is not None and ev.ts - last_fire < self.cfg.entry.refire_hours * 3600:
            return None
        self.fired[ev.mint] = ev.ts
        first = min(lst, key=lambda e: e.ts)
        priced = [e for e in sorted(lst, key=lambda e: e.ts) if e.price_sol]
        return Signal(
            mint=ev.mint, first_ts=first.ts, first_price=priced[0].price_sol if priced else None,
            last_ts=ev.ts, wallets=sorted({e.wallet for e in lst}), clusters=len(per_cluster),
            eff_weight=sum(w for w, _ in per_cluster.values()), total_sol=sum(e.sol_amount for e in lst))

    def on_sell(self, ev: WalletEvent):
        self.sells[ev.mint].append(ev)

    def sellers_since(self, mint, wallets, since_ts) -> int:
        ws = set(wallets)
        return len({e.wallet for e in self.sells[mint] if e.wallet in ws and e.ts >= since_ts})
