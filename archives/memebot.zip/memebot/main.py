#!/usr/bin/env python3
"""memebot : bot prudent de memecoins Solana (simulation par défaut).

  python main.py gen-sample                 # crée un scénario de test synthétique
  python main.py replay                     # rejoue le scénario et affiche le rapport
  python main.py live                       # paper trading sur données réelles (HELIUS_API_KEY requis)
  python main.py report --db journal.db     # relit un journal existant
  python main.py discover-wallets           # trouve, évalue et classe seul les wallets à suivre (Helius, lecture seule ; lent, normal)
  python main.py scout                      # paper trading FORWARD sur API publiques (DexScreener + RugCheck), aucune transaction réelle
  python main.py scout-report --db scout.db # rapport 48-72 h : trades, win rate, P&L net, refus, tailles, revue, porte de promotion
  python main.py review --db journal.db     # chaque coin détecté : décision, puis ce qu'il est devenu (bot trompé ou non ?)
  python main.py gate --db journal.db       # la porte de promotion : le bot a-t-il PROUVÉ un avantage ?
  python main.py gate --real-csv real_trades.csv --capital 150   # même test sur les trades d'un autre bot
"""
import argparse
import json
import logging
import sys
from pathlib import Path

from bot.config import load_config
from bot.db import Journal
from bot.engine import Engine
from bot.gate import evaluate, format_gate
from bot.market import ReplayMarket
from bot.models import WalletEvent
from bot.paper import PaperBroker
from bot.report import build_report
from bot.review import format_review, review
from bot.risk import RiskManager
from bot.simulate import write_scenario
from bot.wallets import WalletBook
from bot.x_signal import MockX


def run_replay(cfg, data_path, wallets_path, db_path, verbose_report=True):
    data = json.loads(Path(data_path).read_text())
    if db_path != ":memory:" and Path(db_path).exists() and Path(db_path).stat().st_size > 0:
        raise SystemExit(f"{db_path} existe déjà : un replay sur un journal non vide mélangerait deux comptabilités. "
                         "Choisis un nouveau fichier (--db) ou omets l'option.")
    j = Journal(db_path)
    market = ReplayMarket(data, require_top10=cfg.filters.require_top10)
    book = WalletBook(wallets_path, enforce_j7_freshness=False, journal=j)
    broker = PaperBroker(cfg, market, cfg.capital.start_sol)
    engine = Engine(cfg, market, book, j, broker, RiskManager(cfg), x=MockX({}))
    events = sorted(data["events"], key=lambda e: e["ts"])
    for e in events:
        engine.handle_event(WalletEvent(ts=e["ts"], wallet=e["wallet"], side=e["side"], mint=e["mint"],
                                        sol_amount=e["sol_amount"], token_amount=e.get("token_amount")))
    last = max(max(p[0] for p in t["price_path"]) for t in data["tokens"].values())
    engine.finish(last)
    report = build_report(j, cfg.capital.start_sol, engine.positions, cfg)
    if verbose_report:
        print(report)
    return engine, j, report


def run_gate(cfg, a):
    if a.real_csv:
        import csv
        with open(a.real_csv, encoding="utf-8") as fh:
            rows = list(csv.DictReader(fh))
        pnls = [float(r["pnl_usd"]) for r in rows]
        rets = [100.0 * float(r["pnl_usd"]) / float(r["mise_usd"]) for r in rows]
        capital, title = a.capital, f"PORTE DE PROMOTION sur {a.real_csv} ({len(rows)} trades, capital de référence {a.capital:g})"
    else:
        c = Journal(a.db or "journal.db").c
        rows = c.execute("SELECT pnl_pct,pnl_sol,config_hash FROM positions WHERE close_ts IS NOT NULL "
                         "ORDER BY close_ts").fetchall()
        if rows and not a.all_configs:
            latest = rows[-1][2]
            rows = [r for r in rows if r[2] == latest]
        rets, pnls, capital = [r[0] for r in rows], [r[1] for r in rows], cfg.capital.start_sol
        title = "PORTE DE PROMOTION (version de config/code la plus récente)" if not a.all_configs else "PORTE DE PROMOTION (toutes versions)"
    passed, checks = evaluate(rets, pnls, capital, **cfg.gate)
    print(format_gate(passed, checks, title))
    return passed


def run_discover(cfg, a):
    from bot.sources.dexscreener import DexClient
    from bot.wallet_discovery import WalletDiscovery
    from bot.wallets_registry import WalletRegistry
    j = Journal(a.db or "scout.db")
    reg = WalletRegistry(j, cfg)
    disc = WalletDiscovery.from_env(cfg, j, reg, DexClient(), public_rpc=a.public_rpc)
    if not disc.enabled:
        print(f"Découverte de wallets désactivée : {disc.why}")
        return 0
    u = disc.rpc.usage()
    print(f"Découverte de wallets ({disc.rpc.label}) : crédits aujourd'hui {u['today']}/{u['daily_cap']}, "
          f"ce mois {u['month']}/{u['monthly_budget']}. Première passe lente : c'est normal, la file est reprise à chaque lancement.")
    n = 0
    while not a.max_units or n < a.max_units:
        msg = disc.step()
        if msg is None:
            break
        n += 1
        print(f"  [{n}] {msg}")
    reg.maintenance(disc.now_fn()) if n else None
    u = disc.rpc.usage()
    c = reg.counts()
    print(f"Terminé : {n} travaux, crédits {u['today']}/{u['daily_cap']} aujourd'hui. Wallets par statut : {c or 'aucun'}. "
          f"{'Budget du jour épuisé : relance demain.' if disc.rpc.remaining_today() <= 0 else 'File vide pour le moment.'}")
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("command", choices=["gen-sample", "replay", "live", "report", "gate", "review", "scout", "scout-report", "discover-wallets"])
    ap.add_argument("--config", default="config.toml")
    ap.add_argument("--data", default="sample_data/scenario.json")
    ap.add_argument("--wallets", default="sample_data/wallets.txt")
    ap.add_argument("--db", default=None)
    ap.add_argument("--real-csv", default=None, help="gate : CSV de trades (colonnes pnl_usd, mise_usd)")
    ap.add_argument("--capital", type=float, default=150.0, help="gate --real-csv : capital de référence")
    ap.add_argument("--all-configs", action="store_true", help="gate : inclure toutes les versions de config/code")
    ap.add_argument("--horizon", type=int, choices=[1, 6], default=6, help="review : horizon de suivi en heures")
    ap.add_argument("--public-rpc", action="store_true", help="discover-wallets : autorise le RPC public (lent) sans clé Helius")
    ap.add_argument("--max-units", type=int, default=0, help="discover-wallets : nombre maximal de travaux (0 = jusqu'à épuisement du budget ou de la file)")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args()
    logging.basicConfig(level=logging.INFO if a.verbose else logging.WARNING,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    cfg = load_config(a.config)
    if a.command == "gen-sample":
        write_scenario(a.data, a.wallets)
        print(f"Scénario écrit : {a.data} et {a.wallets}")
    elif a.command == "replay":
        run_replay(cfg, a.data, a.wallets, a.db or ":memory:")
    elif a.command == "discover-wallets":
        return run_discover(cfg, a)
    elif a.command == "scout":
        from bot.scout import run_scout
        run_scout(cfg, a.db or "scout.db")
    elif a.command == "scout-report":
        db = a.db or "scout.db"
        print(build_report(Journal(db), cfg.capital.start_sol, cfg=cfg))
        print()
        print(format_review(review(Journal(db), a.horizon), a.horizon))
        print()
        a.db = db
        run_gate(cfg, a)
    elif a.command == "review":
        print(format_review(review(Journal(a.db or "journal.db"), a.horizon), a.horizon))
    elif a.command == "gate":
        run_gate(cfg, a)
    elif a.command == "report":
        print(build_report(Journal(a.db or "journal.db"), cfg.capital.start_sol, cfg=cfg))
    else:
        from bot.live import run_live
        run_live(cfg, a.db or "journal.db")


if __name__ == "__main__":
    sys.exit(main())
