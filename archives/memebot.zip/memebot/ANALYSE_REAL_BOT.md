# Analyse de `real_bot` (le bot qui a perdu de l'argent)

**Lequel a perdu ?** `real_bot` : c'est le seul des deux qui exécute de vrais ordres (`test_mode: false`,
Robinhood Chain, copie de wallets, mise de 20 % du capital). `memebot` ne passe aucun ordre réel.

Méthode : j'ai décompressé l'archive (CRC32 vérifiés), lu les CSV de trades, le journal (36 démarrages LIVE
du 18 au 22/09/2026, ~1 800 lignes) et le code d'exécution. Je n'ai pas vu le moteur de détection (`engine`,
absent de l'archive) ni l'historique qui a servi à choisir les règles.

## Les chiffres (11 trades réels du CSV)

| | |
|---|---|
| Trades / gagnants | 11 / 3 (**27 %**) |
| Résultat CSV | +10,3 $ |
| **Sans le meilleur trade (+48 $)** | **−38 $** |
| Trade `0x435f…` absent du CSV (80 % revendus à −26 %, aucune ligne de vente pour les 20 % restants) | ≈ −15 $ |
| **Bilan réaliste** | **≈ −5 $ avec ce trade ; ≈ −53 $ sans le coup de chance** |
| Gain moyen / perte moyenne | +18,0 $ / −5,5 $ (profit factor 1,24, porté par un seul trade) |
| Même trade gagnant : bot « papier » vs réel | **5,75× vs 2,58×** |

Coûts réels mesurés dans le journal : entrée **+5,8 % en médiane** par rapport au prix du signal (max +20,6 %),
sortie **−3,3 % en médiane** sous le prix affiché (moyenne −8,7 %, pire cas −52 %), et ~3 % de frais par côté.
**Aller-retour ≈ 17-20 %.** Avec un stop à −25 %, il faut des gagnants énormes pour compenser : c'est ce
que la perte reflète.

## Pourquoi il a perdu (par ordre d'importance, preuves à l'appui)

1. **Les frictions mangent l'avantage.** Voir ci-dessus. Mon simulateur, rejoué avec ces coûts
   (`config.microcap.toml`), fait passer le même scénario de profit factor 1,12 à 0,78.
2. **Le résultat repose sur un seul coup de chance.** Taux de réussite 27 %, et sans un trade le total est négatif.
   11 trades sur 5 jours ne prouvent aucun avantage statistique.
3. **Copie d'un seul wallet, avec retard et sans confirmation.** Les entrées arrivent 2 à 17 s après le wallet,
   déjà plus chères. Aucun second signal indépendant ne valide le token (`memebot` exige 3 clusters indépendants).
4. **Mises trop grosses pour la fiabilité du signal.** 20 % du capital par trade ; les stops réels se sont
   exécutés à −26 %, −32 %, −34 % (pas −25 %) ; un seul trade perdant coûte 4 à 7 % du capital.
5. **Sur-optimisation probable.** Les noms de règles (R1…R28, W2…W6), la fenêtre horaire 18 h-2 h et les seuils
   très précis (13 k$, 85 % du plus haut, dev ≥ 0,05 ETH…) ressemblent à des réglages choisis sur quelques jours
   d'historique. Le résultat « papier » (+453 $ sur 5 trades) vient lui aussi d'UN trade à 5,75×.
6. **Processus.** ~36 démarrages LIVE et 42 reprises d'état en 5 jours, une dizaine de sauvegardes `avant_*`
   (code modifié pendant que de l'argent réel tourne), des tests qui écrivent dans les fichiers de production
   (lignes factices `0xdddd…` dans `real_trades.csv`), passage en réel après quelques heures de mode test,
   et mise par défaut de 20 % alors que son propre README conseille `/set max 10` le premier soir.
7. **Incidents d'exécution.** 24 pannes RPC, `nonce too low`, transaction rejetée à la sortie du seul gagnant,
   et un slippage de vente qui s'élargit automatiquement après chaque échec (12 % → 45 %) : on vend à n'importe
   quel prix quand ça se passe mal.
8. **Sécurité.** Clés privées en clair dans `users.json`, et envoyées via Telegram.
   ⚠ Ce fichier faisait partie de ce que tu m'as envoyé : **considère ce wallet comme compromis**, déplace les
   fonds vers un wallet neuf, et régénère aussi les clés Alchemy / token Telegram si `config.json` en contient.
   Je n'ai copié aucune clé ailleurs.

## Ce que `real_bot` fait mieux (repris ou à reprendre dans `memebot`)

| Idée de `real_bot` | État dans `memebot` |
|---|---|
| Rejeter un signal trop vieux (« signal vu N s trop tard ») | ✅ ajouté (`max_signal_age_s`) |
| Mesurer le coût réel d'exécution (prix décision vs rempli, prix affiché vs reçu) | ✅ slippage d'entrée dans le journal et le rapport ; profil de frictions calibré |
| État persistant et coupe-circuits conservés au redémarrage | ✅ ajouté (`save_state`/`load_state`, refus de démarrer si incohérent) |
| Alerte quand une position n'est plus surveillable / vente bloquée | ✅ alerte « aveugle » ; ⏳ alerting Telegram à faire |
| Expliquer chaque non-achat (« non acheté : raison ») | ✅ déjà dans le journal (raisons de rejet) |
| Protection contre les fausses pools / plancher de prix on-chain / minOut | ⏳ à reprendre quand on écrira l'exécution réelle |
| Mesure du produit réel d'une vente par variation de solde | ⏳ idem |
| Verrou d'instance unique, relance automatique | ⏳ à faire |

## Ce que `memebot` apporte et que `real_bot` n'a pas

Convergence de wallets **indépendants** · journal des tokens **rejetés** pour prouver que les filtres protègent ·
simulation avec coûts réalistes · mise de 1 % et stop journalier · tests déterministes · critères chiffrés avant
l'argent réel (≥ 200 trades, positif net de frais, « sans le meilleur trade » encore positif).

## Ce que je n'ai volontairement PAS repris

La copie d'un seul wallet, la mise de 20 %, et l'exécution réelle. Ce dernier point attend que le paper trading
prouve un avantage **après** frictions mesurées.

## Si tu continues avec `real_bot`

Coupe l'argent réel tant qu'un backtest honnête n'a pas montré un profit net après ~18 % de frictions, divise la
mise par 10-20, gèle le code pendant les tests, sépare les fichiers de test et de production, et compare toujours
« sans le meilleur trade ».


---

## Addendum : « fais mieux » (v2) et ce que je n'ai pas pu vérifier

**Insentos / Ethan Prosper.** Mes recherches n'ont rien retourné de précis sur leurs méthodes (uniquement des guides
génériques) : je ne leur attribue donc aucune règle. Les principes qui reviennent partout (reprendre la mise à x2
et garder un petit reste, taille de position faible, perte maximale par jour de 3-5 %, plafond de slippage de 2-5 %,
sortie au temps, stop remonté à breakeven) étaient déjà dans les deux bots ou ont été ajoutés (breakeven, porte de coût).
Ce ne sont pas ces règles qui ont fait perdre `real_bot` : ce sont les coûts, l'absence de preuve statistique et le
code modifié en production, que ces guides ne mesurent pas. Les résultats d'influenceurs sont par ailleurs
invérifiables et soumis au biais du survivant.

**Test de la porte de promotion sur les 11 trades réels de `real_bot`** : ❌ sur les 6 critères (rendement moyen
−4,0 % par trade, 39 % de confiance que l'espérance soit positive, profit factor 0,84, drawdown 18,9 %). Elle aurait
interdit le passage en réel.

**Ce que la v2 ne fait pas** : elle ne prouve aucun avantage (aucune donnée réelle n'a été testée) ; les appels
réseau (DexScreener, RugCheck, Jupiter, Helius) n'ont jamais été exécutés dans mon environnement ; l'exécution
d'ordres réels, le webhook, l'alerte Telegram et le module X ne sont pas écrits.


---

## Addendum 2 : chaînes d'Axiom, détection de coins et backtest sur `real_state.pkl`

**Ce que dit l'URL Axiom** (la page est une application JavaScript : je n'ai pu lire aucune donnée de coin) :
`chains=sol` et `discoverChains=sol` = l'onglet Discover est **Solana uniquement** ; Pulse (nouveaux tokens) et
Tracker (wallets) couvrent 8 chaînes : sol, robinhood, arc, bnb, ink, hype, base, eth.
Vérifié par sources : Robinhood Chain est un L2 Ethereum (technologie Arbitrum) lancé le 1er juillet 2026, sans token
natif, avec gaz offert 90 jours aux utilisateurs de Robinhood Wallet (soit jusqu'à fin septembre) ; la frénésie
memecoin y a été portée par CASHCAT, Pump.fun l'a intégrée le 8 juillet, et une part notable du volume venait
d'incitations. **Non vérifié** : le contenu de Pulse sur Arc, Ink et Hype.

**Couverture des bots** : `memebot` = Solana seulement (adresses base58, Helius, Jupiter, DexScreener filtré sur
`solana`/WSOL). `real_bot` = Robinhood Chain seulement. Aucun des deux ne couvre Base, Ethereum, BNB, Ink, Hype ni Arc.
`memebot` n'a jamais tourné sur des données réelles : il n'a détecté aucun vrai coin.

**Backtest** (`tools/backtest_real_state.py`, fichier chargé en lecture sûre) : 57 tokens suivis en 5 heures le
22/09 ; 42 ont franchi 13 000 $ ; 30 sur 42 touchent le stop. Résultat par trade selon l'exécution :

| Hypothèse | Moyenne / trade | P(espérance > 0) |
|---|---|---|
| Aucun coût, rempli au franchissement | +70 % | 99 % |
| Coûts mesurés, rempli au franchissement | +45 % | 96 % |
| + gros gagnants capturés à 33 % (ratio réel observé) | −3 % | 36 % |
| Entrée +10 s, capture 33 % | −17 % | 1 % |
| Entrée +30 s, capture 33 % | −13 % | 7 % |
| *Trades réels de `real_bot` (n = 11)* | *−4 %* | *39 %* |

Lecture : l'avantage éventuel n'existe que si l'on remplit au prix exact du franchissement et que l'on capte tout le
côté droit de la distribution, deux hypothèses que les mesures réelles contredisent. Le trade médian perd ~34 %.
**Ce n'est pas un résultat gagnant.** Échantillon : un soir, 57 tokens, biais du survivant possible.


---

## Addendum 3 : alternatives à Axiom, signal des wallets et test du déclencheur

**Alternatives lisibles depuis mon environnement : aucune.** GMGN, Axiom et Photon sont des applications protégées ;
l'API de GeckoTerminal interdit l'accès automatisé à mon outil ; l'API Jupiter exige une clé ; DexScreener n'est pas ouvrable
ici. Je n'ai donc pas pu interroger de marché en direct. **GMGN a en revanche une API officielle** (`gmgn-cli`, clé
personnelle) qui expose les trades smart money / KOL : un adaptateur est fourni (`bot/sources/gmgn.py`), non testé en réel.

**Test du déclencheur sur les données réelles de `real_state.pkl`** (4 wallets suivis, 57 tokens, 5 h) : deux wallets
(`0xa053…`, `0xfbcf…`) ont acheté 49 et 48 des 57 tokens (86 %) : ce sont des « arroseurs », pas de la smart money.
Entrer 10 s après leur achat (coûts réels, capture 33 % des gros gains) : **−22 % par trade en moyenne**, 16 % de réussite,
P(espérance > 0) = 0 %, et **aucune sous-catégorie ne fait mieux** (1, 2 ou 3 acheteurs, avec ou sans wallet sélectif).
Conséquence : filtre anti-arroseurs ajouté, et la convergence de wallets n'a de valeur que si les wallets sont sélectifs
et réellement indépendants.


---

## Addendum 4 : spécification « paper trading forward » (scout)

**Correction de ce que j'avais écrit** : les deux flux de découverte DexScreener (`token-profiles/latest/v1`, `token-boosts/latest/v1`)
sont lisibles par mon outil quand l'URL figure dans ton message, et j'ai pu valider le parseur sur une vraie réponse (extrait :
`tests/fixtures/dexscreener_boosts_real_sample.json`, 9 entrées → 5 tokens Solana distincts, doublon fusionné, tokens Robinhood/BSC/Cronos
écartés). **Les routes par token** (`/token-pairs`, RugCheck, GeckoTerminal) restent inaccessibles depuis mon environnement : je n'ai pu
faire ni tourner 48-72 h de paper trading, ni obtenir un seul prix réel de token. Le rapport demandé ne peut venir que de ta machine
(`python main.py scout`, puis `scout-report`).

**À savoir avant de lire ses résultats** : ces flux sont des promotions payantes ; la simulation du cahier des charges (0,1 % de frais,
1 % de slippage) est environ 10 à 20 fois plus optimiste que les frictions mesurées sur un vrai bot ; et avec peu de capital les
pourboires fixes écrasent le sizing dynamique.


---

## Addendum 5 : découverte automatique de wallets

Module `bot/wallet_discovery.py` + `bot/wallet_scoring.py` + `bot/wallets_registry.py`, commande `python main.py discover-wallets`, auto-entretien
quotidien dans le scout. Lecture seule (liste blanche de 3 méthodes RPC), aucune clé privée, aucune transaction (`NoRealTradingGuardTest` passe toujours).

**Pourquoi des garde-fous aussi stricts** : l'analyse de `real_state.pkl` a montré que 2 des 4 wallets suivis par l'ancien bot avaient acheté 86 % de tous les
tokens et que les suivre faisait perdre −22 % par trade. Le scoring écarte donc les arroseurs, pénalise les premiers acheteurs systématiques, exige un P&L
réalisé non porté par un seul trade, et laisse chaque nouveau wallet à un poids faible tant que ses propres signaux n'ont pas gagné en conditions réelles.

**Trouvé par les tests pendant la construction** : `WalletBook.weight()` renvoyait 1,0 pour un wallet exclu (corrigé) ; la file d'amorçage ne se vidait jamais
et n'aurait jamais été rafraîchie (corrigé).

**Non vérifié** : tout ce qui touche Helius (format réel des réponses, coût en crédits par appel, limites de `getSignaturesForAddress`) ; la qualité
prédictive du score (aucune donnée réelle) ; l'indépendance des wallets découverts.
