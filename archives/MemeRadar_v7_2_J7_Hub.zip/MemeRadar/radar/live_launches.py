"""Optional FREE-only PumpPortal feed. No paid trade subscriptions, no order API.

Needs a user-provided API key. This is not silently activated because the
provider requires registration and a linked wallet for some data services.
"""
from __future__ import annotations
import json, os, threading, time
from .social import is_solana_address


class LaunchFeed:
    def __init__(self,store,stop_event,wakeup=None,key=None):
        self.store=store
        self.stop_event=stop_event
        self.wakeup=wakeup
        self.key=(key if key is not None else os.getenv('PUMPPORTAL_API_KEY','')).strip()
        self.lock=threading.RLock()
        self.status={'enabled':bool(self.key),'connected':False,'creations':0,'migrations':0,
                     'last_event':None,'state':'starting' if self.key else 'optional_no_key','error':None}

    def snapshot(self):
        with self.lock:return dict(self.status)

    def ingest(self,obj):
        if not isinstance(obj,dict):return False
        mint=obj.get('mint')
        if not is_solana_address(mint):return False
        # PumpPortal creation events carry name/symbol; migration events may not.
        kind='migration' if ('migrate' in str(obj.get('txType') or '').lower() or
                              str(obj.get('event') or '').lower()=='migration' or
                              str(obj.get('type') or '').lower()=='migration') else 'creation'
        name=str(obj.get('name') or '')[:80]
        symbol=str(obj.get('symbol') or '')[:25]
        if not self.store.launch_event(mint,kind,name,symbol,'pumpportal'):return False
        from .narrative_intelligence import watch_evidence
        related=watch_evidence(name,symbol,self.store.recent_narrative_events(100)) if name or symbol else []
        self.store.enqueue(mint,'launch_narrative' if related else 'launch_'+kind)
        if self.wakeup:self.wakeup(mint)
        with self.lock:
            self.status['creations' if kind=='creation' else 'migrations']+=1
            self.status['last_event']=time.time()
        return True

    def run(self):
        if not self.key:return
        try:
            import websocket
        except ImportError:
            with self.lock:self.status.update(state='missing_websocket_client',error='Installer websocket-client')
            return
        # One socket, two confirmed free subscriptions. NEVER subscribe to
        # account/token trades (metered). Do not log websocket URLs / API keys.
        while not self.stop_event.is_set():
            ws=None
            try:
                from urllib.parse import quote
                ws=websocket.create_connection('wss://pumpportal.fun/api/data?api-key='+quote(self.key,safe=''),timeout=12)
                ws.settimeout(8)
                ws.send(json.dumps({'method':'subscribeNewToken'}))
                ws.send(json.dumps({'method':'subscribeMigration'}))
                with self.lock:self.status.update(state='connected',connected=True,error=None)
                while not self.stop_event.is_set():
                    try:raw=ws.recv()
                    except websocket.WebSocketTimeoutException:continue
                    if not raw:break
                    if len(raw)>100_000:continue
                    obj=json.loads(raw)
                    if isinstance(obj,dict) and obj.get('message') and not obj.get('mint'):
                        continue
                    self.ingest(obj)
            except Exception as exc:
                with self.lock:self.status.update(state='error',connected=False,error=type(exc).__name__)
            finally:
                if ws:
                    try:ws.close()
                    except Exception:pass
                with self.lock:self.status['connected']=False
            self.stop_event.wait(15)
