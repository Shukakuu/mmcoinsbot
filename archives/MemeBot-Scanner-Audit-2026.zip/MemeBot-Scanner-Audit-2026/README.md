# MemeBot Scanner — Guide complet (Windows)

**Version documentée : MemeBot Scanner — Audit Edition (27 octobre 2026)**  
**Blockchain : Solana • Mode : lecture seule • Langage : Python**

> **À lire avant de commencer :** MemeBot détecte et **affiche** des memecoins répondant à des filtres expérimentaux. Il enregistre ensuite les prix pour observer ce qui s'est passé à **+2 h et +3 h**. Il **n'achète rien**, ne vend rien et ne simule **aucun investissement virtuel**. Un score élevé ne garantit ni un gain, ni l'absence de rug pull. Le programme n'est pas encore validé sur plusieurs jours de marché réel.

## Sommaire

1. [Ce que fait le bot, concrètement](#1-ce-que-fait-le-bot-concrètement)
2. [Interface : que va-t-on voir à l'écran ?](#2-interface--que-va-t-on-voir-à-lécran-)
3. [Combien de temps le laisser tourner ?](#3-combien-de-temps-le-laisser-tourner-)
4. [Installation de A à Z sur Windows 11](#4-installation-de-a-à-z-sur-windows-11)
5. [Premier lancement et diagnostic](#5-premier-lancement-et-diagnostic)
6. [Lancer la surveillance en continu](#6-lancer-la-surveillance-en-continu)
7. [Consulter les résultats et exporter en CSV](#7-consulter-les-résultats-et-exporter-en-csv)
8. [Comprendre les calculs et les contrôles](#8-comprendre-les-calculs-et-les-contrôles)
9. [Comment faire un bon test sur 2 à 3 heures](#9-comment-faire-un-bon-test-sur-2-à-3-heures)
10. [Dépannage et questions fréquentes](#10-dépannage-et-questions-fréquentes)
11. [Fichiers créés, confidentialité et limites](#11-fichiers-créés-confidentialité-et-limites)
12. [Références et commandes utiles](#12-références-et-commandes-utiles)

---

## 1. Ce que fait le bot, concrètement

Le programme réalise la chaîne suivante :

```text
DexScreener + GeckoTerminal (découverte de tokens/pools)
                         |
                         v
         Vérification des données de marché
  (prix, liquidité, volume, âge, achats/ventes...)
                         |
                         v
   Vérification croisée du prix sur la même paire
                         |
                         v
          RugCheck (risques techniques du coin)
                         |
                         v
            Filtres éliminatoires + score
                         |
             +-----------+------------+
             |                        |
           Refus                   Accepté
    Pas de signal publié     Signal affiché à l'écran
                                      |
                                      v
                          Enregistré dans scanner.db
                                      |
                                      v
                         Mesures ~toutes les 10 min
                           +2 h et +3 h également
                                      |
                                      v
                              Rapport + export CSV
```

**Au démarrage :** il contacte des API publiques pour découvrir des candidats sur **Solana seulement**. Il ne parcourt **pas tous les coins de Solana** : les découvertes proviennent des profils/boosts DexScreener et des pools nouveaux/tendance GeckoTerminal. Un boost payé ne suffit jamais, à lui seul, à faire publier une alerte.

**Quand un coin passe les filtres :** le terminal affiche son symbole, son score sur 100, son prix en dollars, sa liquidité, son volume sur une heure, ses changements de prix récents, certains contrôles de risque, son adresse de token (*mint*), l'adresse de la paire et un lien DexScreener. C'est un **signal d'observation**, pas une invitation automatique à l'acheter.

**Pendant les trois heures suivantes :** le programme tente d'enregistrer un point toutes les 10 minutes, puis de vérifier spécialement son prix à +2 h et +3 h. Il mesure les **variations de prix**, pas le bénéfice d'une transaction. Un coin peut être devenu impossible à vendre même si une cotation théorique existe encore.

**S'il ne trouve aucun bon candidat :** il affiche « Aucun signal satisfaisant les contrôles ». Cela peut être normal avec des filtres stricts ; cela peut aussi révéler des sources incomplètes, d'où l'intérêt du diagnostic et des avertissements.

**Ce qu'il ne fait pas :** aucun achat/vente, aucune connexion wallet, aucun ordre fictif, aucune notification Telegram, aucune fenêtre graphique, aucun site web hébergé, aucune prédiction garantie. Le suivi automatique des *smart wallets* J7/Axiom et l'analyse fiable des insiders/narratifs **ne sont pas intégrés à cette version**.

## 2. Interface : que va-t-on voir à l'écran ?

### L'interface actuelle est un terminal

Il s'agit de **texte affiché dans PowerShell ou CMD**, pas d'un tableau de bord web avec boutons, graphiques et cartes. Tu peux laisser la fenêtre ouverte pendant que le bot travaille ; elle écrit les résultats des scans et les mises en garde.

**Exemple fictif de ce que tu pourrais voir (chiffres inventés uniquement pour illustrer l'affichage) :**

```text
===========================================================================
SCANNER Solana (lecture seule) — 27/10 13:00 UTC
Découverts : 82 | Analysés : 10 | Nouveaux signaux : 1

  $EXEMPLE | SCORE 81.0/100 (NON calibré)
  Prix $0.000125 | Vérification Gecko $0.000126 (écart 0.8%)
  Liquidité $125,000 | Volume 1 h $48,000 | Achats/Ventes 1 h 160/87
  Âge 78 min | Variation 5 min 5.4% | 1 h 22.1%
  Top10 17.2% | LP verrouillée 100.0% | RugCheck risque 10
  Découverte : nouveau_pool_gecko
  CONTROLES HUMAINS NON REALISES : narratif, réseaux sociaux, insiders.
  Adresse : <adresse mint réelle affichée ici>
  Pool : <adresse pool réelle affichée ici>
  DexScreener : https://dexscreener.com/solana/...

Motifs de rejet : liquidite_insuffisante_ou_inconnue=4, ...
```

Ce n'est **pas** une capture d'un coin réel ni la promesse que le programme trouvera un coin à chaque cycle.

### Comment consulter le coin toi-même ?

1. Lis le **symbole** et surtout l'**adresse mint** : deux tokens peuvent partager le même nom.
2. Copie l'URL **DexScreener** affichée, et colle-la dans ton navigateur.
3. Vérifie que le mint et la paire correspondent bien à ceux affichés dans le terminal.
4. Observe le graphique, la liquidité, les transactions, la répartition des wallets et les signaux de risque supplémentaires.
5. N'interprète pas « SCORE 81/100 » comme « 81 % de chances de gagner ». C'est un classement expérimental, pas une probabilité.

**Tu peux utiliser PowerShell pour le bot et ton navigateur pour l'analyse manuelle.** Les liens ne s'ouvrent pas automatiquement.

## 3. Combien de temps le laisser tourner ?

| Temps | À quoi cela sert | Ce qu'on peut conclure |
|---|---|---|
| **20 à 30 min** | Vérifier les commandes, les réponses des API et la stabilité | Fonctionnement technique de base, pas la qualité des signaux |
| **4 à 6 heures** | Premier test pratique **si des signaux arrivent assez tôt** | Premières observations à +2 h/+3 h, échantillon trop petit pour juger |
| **24 à 72 heures** | **Durée conseillée pour un premier vrai essai** | Plusieurs périodes de marché, davantage d'occasions de recevoir des signaux |
| **2 à 4 semaines** | Accumuler des signaux, hausses, chutes, données absentes | Une base plus utile pour comparer les filtres ; la fiabilité statistique dépend surtout du nombre et de la diversité des signaux |

**Très important : le chronomètre part à la détection de chaque coin, pas au lancement du programme.** Par exemple, si tu lances MemeBot à 14 h et qu'il signale un token à **18 h**, ses échéances sont vers **20 h (+2 h)** et **21 h (+3 h)**. Il doit rester actif jusqu'à cette dernière échéance, avec une tolérance prévue de **5 minutes**.

Si aucun signal n'est détecté pendant les premières heures, il n'y aura rien à comparer à +2 h ou +3 h. C'est possible et ce n'est pas forcément un bug.

### Conditions pour un suivi correct

- L'ordinateur doit **rester allumé** et connecté à Internet. Sur un portable, branche-le sur secteur.
- Le programme ne travaille pas lorsque le PC **est éteint ou en veille**. Tu peux en général éteindre l'écran sans mettre le PC en veille.
- Sous **Windows 11**, ouvre **Paramètres → Système → Alimentation et batterie** (ou **Alimentation**) → **Écran, mise en veille et veille prolongée**, puis ajuste provisoirement la mise en veille sur secteur. Rétablis ton réglage habituel après le test.
- Laisse **la fenêtre du bot ouverte**. La fermer, ou redémarrer Windows, arrête la surveillance ; les données déjà enregistrées restent dans `scanner.db`.
- Les scans se répètent avec **au moins 120 secondes de pause entre les cycles** par défaut. Le traitement réseau prend du temps en plus : ce n'est pas une exécution à l'heure exacte toutes les deux minutes.
- Si une API tombe au mauvais moment, le suivi peut être noté **`unavailable`** ou **`missed`**. Le programme n'invente pas une ancienne cotation.

---

## 4. Installation de A à Z sur Windows 11

### 4.1 Télécharger et extraire les fichiers

1. Télécharge l'archive **MemeBot Scanner — Audit Edition** contenant ce `README.md`.
2. Dans l'Explorateur de fichiers, fais **clic droit sur le ZIP → Extraire tout**.
3. Place le dossier extrait à un emplacement simple, par exemple :

   ```text
   C:\MemeBot-Scanner\
   ```

   Un dossier sur le Bureau fonctionne aussi. **Évite de lancer les fichiers directement à l'intérieur du ZIP** ; il faut d'abord extraire.

4. Ouvre le dossier. Il doit contenir au moins :

   ```text
   MemeBot-Scanner\
   ├── main.py                      <- commandes du bot
   ├── scanner\
   │   ├── __init__.py
   │   └── core.py                  <- analyse, collecte et stockage
   ├── tools\
   │   └── diagnostic_sources.py    <- test des sources publiques
   ├── tests\
   │   └── test_scanner.py         <- tests automatisés
   ├── START_SCANNER_WINDOWS.bat    <- double-clic pour lancer watch
   ├── README.md                    <- ce guide
   └── RAPPORT_AUDIT_SOURCES_2026-10-27.md
   ```

**Ne mélange pas ce dossier avec l'ancien `real_bot`**, ses fichiers de configuration ou ses clés privées. Le scanner n'a besoin ni de seed phrase, ni de clé API, ni de wallet.

### 4.2 Installer ou vérifier Python

Le code utilise **Python 3.11 minimum**. Ce guide utilise **Python 3.13 sous Windows**.

1. Ouvre **PowerShell** (menu Démarrer → tape `PowerShell`).
2. Entre :

   ```powershell
   py -3.13 --version
   ```

3. Si tu obtiens `Python 3.13.x`, passe à l'étape suivante.
4. Si Python 3.13 n'est pas installé, télécharge-le depuis le [site officiel de Python](https://www.python.org/downloads/windows/), installe-le avec le *Python Launcher* si proposé, puis rouvre PowerShell.
5. Pour connaître les versions disponibles sur ton PC :

   ```powershell
   py -0p
   ```

Si tu disposes de Python 3.11 ou 3.12 et non de 3.13, tu peux remplacer `py -3.13` dans les exemples par `py -3.11` ou `py -3.12`. Le fichier `.bat` fourni, lui, est configuré explicitement pour Python **3.13**.

**Il n'y a rien à installer avec `pip` pour cette version.** Elle utilise les bibliothèques standard de Python ; pas besoin de `requirements.txt`, `npm`, `Node.js`, Helius, J7 ou Playwright.

### 4.3 Ouvrir un terminal au bon endroit

1. Dans l'Explorateur Windows, entre dans le dossier contenant **`main.py`**.
2. Clique sur la **barre d'adresse** de l'Explorateur.
3. Tape `powershell`, puis appuie sur **Entrée**.
4. Le terminal s'ouvre directement dans ce dossier.

Pour vérifier :

```powershell
dir
```

Tu dois voir `main.py`, `START_SCANNER_WINDOWS.bat`, `scanner`, `tools`, etc.

> Si tu vois « can't open file 'main.py' », tu n'es probablement **pas dans le bon dossier**. Entre dans le dossier qui contient réellement `main.py` et recommence.

---

## 5. Premier lancement et diagnostic

Fais **ces trois opérations dans cet ordre** pour éviter de laisser tourner un programme dont les sources ne répondent pas.

### Étape A — Tester le code sans Internet

```powershell
py -3.13 -m unittest discover -s tests -v
```

Ce sont des **tests locaux** avec des données fabriquées pour vérifier différentes réactions du programme. Tu devrais obtenir un message final `OK` sans échec. Ils ne prouvent **ni** le fonctionnement des API en direct **ni** la qualité des memecoins sélectionnés.

Si un test est marqué `FAIL` ou `ERROR`, ne commence pas une longue période de suivi avant d'avoir compris l'erreur.

### Étape B — Tester les vraies API (Internet nécessaire)

```powershell
py -3.13 tools/diagnostic_sources.py
```

Ce diagnostic vérifie notamment :

- si DexScreener renvoie des candidats ;
- si GeckoTerminal renvoie des candidats ;
- si une paire test peut être identifiée ;
- si GeckoTerminal connaît **cette même paire** ;
- si un rapport RugCheck peut être lu.

Tu peux voir des lignes `OK`, `ATTENTION`, `ECHEC` ou `INCONNU`. **Un `OK` de connexion ne signifie pas que le filtre sélectionne des coins sûrs.** Une ligne `INCONNU: aucune paire de test compatible` peut aussi apparaître si les quelques candidats de diagnostic ne possèdent pas de paire adaptée.

En cas d'erreurs répétées, copie **l'intégralité du diagnostic** avant d'ajuster quoi que ce soit. Les API publiques peuvent évoluer ou limiter les requêtes.

### Étape C — Faire un seul scan

```powershell
py -3.13 main.py scan
```

Cette commande :

1. essaie de découvrir des candidats ;
2. analyse jusqu'à **10 nouveaux candidats** (valeur par défaut) ;
3. affiche les nouveaux signaux acceptés, si disponibles ;
4. affiche les motifs de refus et les avertissements des sources ;
5. quitte ensuite. Elle **ne surveille pas en continu**.

Si le terminal affiche `Nouveaux signaux : 0`, regarde les **motifs de rejet** et les éventuelles erreurs d'API. Ne réduis pas les contrôles juste pour forcer une alerte.

---

## 6. Lancer la surveillance en continu

### Méthode la plus simple : double-clic

Dans le dossier, double-clique sur :

```text
START_SCANNER_WINDOWS.bat
```

Le fichier démarre la même commande que ci-dessous et garde une console ouverte. Si Windows demande ce que tu veux faire d'un fichier `.bat`, vérifie que c'est bien le fichier fourni dans **ce projet** avant de le lancer.

### Méthode conseillée : PowerShell

```powershell
py -3.13 main.py watch --interval 120
```

- `watch` : lance les scans et suivis en boucle ;
- `--interval 120` : ajoute **120 secondes de pause** entre les cycles (minimum autorisé) ;
- `--max-candidates 10` : analyse au plus 10 nouveaux candidats à chaque cycle (valeur par défaut) ;
- `--min-score 75` : n'accepte que les tokens atteignant le seuil expérimental de 75/100 **après les contrôles de sécurité** (valeur par défaut).

**Ne lance qu'une seule instance `watch` pour la même base de données.** Des accès concurrents pourraient provoquer des blocages SQLite.

### Exemple de déroulement

```text
14 h 00 : tu lances le bot.
14 h 00 : il découvre, vérifie, puis affiche ses résultats.
14 h 02+ : un nouveau cycle démarre après la pause (plus le traitement).
15 h 20 : il signale le token ABC et l'enregistre.
15 h 30 : il cherche une première mesure à +10 min pour ABC.
17 h 20 : il cherche le résultat de ABC à +2 h.
18 h 20 : il cherche le résultat de ABC à +3 h.
...     : de nouveaux tokens peuvent être détectés entre-temps.
```

Cet horaire est **un scénario explicatif**, pas une promesse de détecter ABC ni de réussir toutes les mesures aux minutes exactes.

### Arrêter proprement

Place-toi dans la fenêtre où `watch` tourne puis presse :

```text
Ctrl + C
```

Le programme arrête sa boucle. Les signaux déjà enregistrés restent dans `scanner.db`. Il ne continue **pas** à travailler lorsque la console est fermée.

### Reprendre après un arrêt

Relance simplement :

```powershell
py -3.13 main.py watch --interval 120
```

Avec la même base `scanner.db`, les coins déjà signalés ne sont pas publiés comme de nouveaux signaux. **Attention :** si la fenêtre d'observation +2 h ou +3 h est dépassée de plus de cinq minutes pendant ton arrêt, la mesure sera classée `missed` ; le scanner ne reconstitue pas artificiellement le prix passé.

---

## 7. Consulter les résultats et exporter en CSV

Ouvre **un deuxième terminal PowerShell** dans le même dossier, pendant que le premier continue à faire tourner `watch`.

### Rapport en texte

```powershell
py -3.13 main.py report
```

Pour chaque signal, le rapport indique :

- le symbole et le **mint** du token ;
- le score initial ;
- la date/heure de la première détection et son prix `t0` ;
- la variation du prix à **+2 h** et **+3 h**, ou l'état de mesure ;
- le nombre de points de suivi valides ou absents ;
- la **plus forte hausse observée** et la **plus forte baisse observée** parmi les points de 10 minutes ;
- une alerte si la liquidité mesurée est descendue à **moins de la moitié** de sa valeur initiale.

Le bilan global présente aussi le nombre de variations positives **parmi les seuls signaux réellement mesurés**, avec leur médiane. Les signaux non mesurés **ne doivent pas être assimilés à des gagnants**.

### Comprendre les statuts

| Affichage | Signification |
|---|---|
| `en attente` | Le moment +2 h ou +3 h n'est pas encore arrivé, ou n'a pas encore été traité |
| `observed` | Deux sources fournissent un prix cohérent de la paire d'origine dans la fenêtre prévue |
| `unavailable` | La cotation vérifiable n'était pas disponible au moment tenté ; pas de résultat inventé |
| `missed` | Le créneau de mesure est dépassé ; pas de prix ultérieur utilisé pour remplacer le point manqué |

La marge de retard pour enregistrer une échéance est **5 minutes**. La surveillance peut recommencer sur un statut temporairement `unavailable` tant que la fenêtre n'est pas dépassée.

### Export pour Excel

```powershell
py -3.13 main.py export --output resultats.csv
```

Tu obtiens `resultats.csv` dans le dossier du bot. Ouvre-le avec Excel ou un tableur. Il contient notamment : token, adresse, date UTC, score, prix initial, statuts +2 h/+3 h, variations, nombres de mesures disponibles/absentes et liquidité.

**L'export ne représente pas des trades** : aucun capital, ordre ou gain réel n'est calculé. Les variations affichées sont **brutes**, sans frais, slippage ou impossibilité de vendre.

### Et si je veux afficher le rapport après une interruption ?

Tu peux lancer, **sans autre instance `watch` active** :

```powershell
py -3.13 main.py report --refresh
```

Cela tente de relever les observations arrivées à échéance, **si leur fenêtre est encore ouverte**, avant d'imprimer le rapport. Cela ne récupère **pas** rétroactivement un cours à 2 h ou 3 h si le moment est déjà dépassé.

### Où les données sont-elles sauvegardées ?

Dans le fichier `scanner.db`, créé automatiquement **dans le dossier où tu lances les commandes**. Conserve-le si tu souhaites préserver ton historique. Le fichier CSV est une exportation : il ne remplace pas la base de données.

Si tu souhaites séparer deux campagnes de test :

```powershell
py -3.13 main.py watch --db test_semaine_2.db --interval 120
py -3.13 main.py report --db test_semaine_2.db
py -3.13 main.py export --db test_semaine_2.db --output semaine_2.csv
```

Utilise **le même `--db`** pour consulter la bonne campagne et ne mélange pas les résultats de tests ayant des paramètres différents.

---

## 8. Comprendre les calculs et les contrôles

### Filtres de marché (valeurs actuelles du code)

| Indicateur | Règle appliquée |
|---|---|
| Réseau / paire | Solana ; token en base, coté en SOL, USDC ou USDT |
| Liquidité DexScreener | Au moins **50 000 $** |
| Volume sur 1 heure | Au moins **10 000 $** |
| Âge de la paire | Entre **10 minutes et 24 heures** |
| Valorisation entièrement diluée (FDV) | Entre **20 000 et 5 000 000 $** |
| Activité achat/vente | Au moins 20 transactions et plus d'achats que de ventes selon le seuil du code |
| Variation sur 5 min | De **−10 % à +25 %** |
| Variation sur 1 h | De **−20 % à +100 %** |
| Acheteurs distincts en 1 h (GeckoTerminal) | Au moins **15** |
| Intensité des achats | Pas plus de **12 achats moyens par acheteur distinct** |
| Cohérence de prix | Écart DexScreener/GeckoTerminal de **5 % maximum**, **sur la même paire** |
| Cohérence de liquidité | Le chiffre Gecko doit rester entre **0,5 et 2 fois** celui de DexScreener |
| Score final | **75/100 minimum**, uniquement après validation des contrôles indispensables |

### Vérifications RugCheck

- Autorités **mint** et **freeze** non actives ;
- concentration déclarée des **10 plus gros détenteurs à 35 % maximum** ;
- absence de risque classé très élevé dans les catégories examinées ;
- score de risque normalisé disponible et **inférieur ou égal à 40/100** ;
- preuve d'un verrouillage de liquidité d'au moins **90 % pour la paire exacte affichée**.

Un champ obligatoire non vérifiable peut provoquer le **rejet**. C'est volontairement restrictif, mais peut aussi exclure des coins légitimes. **Un coin qui passe ces contrôles peut encore subir une chute ou un rug.** Les mécanismes avancés Token-2022, le caractère réellement revendable, les frais de transaction exacts, les wallets liés et les manipulations sophistiquées ne sont pas entièrement contrôlés.

### Que veut dire le score /100 ?

Il combine des facteurs comme la liquidité, le rapport volume/liquidité, la part des achats, l'âge, le momentum et la concentration des détenteurs. **Il n'est pas calibré statistiquement** : `85/100` **ne veut pas dire 85 % de probabilité de monter**. Les seuils choisis sont des **hypothèses de départ**, pas des valeurs démontrées rentables.

### Comment la hausse ou la baisse est-elle calculée ?

```text
Variation (%) = ((Prix observé / Prix initial) - 1) × 100
```

Exemple **fictif** : signal à **0,000100 $**, puis observation à **0,000120 $** :

```text
((0,000120 / 0,000100) - 1) × 100 = +20 %
```

Si le prix passe à **0,000080 $**, la variation est **−20 %**.

Ces pourcentages ne représentent pas le rendement que tu aurais pu réellement obtenir : pas de prix d'exécution garanti, pas de frais déduits, pas de slippage ni de vente confirmée.

---

## 9. Comment faire un bon test sur 2 à 3 heures

Ton idée est de choisir **deux ou trois coins** parmi les signaux et de regarder s'ils montent ou s'ils chutent. Tu peux le faire, mais **n'évalue pas le bot uniquement sur ces deux ou trois coins** : il doit conserver et analyser **tous les signaux qu'il publie**, y compris ceux que tu ne choisis pas.

Je recommande ce protocole :

1. Lance `diagnostic_sources.py`, puis `watch` avec les paramètres par défaut.
2. Laisse tourner **24 à 72 heures** pour le premier essai. Si un coin est détecté près de l'heure d'arrêt prévue, attends **trois heures après ce signal** pour avoir son suivi complet.
3. Pour quelques signaux, ouvre la **paire exacte** sur DexScreener et regarde le graphique, les transactions et la liquidité, sans conclure sur le seul score.
4. Relève le **prix au moment du signal**, pas un meilleur prix choisi après coup. Les heures affichées dans les rapports sont en **UTC**, à convertir pour ton fuseau local.
5. Consulte `report` et `resultats.csv` une fois les échéances écoulées. Note les hausses, baisses, disparitions, liquidités qui s'effondrent et points manquants.
6. Avant de modifier les filtres, accumule davantage de données sur plusieurs journées. Compare ensuite les résultats avant/après **sur des périodes séparées**, pour ne pas sélectionner uniquement les règles qui auraient été gagnantes dans le passé.

**Comment interpréter un échec ?** Si un token rug malgré les vérifications, il faut revoir les contrôles de sécurité ou reconnaître ce qu'ils ne détectent pas. Si un token baisse, cela ne prouve pas automatiquement qu'un calcul arithmétique était erroné : cela peut montrer que la **stratégie de sélection ne prédit pas correctement le marché**. Il faut distinguer la justesse des données, les limites du filtre et le résultat réel.

**Critère de prudence :** ne considère pas le bot comme « fiable » après quelques réussites. Une évaluation sérieuse demande un nombre de signaux suffisant, des données manquantes comptabilisées et des comparaisons sur différents marchés. Aucun bénéfice futur n'est garanti.

---

## 10. Dépannage et questions fréquentes

| Problème / question | Ce qu'il faut faire ou savoir |
|---|---|
| **`py` n'est pas reconnu** | Installer/réparer Python depuis le site officiel, avec Python Launcher ; rouvrir le terminal, puis essayer `py -0p`. |
| **`No suitable Python runtime found`** | La version `3.13` n'est probablement pas installée ; utiliser une version installée prise en charge, ou installer Python 3.13. |
| **`can't open file main.py`** | Tu es dans le mauvais dossier. Ouvre un terminal là où se trouve `main.py`. |
| **La fenêtre `.bat` disparaît ou affiche une erreur** | Lance la commande directement dans PowerShell pour lire le message complet. |
| **`Nouveaux signaux : 0`** | Possible avec ces filtres exigeants. Regarde les raisons de rejet et vérifie le diagnostic API. |
| **`ECHEC`, `ATTENTION`, erreur 429 ou timeout** | Source indisponible ou quota. Vérifie Internet, relance le diagnostic plus tard et évite d'accélérer la boucle. |
| **Aucun résultat dans `report`** | Aucun coin n'a encore été accepté et enregistré dans cette base. Le scanner peut pourtant avoir analysé des candidats refusés. |
| **Un coin a disparu** | Il reste dans les rapports, mais peut être noté `unavailable` ou `missed`. Cela ne prouve pas à lui seul la cause de disparition ou un rug. |
| **Mon PC s'est mis en veille** | Les mesures ne sont pas prises pendant la veille. Relance `watch`, mais les échéances dépassées ne sont pas rattrapées artificiellement. |
| **Les heures sont décalées** | Le bot affiche en **UTC**. En France métropolitaine, le décalage est +1 h en hiver et +2 h en été. |
| **Le bot tourne mais aucun graphique n'apparaît** | Normal : **pas d'interface graphique** dans cette version. Utilise le lien DexScreener pour le graphique, et le CSV pour tes propres courbes. |
| **Est-ce qu'il surveille J7 et Axiom directement ?** | **Non**. Ces intégrations n'existent pas dans ce paquet. |
| **Dois-je payer / acheter des SOL ?** | **Non**. Le scanner n'exécute aucune transaction et n'a pas besoin de wallet. Les API publiques peuvent néanmoins avoir leurs propres limites d'accès. |

**Règle simple :** si les lignes d'erreur reviennent à chaque cycle, **arrête le bot**, lance `diagnostic_sources.py` et conserve les messages. Un scanner qui tourne sans crash n'est pas nécessairement un scanner qui reçoit des données fiables.

---

## 11. Fichiers créés, confidentialité et limites

| Fichier | Rôle |
|---|---|
| `main.py` | Commandes `scan`, `watch`, `report`, `export` |
| `scanner/core.py` | Filtres, API, scoring, calculs et stockage |
| `scanner.db` | **Créé pendant l'utilisation** : signaux et observations conservés en SQLite |
| `scanner_results.csv` / `resultats.csv` | **Créé sur demande** via `export` |
| `START_SCANNER_WINDOWS.bat` | Démarre `watch` avec Python 3.13 |
| `tools/diagnostic_sources.py` | Diagnostic des endpoints et données publiques |
| `tests/test_scanner.py` | Vérification locale des principaux comportements |

- **Ne supprime pas `scanner.db`** si tu veux garder les anciens signaux. Tu peux en faire une copie lorsque le bot est arrêté.
- Ne copie **jamais** des clés du dossier de l'ancien robot dans celui-ci. Aucune clé privée n'est nécessaire.
- Le programme interroge des **API publiques en lecture seule**. La disponibilité, les schémas et les limites d'appels peuvent évoluer.
- Les contrôles de sécurité sont incomplets par nature. Même si toutes les données semblent cohérentes, un memecoin peut perdre la majeure partie de sa valeur très rapidement.
- La version du programme est une **console de recherche expérimentale** : pas d'interface graphique, de notifications, d'apprentissage automatique ni de garantie de détection rentable.
- Les tests effectués à la livraison portent sur des **réponses synthétiques**. Le diagnostic sur des API réelles et l'observation de trois heures sur **ton PC** restent nécessaires pour vérifier l'utilisation concrète.

## 12. Références et commandes utiles

### Sources du marché / risques

- [Documentation officielle DexScreener API](https://docs.dexscreener.com/api/reference)
- [Documentation API GeckoTerminal](https://api.geckoterminal.com/docs/index.html)
- [Site RugCheck](https://rugcheck.xyz/)
- [Documentation J7Tracker](https://docs.j7tracker.io/docs) — **pas intégré au scanner**
- [Documentation Solana — frais de transfert Token-2022](https://solana.com/docs/tokens/extensions/transfer-fees)

### Récapitulatif à copier dans PowerShell (dans le dossier du bot)

```powershell
# 1. Vérifier Python
py -3.13 --version

# 2. Tester le code sans Internet
py -3.13 -m unittest discover -s tests -v

# 3. Vérifier les sources réelles
py -3.13 tools/diagnostic_sources.py

# 4. Faire un scan ponctuel
py -3.13 main.py scan

# 5. Scanner et observer en continu (Ctrl+C pour arrêter)
py -3.13 main.py watch --interval 120

# 6. Dans un DEUXIÈME terminal : consulter les résultats
py -3.13 main.py report

# 7. Dans un DEUXIÈME terminal : exporter les résultats
py -3.13 main.py export --output resultats.csv
```

**Conseil de démarrage :** commence par le diagnostic, fais un scan, puis lance `watch` pour **24 à 72 heures**. Si des signaux apparaissent, garde le programme ouvert **jusqu'à 3 heures après le dernier signal** que tu souhaites examiner. Observe quelques coins manuellement, mais conserve l'historique **complet** pour juger la stratégie.
