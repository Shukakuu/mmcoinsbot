# Audit et fiabilisation du scanner — 26 octobre 2026

## Anomalies corrigées

1. **Prix initial trop ancien :** l'ancienne version enregistrait la cotation DexScreener récupérée *avant* les appels RugCheck, parfois lents. On récupère maintenant la paire une deuxième fois après les contrôles. L'alerte est refusée si son prix final est trop ancien.
2. **Validation de cotation insuffisamment stricte :** seuil d'écart entre DexScreener et GeckoTerminal ramené de 15 % à 5 %, et utilisé aussi pour les points de suivi.
3. **Paire manipulable :** seules les paires dont la base est exactement le mint recherché et la quote est WSOL, USDC ou USDT sont utilisées.
4. **Sécurité de liquidité :** contrôle du verrou LP de la paire exacte via RugCheck (`markets[].pubkey` et `lp.lpLockedPct`). Rejet si absent ou inférieur à 90 %. Ce critère est volontairement conservateur ; certaines paires légitimes ne fourniront pas ce champ.
5. **Filtrage risque RugCheck :** niveaux dangereux étendus et contrôle complémentaire du score normalisé lorsqu'il est présent. Vérification des bornes du pourcentage top-10.
6. **Seuils de sélection :** liquidité minimale 50 000 $, volume minimal 10 000 $/h, score minimum 75. **Ce sont des règles de filtrage heuristiques, non des seuils statistiquement validés.**
7. **Rugs / chutes entre les mesures :** ajout d'observations toutes les 10 min pendant 3 heures, enregistrant les prix, la liquidité, les données absentes et les créneaux manqués. Les extrêmes calculés sont uniquement les extrêmes **observés**, pas des max/min réels continus.
8. **Précision des échéances :** mesures à +2 h/+3 h acceptées seulement dans les 5 minutes suivant l'échéance ; vérification du temps d'observation après la récupération des données, pas seulement avant les requêtes.
9. **Biais du survivant :** l'historique contient aussi les coins dont le prix est indisponible. Le CSV conserve leur statut au lieu de créer un prix fictif.

## Ce qui n'est PAS démontré

- Aucune preuve qu'un score élevé prédise une hausse. Il faut mesurer la performance de **tous** les signaux sur plusieurs périodes de marché, avec des seuils fixés à l'avance.
- Les trois API n'ont pas été exécutées en conditions réelles dans cet environnement ; formats, limites et disponibilité sont encore à confirmer sur Windows.
- Les alertes ne garantissent ni l'absence de rug pull ni l'existence d'un prix de vente exécutable.
- J7, Axiom et la convergence de smart wallets ne sont pas encore des sources intégrées à ce paquet.
- Aucun ordre, aucun portefeuille virtuel, aucune transaction réelle.

## Vérification technique

La suite de tests couvre les calculs de pourcentage, le filtrage des risques, les quotes incompatibles, l'exclusion des mauvaises paires, les mesures à 2 h et 3 h sans substitution, la collecte toutes les 10 minutes, le scénario de chute de 80 %, les périodes manquées, les interruptions de sources et le maintien des signaux introuvables dans les résultats.
