#!/usr/bin/env python3
"""MemeBot Scanner — Solana uniquement, analyse READ-ONLY, sans trading ni monnaie virtuelle.

Usage :
    python main.py scan                         # vérification ponctuelle et nouveaux signaux
    python main.py watch                        # surveillance et mesures +2h / +3h
    python main.py report                       # bilan des observations
    python main.py report --refresh             # actualise les observations dues puis bilan
    python main.py export                       # export CSV des observations

Une absence de signal ne signifie pas une panne. Aucun signal ne garantit une hausse.
"""
import argparse
import time

from scanner.core import Store, export_csv, print_report, print_scan, refresh_due, sample_prices, scan, time_label


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("command", choices=["scan", "watch", "report", "export"])
    parser.add_argument("--db", default="scanner.db", help="base SQLite de signaux sans aucun wallet")
    parser.add_argument("--max-candidates", type=int, default=10, help="tokens au maximum analysés par cycle")
    parser.add_argument("--min-score", type=float, default=75, help="seuil heuristique non calibré")
    parser.add_argument("--interval", type=int, default=120, help="watch : secondes entre scans (>= 120)")
    parser.add_argument("--refresh", action="store_true", help="report : observer les échéances disponibles maintenant")
    parser.add_argument("--output", default="scanner_results.csv", help="export CSV")
    args = parser.parse_args()
    if args.max_candidates < 1 or args.max_candidates > 20:
        parser.error("--max-candidates doit être dans [1,20]")
    if not 0 <= args.min_score <= 100:
        parser.error("--min-score doit être dans [0,100]")
    if args.interval < 120:
        parser.error("--interval doit être >=120 pour les limites API publiques")
    store = Store(args.db)

    def cycle():
        print("\n" + "=" * 75)
        print(f"SCANNER Solana (lecture seule) — {time_label(time.time())}")
        result = refresh_due(store)
        if result:
            print(f"Contrôles +2 h / +3 h : {dict(result)}")
        samples = sample_prices(store)
        if samples:
            print(f"Mesures 10 min (y compris absences) : {dict(samples)}")
        try:
            records, warnings, total = scan(store, max_candidates=args.max_candidates,
                                             min_score=args.min_score)
            print_scan(records, warnings, total)
        except Exception as exc:
            print(f"Erreur de sources pendant ce cycle : {type(exc).__name__}: {exc}")
            print("Aucun signal émis sur ce cycle en cas d'erreur de données.")

    if args.command == "scan":
        cycle()
    elif args.command == "watch":
        print("Lecture seule, aucun achat/vente (ni réel ni virtuel). Ctrl+C pour arrêter.")
        try:
            while True:
                cycle()
                time.sleep(args.interval)
        except KeyboardInterrupt:
            print("\nArrêt propre. Observations conservées dans", args.db)
    elif args.command == "report":
        if args.refresh:
            print("Observations rafraîchies :", dict(refresh_due(store)))
            print("Mesures 10 min :", dict(sample_prices(store)))
        print_report(store)
    else:
        n = export_csv(store, args.output)
        print(f"{n} signaux exportés : {args.output}")


if __name__ == "__main__":
    main()
