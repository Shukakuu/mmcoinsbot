@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo MemeBot Scanner - Solana - LECTURE SEULE
 echo Pas de transactions ou de portefeuille fictif.
py -3.13 main.py watch --interval 120
pause
