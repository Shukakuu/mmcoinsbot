#!/usr/bin/env python3
"""Diagnostique les schémas/connexions des sources publiques, SANS achat/vente.

Ne constitue pas un test de rentabilité. Aucun identifiant API ou clé privée requis.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scanner.core import DEX, GECKO, SourceError, dex_discovery, dex_pair, fetch, gecko_discovery, gecko_pool_quotes, rugcheck


def check(label, fn):
    try:
        val = fn()
    except Exception as e:
        print(f'ECHEC {label}: {type(e).__name__} — {e}')
        return None
    print(f'OK {label}')
    return val


def main():
    print('Diagnostic lecture seule. Aucune transaction et aucune cle requise.\n')
    dex = check('DexScreener / discovery', lambda: dex_discovery(fetch))
    gecko = check('GeckoTerminal / discovery', lambda: gecko_discovery(fetch))
    for name, val in [('DexScreener', dex), ('GeckoTerminal', gecko)]:
        if val is not None:
            found, errors = val
            print(f'  {name}: {len(found)} tokens candidats, {len(errors)} erreurs')
            for error in errors[:4]:
                print('  ATTENTION:', error)
    mints = list(dict.fromkeys(
        (list(dex[0])[:6] if dex else []) + (list(gecko[0])[:6] if gecko else [])))
    # Utiliser aussi les candidates Gecko si les candidates Dex sont absentes.
    if not mints and gecko:
        mints = list(gecko[0])[:6]
    pairs = {}
    for mint in mints:
        try:
            p = dex_pair(mint)
            if p:
                pairs[mint] = p
                break
        except SourceError as exc:
            print('  ATTENTION paire:', exc)
    if not pairs:
        print('INCONNU: aucune paire de test compatible parmi les premieres decouvertes')
        return 0
    mint = next(iter(pairs))
    print(f'Paire test: mint={mint} pool={pairs[mint].get("pairAddress")}')
    gt = check('GeckoTerminal / correspondance du pool exact', lambda: gecko_pool_quotes(pairs))
    if gt is not None:
        if mint in gt:
            print('  Paire identique + orientation base/quote verifiees')
        else:
            print('ATTENTION: cette paire ne peut pas etre recoupee (signal refuse)')
    safety = check('RugCheck / rapport de risque', lambda: rugcheck(mint))
    if safety is not None:
        print('  Champs disponibles:', ', '.join(sorted(k for k,v in safety.items() if v is not None)))
        print('  Risque / LP: cette verif ne garantit jamais l absence de rug')
    print('\nDiagnostic termine. Aucun resultat de rentabilite ni d absence de rug n est prouve.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
