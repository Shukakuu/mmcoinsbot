# Analyse des cinq vidéos — constats vérifiables et décisions de développement

Date : 26 octobre 2026. Bot : MemeBot Scanner, observation seule, Solana.

## Ce qui a effectivement pu être consulté

Les pages YouTube ne fournissaient pas la vidéo complète et la transcription intégrale exploitable dans l'environnement d'analyse. Pour les deux vidéos d'Ethan Prosper, leurs **descriptions et chapitrages publiés** ont pu être récupérés. Pour les trois autres, seuls les titres, métadonnées publiques et, pour l'une d'elles, la description succincte ont été accessibles. Ce document ne prétend donc **pas** avoir analysé image par image, écouté ou retranscrit les cinq vidéos. Aucune recommandation présentée ci-dessous ne doit être attribuée mot pour mot aux auteurs, sauf si elle est clairement reliée à un titre de chapitre visible.

### Vidéo 1 — https://www.youtube.com/watch?v=abCMKgyiRfU
- Titre : *Beginners Guide To Memecoin Trading in 2026 (FREE COURSE)* — Ethan Prosper (17 décembre 2025).
- Chapitres consultables : Coin Stats 04:15 ; Holder Distribution 10:15 ; Multi Walleting & Traders 11:30 ; Filters 16:50 ; Wallet Tracking 17:20 ; Trading Strategies 19:32.
- Décision raisonnable : **ne pas assimiler un score sur prix, volume et liquidité à un contrôle des wallets, de la concentration réelle ou des insiders**. Afficher ces dimensions comme non vérifiées tant qu'une analyse de transactions on-chain n'est pas intégrée et testée.

### Vidéo 2 — https://www.youtube.com/watch?v=WCLPzG5HPQ8
- Titre : *How to Trade Memecoins BEFORE They Explode — Full Course 2025* — Ethan Prosper (13 octobre 2025).
- Chapitres consultables : Pulse Theming 04:00 ; BEST Axiom Filters 05:30 ; Wallet Tracking 07:30 ; Twitter Tracker 13:00 ; How to RESEARCH Coins 19:00.
- Décision raisonnable : distinguer **détection d'un coin**, **confirmation de l'activité**, **vérification du projet/narratif** et **vérification on-chain**. Refuser les découvertes fondées seulement sur des boosts payants et étiqueter les contrôles sociaux comme non vérifiés.

### Vidéo 3 — https://www.youtube.com/watch?v=T81MtiE3fsE
- Titre : *How to Trade Memecoins in 2026 | The Only Beginner Guide You Need* — insentos (11 août 2026).
- Les métadonnées sont accessibles, mais ni transcription ni chapitres détaillés vérifiés : **aucune formule, aucun seuil précis n'en est tiré**.

### Vidéo 4 — https://www.youtube.com/watch?v=Y-YbiQwhV5o
- Titre vérifié : *how to find the next 100x memecoin (FOMO)*.
- Transcription et méthodologie exacte non accessibles : **aucune promesse « 100x » ni méthode d'achat n'est incorporée au programme**.

### Vidéo 5 — https://www.youtube.com/watch?v=bThM26BfDzg
- Titre vérifié : *7 things you should avoid if you are trading memecoins* — vidéo référencée sur la chaîne insentos.
- Les **sept éléments précis** ne sont pas disponibles sous forme vérifiable, il serait trompeur de prétendre les lister. Nous conservons des protections déjà présentes et un filtre expérimental « ne pas courir après un pump », sans attribuer ce filtre à la vidéo.

## Décisions implémentées

1. **Publicité ≠ signal** : rejet des tokens dont l'unique provenance est `dex_boosts_paid`. Un listing parallèle sur GeckoTerminal ne garantit pas une croissance organique, mais apporte un second chemin de découverte.
2. **Anti-FOMO temporaire** : refus si `priceChange.m5 > +25 %` ou `priceChange.h1 > +100 %`, comparé à des seuils précédents de +40 % / +120 %. Il s'agit d'une hypothèse prudente à évaluer sur données réelles, et non de nombres recommandés par les vidéos.
3. **Transparence** : statut `narrative_status=non_verifie`, `smart_wallet_status=non_verifie` et provenance `discovery_kind` visibles dans chaque signal enregistré et à l'écran.
4. **Protection des API** : le bot conserve les raisons du dernier refus et attend dix minutes avant de réanalyser le même coin, sans le bannir définitivement.
5. **Aucun retour au trading** : signal d'observation uniquement ; pas de simulation financière ni de connexion à un wallet.

## Décisions différées

- **Pas d'ajout automatique de J7, FOMO ou Axiom** sans source de données officiellement autorisée, stable et vérifiable. Les outils peuvent être utilisés manuellement pour approfondir un signal.
- **Pas de score de viralité inventé** à partir du symbole ou de noms de projets. Les titres et narratifs peuvent être manipulés.
- **Pas de copie aveugle des gros wallets** : pour faire du suivi on-chain sérieux, il faudrait mesurer P&L réalisés (et non seulement estimés), horizon, liquidité, indépendance des wallets, comportements de sortie et frais réels.
- **Pas de verdict « rentable » avant validation** : mesures horodatées à +2 h/+3 h pour tous les coins, y compris ceux qui disparaissent, avec comptabilité du nombre de données manquantes. Une variation positive de prix ne démontre pas qu'un acheteur pouvait effectivement revendre à ce prix.

## Mesures pour décider après le test

- Nombre total de coins signalés, nombre avec cotations valides à +2 h et +3 h, nombre introuvable.
- Proportions positives **sur tous les signaux** (avec distinction explicite pour les cas sans donnée) et positives seulement **parmi ceux avec mesure**, sans les confondre.
- Variation médiane, pire variation observée, chute de liquidité, cas de rug plausible.
- Comparaison de campagnes à seuils fixes : version originale vs nouvelle version ; ne pas modifier les filtres en cours d'essai.
- Vérification manuelle des récits, liens officiels, insiders et convergence de wallets pour chaque coin shortlisté.

**Limites :** les seuils de 25 %, 100 % ou les scores 75/100 sont des heuristiques non calibrées. Une période de deux ou trois heures n'est pas une preuve de rentabilité future.
