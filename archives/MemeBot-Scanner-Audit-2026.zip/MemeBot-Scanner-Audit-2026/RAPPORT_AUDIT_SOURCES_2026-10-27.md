# Audit documentaire et technique — MemeBot Scanner (27/10/2026)

## Méthode anti-fake news

Priorité à la documentation technique **des fournisseurs** (pour les routes, schémas et plafonds), à la documentation **Solana** (pour les fonctionnalités possibles des tokens), et à la recherche on-chain **avec une méthodologie explicitée** pour les limites de qualité du volume. Une annonce marketing, une vidéo ou un score de risque automatique ne vaut pas une preuve qu'un token montera.

### Sources et conclusions

| Source | Élément recoupé | Incidence |
|---|---|---|
| DexScreener officiel — https://docs.dexscreener.com/api/reference | Routes `token-profiles`, `token-boosts`, `token-pairs` ; limites de 60 et 300 requêtes/min selon la route | Les boosts payants ne donnent pas de bonus et ne suffisent pas à publier un signal |
| GeckoTerminal officiel — https://api.geckoterminal.com/docs/index.html | API V2, version `20230203` recommandée, cache d'environ 60 s, ~10 requêtes/min publiques ; endpoint `pools/multi` | Vérifier le **pool exact**, grouper les requêtes, cadence d'au moins 120 s |
| CoinGecko sur la structure des pools — https://www.coingecko.com/learn/dex-data-api | `attributes.base_token_price_usd`, `reserve_in_usd`, `relationships.base_token`, `transactions` | Confirmation explicite de l'identité du pool avant calcul |
| RugCheck — https://rugcheck.xyz/ | Rapport de sécurité du token, données de liquidité, autorités et holders (format variable) | Données manquantes = refus ; vérification de verrouillage pour le pool exact ; aucun label “sans risque” |
| Solana — https://solana.com/docs/payments/how-payments-work | Token-2022 peut ajouter des frais/limitations au transfert | Ces extensions ne sont pas entièrement vérifiées par le scanner actuel |
| J7 — https://docs.j7tracker.io/docs | Documentation publique de routes pour déployer/acheter/vendre | **Pas de connexion automatique** aux historiques de smart wallets ou à Discover ; ne pas demander de JWT ni utiliser un endpoint d'achat |
| Bitquery — https://bitquery.io/investigations/solana-volume-bots | Étude du 24/08 au 22/09/2026 dans les DEX indexés : 58 % classés non organiques par leur algorithme | Les volumes ne prouvent pas l'intérêt réel ; chiffre spécifique au périmètre de leur étude, ni vérité universelle ni filtre prêt à l'emploi |
| Bitquery — https://bitquery.io/investigations/solana-memecoin-traders-lose-money | Étude publiée en octobre 2026 : 74 % des acheteurs ordinaires étudiés perdaient du SOL sur deux semaines | Indication du risque structurel ; périmètre et biais éventuels à lire, ne pas convertir en probabilité prédictive pour un coin |

## Corrections sur la version précédente

1. **Croisement par pool** : les prix GeckoTerminal pour un *token* peuvent provenir d'une autre paire ; maintenant la même adresse de pool et le même token base/quote doivent être identifiés, faute de quoi le signal est refusé.
2. **Suivi cohérent** : les points +2 h/+3 h et +10 min sont mesurés sur la paire d'origine, pas une paire de remplacement susceptible de changer le prix de référence.
3. **Qualité du volume** : un garde-fou expérimental utilise le nombre d'acheteurs distincts fourni par Gecko et la fréquence d'achat moyenne. Cela **ne prouve pas** l'absence de wash trading.
4. **Coherence de liquidité** : un écart de plus d'un facteur deux entre fournisseurs bloque le signal ; les différences de méthode et la mise en cache peuvent engendrer des faux refus.
5. **RugCheck score absent** : refus au lieu de considérer le champ manquant comme rassurant.
6. **Cadence** : 10 candidats et cycles >=120 secondes par défaut pour ménager l'API gratuite.
7. **Diagnostic réseau** : `tools/diagnostic_sources.py` réalise des GET réels afin de vérifier si les schémas observés correspondent au code chez l'utilisateur.
8. **Résultats conservés** : les rendements publiés ne concernent que les cours observés ; les signaux introuvables ou manqués restent présents dans le bilan.

## Risques qui restent NON couverts

- RugPull, bots vendeurs, drain de liquidité soudain, insiders liés, faux narratif et social engineering ; les filtres sont **préventifs et incomplets**.
- Authentification des wallets, cluster de wallets qui partagent un contrôleur, transactions exécutables, fees de Token-2022, frais réseau, spread, arbitrage, route de sortie, sandwich MEV, taxes et slippage. Ce programme ne simule pas ces phénomènes et n'affirme pas les mesurer.
- Détection des coins créés hors des sources de découverte disponibles. Les profils Dex et les listes Gecko sont une **couverture partielle**.
- Prix et volume parfois artificiels ou retardés. Deux fournisseurs ne constituent pas deux données économiques indépendantes puisqu'ils lisent la même blockchain.
- Les seuils de score/liquidité/momentum sont choisis pour une expérience prudente, pas calibrés scientifiquement. Aucun coin ne peut être qualifié “vraiment rentable” avant observation.

## Preuves techniques et vérifications à faire

- `python -m unittest discover -s tests -v` : 22 tests locaux simulés réussis à la livraison.
- `python tools/diagnostic_sources.py` : **à exécuter sur un PC avec réseau** ; non testé en live dans l'environnement d'édition.
- `python main.py scan` puis `python main.py watch --interval 120` : données réelles du marché à observer sur la machine de l'utilisateur.
- `python main.py report` et `python main.py export` : suivre *tous* les signaux sur la durée, avec état des observations manquantes.

**Décision :** scanner d'observation à validation expérimentale seulement ; aucun achat conseillé ni automatique.
