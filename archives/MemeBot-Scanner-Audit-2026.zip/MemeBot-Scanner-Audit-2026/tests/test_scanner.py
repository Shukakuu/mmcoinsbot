import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from scanner.core import (GECKO, DEX, RUG, Store, assess, candidate, discover,
                          dex_pair, export_csv, gecko_prices, percent, refresh_due, scan)

MINT = 'B' * 44
MINT_BAD = 'C' * 44
NOW = 1_800_000_000.0


def pair(mint=MINT, price=0.00010):
    return {"chainId":"solana", "dexId":"raydium", "url":f"https://dexscreener.com/solana/{mint}",
            "baseToken":{"address":mint,"symbol":"TEST"},"quoteToken":{"address":"So11111111111111111111111111111111111111112"},
            "priceUsd":str(price),"priceNative":"0.000001", "pairAddress":mint,
            "liquidity":{"usd":120000},
            "fdv":250000, "pairCreatedAt":int((NOW-3600)*1000),
            "volume":{"h1":150000},"txns":{"h1":{"buys":180,"sells":60}},
            "priceChange":{"m5":10,"h1":35}}


def safety():
    return {"mint_active":False,"freeze_active":False,"top10_pct":19,
            "rugged":False,"risk_levels":[],"lp_locked_by_pool":{MINT:100,MINT_BAD:100},
            "rugcheck_risk_score":5}


def pool_quotes(url, price='0.00010', buyers=40):
    addresses = url.rsplit('/',1)[-1].split(',')
    return {'data': [
        {'type':'pool','attributes':{
            'address':address,'base_token_price_usd':str(price),
            'reserve_in_usd':'120000',
            'transactions':{'h1':{'buyers': buyers, 'sellers': 22}}},
         'relationships':{'base_token':{'data':{'id':'solana_'+address}},
                          'quote_token':{'data':{'id':'solana_So11111111111111111111111111111111111111112'}}}
        } for address in addresses]}


def provider(url):
    if url == DEX+'/token-profiles/latest/v1':
        return [{"chainId":"solana", "tokenAddress":MINT}]
    if url == DEX+'/token-boosts/latest/v1':
        return [{"chainId":"solana", "tokenAddress":MINT_BAD, "amount":12}]
    if url.startswith(GECKO+'/networks/solana/new_pools'):
        return {"data": [{"relationships":{"base_token":{"data":{"id":"solana_"+MINT}}}}],
                "included": [{"id":"solana_"+MINT,"attributes":{"address":MINT}}]}
    if url.startswith(GECKO+'/networks/solana/trending_pools'):
        return {"data":[],"included":[]}
    if url.startswith(DEX+'/token-pairs/v1/solana/'):
        mint = url.rsplit('/',1)[-1]
        return [pair(mint=mint)]
    if url.startswith(GECKO+'/networks/solana/pools/multi/'):
        return pool_quotes(url)
    if url.startswith(GECKO+'/simple/networks/solana/token_price/'):
        return {"data":{"attributes":{"token_prices":{MINT:"0.000105", MINT_BAD:"0.000105"}}}}
    if url.startswith(RUG):
        return {"token":{"mintAuthority":None,"freezeAuthority":None},"topHolders":[{"pct":1.9}]*10,
                "rugged":False,"risks":[],"markets":[{"pubkey":MINT,"lp":{"lpLockedPct":100}},
                    {"pubkey":MINT_BAD,"lp":{"lpLockedPct":100}}], "score_normalised":5}
    raise AssertionError(url)


class ScannerTests(unittest.TestCase):
    def test_filters_reject_unknowns_and_prices_mismatch(self):
        ok = assess(MINT, pair(), .000105, safety(), {'dex_profiles'}, NOW)
        self.assertTrue(ok['accepted']); self.assertGreaterEqual(ok['score'],65)
        unknown = assess(MINT,pair(),None,safety(),{'dex_profiles'},NOW)
        self.assertFalse(unknown['accepted']); self.assertIn('prix_non_confirme_geckoterminal',unknown['reasons'])
        discrepancy = assess(MINT,pair(),.00020,safety(),{'dex_profiles'},NOW)
        self.assertFalse(discrepancy['accepted'])
        unsafe = safety(); unsafe['mint_active']=True
        self.assertFalse(assess(MINT,pair(),.000105,unsafe,set(),NOW)['accepted'])
        unsafe = safety(); unsafe['top10_pct']=None
        self.assertIn('top10_inconnu',assess(MINT,pair(),.000105,unsafe,set(),NOW)['reasons'])

    def test_filters_token_identity(self):
        swapped = pair(mint='D'*44)
        self.assertIsNone(dex_pair(MINT, get=lambda url:[swapped]))
        self.assertFalse(candidate('not_valid'))
        self.assertFalse(candidate('So11111111111111111111111111111111111111112'))

    def test_sources_discovery_and_scoring(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp)/'signals.db')
            r, warnings, total = scan(store,get=provider,now=NOW,max_candidates=10)
            self.assertEqual(total,2)
            self.assertFalse(warnings)
            self.assertEqual(len(r),2)
            self.assertEqual(sum(x['accepted'] for x in r),1)
            self.assertEqual(len(store.all()),1)
            self.assertIn('boost_payant_sans_decouverte_organique',
                          next(x for x in r if x['mint']==MINT_BAD)['reasons'])
            # No repeated signal when re-scanning same candidate.
            r2, _, total2=scan(store,get=provider,now=NOW+120)
            self.assertEqual(total2,2)
            self.assertEqual(len(r2),0)

    def test_2h_and_3h_are_real_observations_and_missed_not_invented(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp)/'signals.db')
            first = assess(MINT,pair(),.000105,safety(),{'gecko_new_pools'},NOW)
            store.add(first,NOW)
            self.assertEqual(dict(refresh_due(store, get=provider, now=NOW+7200)), {'observed':1})
            r=store.report()[0]
            self.assertEqual(r['status2'],'observed')
            self.assertEqual(r['status3'],None)
            self.assertAlmostEqual(percent(r['px2'],r['price_usd']),0.0)
            # 3h sample taken late -> missing; no fabricated 3h performance.
            self.assertEqual(dict(refresh_due(store,get=provider,now=NOW+3*3600+1900)), {'missed':1})
            r=store.report()[0]
            self.assertEqual(r['status3'],'missed')
            self.assertIsNone(r['px3'])
            path=Path(tmp)/'report.csv'
            self.assertEqual(export_csv(store,path),1)
            self.assertIn('missed',path.read_text('utf-8-sig'))

    def test_price_precision(self):
        self.assertAlmostEqual(percent(0.00012,0.0001),20.0)
        self.assertAlmostEqual(percent(0.00008,0.0001),-20.0)
        self.assertIsNone(percent(1.0,0))


if __name__ == '__main__':
    unittest.main()

class ProviderFailures(unittest.TestCase):
    def test_discrepancy_after_two_hours_is_not_fabricated(self):
        from scanner.core import SourceError
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp)/'s.db')
            r = assess(MINT, pair(), .000105, safety(), {'gecko_new_pools'}, NOW)
            store.add(r,NOW)
            def divergent(url):
                if '/networks/solana/pools/multi/' in url:
                    return pool_quotes(url,price='0.0009')
                return provider(url)
            result = refresh_due(store, get=divergent, now=NOW+7201)
            self.assertEqual(result['unavailable'],1)
            self.assertIsNone(store.report()[0]['px2'])
            self.assertEqual(refresh_due(store, get=provider, now=NOW+7350)['observed'],1)

    def test_missing_rugcheck_no_accepted_coin(self):
        from scanner.core import SourceError
        def get(url):
            if 'rugcheck.xyz' in url:
                raise SourceError('API temporairement inaccessible')
            return provider(url)
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp)/'s.db')
            records, warnings, _ = scan(store,get=get,now=NOW)
            self.assertEqual(len(store.all()),0)
            self.assertTrue(warnings)
            self.assertTrue(all(not r['accepted'] for r in records))

class ConservativeTracking(unittest.TestCase):
    def test_risk_price_filter_and_bad_quote(self):
        from scanner.core import assess
        high = safety(); high['risk_levels']=['high']
        self.assertIn('risque_rug_eleve', assess(MINT,pair(),.00010,high,set(),NOW)['reasons'])
        self.assertIn('ecart_prix_sources_superieur_5pct',
                      assess(MINT,pair(),.00011,safety(),set(),NOW)['reasons'])
        unlocked = safety(); unlocked['lp_locked_by_pool'] = {MINT: 2}
        self.assertIn('liquidite_paire_insuffisamment_verrouillee',
                      assess(MINT,pair(),.0001,unlocked,set(),NOW)['reasons'])
        unknown = safety(); unknown['lp_locked_by_pool'] = {}
        self.assertIn('verrou_liquidite_paire_non_verifiable',
                      assess(MINT,pair(),.0001,unknown,set(),NOW)['reasons'])
        fake_quote = pair(); fake_quote['quoteToken']['address'] = 'D'*44
        self.assertIsNone(dex_pair(MINT,get=lambda url:[fake_quote]))

    def test_10min_samples_record_ruglike_drop_and_missing_slots(self):
        from scanner.core import sample_prices
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp)/'s.db')
            first = assess(MINT,pair(), .0001, safety(), {'gecko_new_pools'},NOW)
            store.add(first,NOW)
            drop_pair = pair(price=.00002); drop_pair['liquidity']['usd'] = 10000
            def dropped(url):
                if '/token-pairs/v1/solana/' in url:
                    return [drop_pair]
                if '/networks/solana/pools/multi/' in url:
                    return pool_quotes(url, price='0.0000201')
                return provider(url)
            # 1st slot 10min recorded at real price -80%, liquidity also -92%.
            result = sample_prices(store,get=dropped,now=NOW+600)
            self.assertEqual(result['observed'],1)
            rows = store.sample_report()
            self.assertEqual(len(rows),1)
            self.assertAlmostEqual(percent(rows[0]['price_usd'],rows[0]['initial_px']),-80)
            self.assertEqual(rows[0]['liquidity_usd'],10000)
            # Restart at 40min -> 20min and 30min cannot be backfilled.
            result = sample_prices(store,get=dropped,now=NOW+2400)
            self.assertEqual(result['missed'],2)
            self.assertEqual(result['observed'],1)
            rows=store.sample_report()
            self.assertEqual([r['status'] for r in rows],['observed','missed','missed','observed'])
            result = sample_prices(store,get=dropped,now=NOW+2401)
            self.assertEqual(sum(result.values()),0)

    def test_report_covers_all_signals_including_unavailable(self):
        from scanner.core import sample_prices, print_report
        from contextlib import redirect_stdout
        from io import StringIO
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp)/'s.db')
            store.add(assess(MINT,pair(),.0001,safety(),set(),NOW),NOW)
            store.add(assess(MINT_BAD,pair(MINT_BAD),.0001,safety(),set(),NOW),NOW)
            def provider_missing(url):
                if '/token-pairs/v1/solana/' in url: return []
                return provider(url)
            result=sample_prices(store,get=provider_missing,now=NOW+600)
            self.assertEqual(result['unavailable'],2)
            out=StringIO()
            with redirect_stdout(out): print_report(store)
            self.assertIn('Signaux : 2',out.getvalue())
            self.assertEqual(out.getvalue().count('0 valides, 1 absents / invérifiables'),2)

class PriceAuditTests(unittest.TestCase):
    def test_final_quote_is_used_not_pre_rugcheck_quote(self):
        from scanner.core import scan
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'s.db')
            calls={'dex':0}
            def moving_price(url):
                if url == DEX+'/token-profiles/latest/v1':
                    return [{'chainId':'solana','tokenAddress':MINT}]
                if url == DEX+'/token-boosts/latest/v1': return []
                if '/networks/solana/new_pools' in url or '/networks/solana/trending_pools' in url:
                    return {'data':[],'included':[]}
                if '/token-pairs/v1/solana/' in url:
                    calls['dex']+=1
                    return [pair(price=.0001 if calls['dex']==1 else .00012)]
                if '/networks/solana/pools/multi/' in url:
                    return pool_quotes(url,price='0.000121')
                return provider(url)
            records, warnings, _=scan(store,get=moving_price,now=NOW)
            self.assertFalse(warnings)
            self.assertEqual(calls['dex'],2)
            self.assertEqual(len(records),1)
            self.assertTrue(records[0]['accepted'])
            self.assertAlmostEqual(store.all()[0]['price_usd'],.00012)

    def test_percentage_arithmetic_extremes(self):
        import math
        self.assertAlmostEqual(percent(.00002,.0001),-80.0)
        self.assertAlmostEqual(percent(.00017,.0001),70.0)
        self.assertAlmostEqual(percent(.0001,.0001),0.0)
        self.assertIsNone(percent(None,.0001))
        self.assertIsNone(percent(.0001,0))


class VideoEditionTests(unittest.TestCase):
    def test_promotion_alone_never_generates_a_signal(self):
        r = assess(MINT, pair(), 0.000105, safety(), {'dex_boosts_paid'}, NOW)
        self.assertFalse(r['accepted'])
        self.assertIn('boost_payant_sans_decouverte_organique', r['reasons'])
        self.assertEqual(r['narrative_status'], 'non_verifie')
        self.assertEqual(r['smart_wallet_status'], 'non_verifie')

    def test_real_organic_discovery_works(self):
        r = assess(MINT, pair(), 0.000105, safety(), {'dex_boosts_paid','gecko_new_pools'}, NOW)
        self.assertTrue(r['accepted'])
        self.assertEqual(r['discovery_kind'], 'nouveau_pool_gecko')

    def test_do_not_chase_fast_pump(self):
        p = pair()
        p['priceChange']['m5'] = 30
        r = assess(MINT, p, 0.000105, safety(), {'gecko_new_pools'}, NOW)
        self.assertFalse(r['accepted'])
        self.assertIn('momentum_extreme_ou_inconnu', r['reasons'])
        p = pair()
        p['priceChange']['h1'] = 110
        r = assess(MINT, p, 0.000105, safety(), {'gecko_new_pools'}, NOW)
        self.assertIn('momentum_extreme_ou_inconnu', r['reasons'])


class RecheckPersistenceTests(unittest.TestCase):
    def test_rejected_coin_is_recorded_and_rechecked_only_after_ten_minutes(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'s.db')
            r1,_,_=scan(store,get=provider,now=NOW)
            self.assertEqual(len(r1),2)
            self.assertEqual(len(store.recent_checks(NOW+120)),2)
            r2,_,_=scan(store,get=provider,now=NOW+120)
            self.assertEqual(len(r2),0)
            r3,_,_=scan(store,get=provider,now=NOW+601)
            self.assertEqual(len(r3),1)
            self.assertEqual(r3[0]['mint'], MINT_BAD)
            self.assertFalse(r3[0]['accepted'])
            status = store.db.execute('SELECT accepted, reasons_json FROM candidate_checks WHERE mint=?',
                                      (MINT_BAD,)).fetchone()
            self.assertEqual(status['accepted'],0)
            self.assertIn('boost_payant_sans_decouverte_organique',status['reasons_json'])

class IndependentPoolVerificationTests(unittest.TestCase):
    def test_wrong_pool_token_identity_cannot_pass(self):
        from scanner.core import gecko_pool_quotes
        forged = pool_quotes(GECKO+'/networks/solana/pools/multi/'+MINT)
        forged['data'][0]['relationships']['base_token']['data']['id'] = 'solana_'+MINT_BAD
        self.assertEqual(gecko_pool_quotes({MINT:pair()}, get=lambda url: forged), {})

    def test_missing_pool_confirmation_blocks_alert(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'s.db')
            def missing(url):
                if '/networks/solana/pools/multi/' in url:
                    return {'data': []}
                return provider(url)
            result,_,_=scan(store,get=missing,now=NOW)
            self.assertEqual(len(store.all()), 0)
            self.assertIn('meme_paire_gecko_non_verifiee',result[0]['reasons'])

    def test_botlike_repeated_buys_block_alert(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'s.db')
            def botlike(url):
                if '/networks/solana/pools/multi/' in url:
                    return pool_quotes(url,buyers=5)
                return provider(url)
            result,_,_=scan(store,get=botlike,now=NOW)
            self.assertEqual(len(store.all()),0)
            self.assertIn('acheteurs_distincts_insuffisants_ou_inconnus', result[0]['reasons'])

    def test_original_pool_pinned_after_launch(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'s.db')
            result=assess(MINT,pair(),.00010,safety(),{'gecko_new_pools'},NOW)
            store.add(result,NOW)
            replacement=pair()
            replacement['pairAddress']=MINT_BAD
            def moved(url):
                if '/token-pairs/v1/solana/' in url:
                    return [replacement]
                return provider(url)
            self.assertEqual(refresh_due(store,get=moved,now=NOW+7200)['unavailable'], 1)
            self.assertIsNone(store.report()[0]['px2'])

    def test_missing_rugcheck_risk_score_is_not_assumed_safe(self):
        s=safety(); s['rugcheck_risk_score']=None
        result=assess(MINT,pair(),.00010,s,{'gecko_new_pools'},NOW)
        self.assertFalse(result['accepted'])
        self.assertIn('score_rugcheck_inconnu',result['reasons'])

    def test_low_gecko_liquidity_rejects_signal(self):
        with tempfile.TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'s.db')
            def contradictory(url):
                if '/networks/solana/pools/multi/' in url:
                    payload=pool_quotes(url)
                    for row in payload['data']:
                        row['attributes']['reserve_in_usd']='1200'
                    return payload
                return provider(url)
            records,_,_=scan(store,get=contradictory,now=NOW)
            self.assertEqual(len(store.all()),0)
            self.assertIn('ecart_liquidite_sources_important_ou_inconnu',records[0]['reasons'])
