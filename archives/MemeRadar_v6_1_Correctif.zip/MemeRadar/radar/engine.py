"""Orchestrates price discovery, independent pool verification and safety research."""
from __future__ import annotations
import time, threading
from . import providers
from .source_scanner import SourceError, number, candidate, gecko_pause_seconds
from .scoring import score_token
from .patterns import detect_patterns
from .store import Store

class Radar:
    def __init__(self, path, wallets_path, interval=20, limit=14, rpc_url=None):
        self.store=Store(path)
        self.interval=max(20,int(interval))
        self.limit=max(1,min(25,int(limit)))
        self.wallet_monitor=providers.PublicWalletMonitor(self.store,wallets_path,rpc_url or 'https://api.mainnet-beta.solana.com')
        self.lock=threading.Lock()
        self.status={'running':False,'last_scan':None,'errors':[],'cycle':0,'scanned':0,'discovered':0,'mode':'live',
                     'interval_seconds':self.interval,'next_scan':None,'started_at':None,'finished_at':None,
                     'duration_seconds':None,'phase':'En attente du premier scan',
                     'progress_done':0,'progress_total':0,'last_outcome':None,'new_tokens':0,
                     'new_candidates':0,'pairs_found':0,'queued_social':0}
        self.stop_event=threading.Event()
        self.refresh_event=threading.Event()
        self._last_social_wake=0

    def social_wakeup(self, mint):
        """Read-only scan trigger, rate-limited; do not duplicate scan workers."""
        now=time.time()
        self.store.enqueue(mint)
        if (not self.stop_event.is_set() and not self.status['running']
              and now-self._last_social_wake>=30 and now-(self.status['last_scan'] or 0)>=15):
            self._last_social_wake=now
            self.refresh_event.set()

    def request_scan(self):
        """Queue one early scan in the existing worker; never start a competing worker."""
        if self.stop_event.is_set() or self.status['running'] or self.refresh_event.is_set():
            return False
        self.refresh_event.set()
        self.status['next_scan']=time.time()
        return True

    def run_once(self):
        if not self.lock.acquire(blocking=False): return False
        started=time.time()
        self.status.update(running=True,started_at=started,phase='Recherche de nouveaux pools',
                           progress_done=0,progress_total=0,next_scan=None,new_tokens=0)
        warnings=[]
        success=False
        try:
            t=time.time()
            try:
                discovered,w=providers.discoveries()
                warnings.extend(w)
            except Exception as exc:
                discovered={};warnings.append(f'Découverte: {type(exc).__name__}: {str(exc)[:150]}')
            self.status['phase']='Surveillance des wallets publics'
            try:
                wallet_mints,w=self.wallet_monitor.scan()
                warnings.extend(w)
            except Exception as exc:
                wallet_mints=set();warnings.append(f'Wallet: {type(exc).__name__}: {str(exc)[:150]}')
            for mint in wallet_mints:
                discovered.setdefault(mint,set()).add('wallet_public')
            # J7 mentions can discover a CA before DEX indexation. They never
            # increase a token's numerical score; no CA means no market match.
            # Monitor old candidates as well, with a strict budget and a share for new discoveries.
            previous=self.store.list_coins(1000)
            known={p['mint'] for p in previous}
            def priority(x):
                mint,src=x
                return (4 if 'j7_direct_contract' in src else 0,
                        3 if 'wallet_public' in src else 0,
                        2 if 'gecko_new_pools' in src else 0,
                        1 if 'gecko_trending_pools' in src else 0,
                        len(src))
            fresh=[m for m,_ in sorted(discovered.items(),key=priority,reverse=True) if m not in known]
            # Keep a small but nonzero old-coin budget; a busy launch window should
            # not starve new discoveries. Rotate stale records instead of reviewing
            # the same high-ranked coin indefinitely.
            old_budget=max(1,self.limit//4)
            urgent=self.store.queue_due(min(max(1,self.limit//3), self.limit-old_budget))
            for q in urgent: discovered.setdefault(q['mint'],set()).add(q['source'])
            active=[p['mint'] for p in sorted(previous,key=lambda p:p.get('last_seen',0))
                    if p['mint'] not in fresh and p['mint'] not in {q['mint'] for q in urgent}]
            urgent_mints=[q['mint'] for q in urgent]
            fresh_budget=max(1,self.limit-len(urgent_mints)-old_budget)
            chosen=list(dict.fromkeys(urgent_mints+fresh[:fresh_budget]+active[:old_budget]+fresh[fresh_budget:]+active[old_budget:]))[:self.limit]
            # These numbers expose whether the bottleneck is the source, pair matching,
            # safety analysis or browser filters (they are otherwise easy to confuse).
            self.status.update(discovered=len(discovered),new_candidates=len(fresh),
                               queued_social=len(urgent))
            self.status.update(progress_total=len(chosen),progress_done=0,
                               phase='Récupération des prix et volumes' if chosen else 'Aucun nouveau candidat à examiner')
            if not chosen:
                self.status.update(scanned=0,pairs_found=0,cycle=self.status['cycle']+1,errors=warnings[:16]);
                success=True
                return True
            try: pairs=providers.dex_pairs_batch(chosen)
            except Exception as exc:
                warnings.append(f'DexScreener: {type(exc).__name__}: {str(exc)[:150]}')
                self.status.update(scanned=0,cycle=self.status['cycle']+1,errors=warnings[:16]);return False
            self.status['pairs_found']=len(pairs)
            self.status['phase']='Vérification des cotations indépendantes'
            gecko,w=providers.quote_same_pools(pairs)
            warnings.extend(w)
            self.status['phase']='Analyse des tokens et des risques'
            new_count=0
            for index,mint in enumerate(chosen):
                pair=pairs.get(mint) or {}
                if not pair:
                    self.status['progress_done']=index+1
                    self.store.queue_done(mint,False)
                    continue  # No unverified market in the coin list.
                prior=self.store.get(mint) or {}
                if not prior and pair: new_count+=1
                sources=set(prior.get('sources') or []) | discovered.get(mint,set())
                safety=self.store.cached_safety(mint)
                if safety is None:
                    try:
                        safety=providers.rug_report(mint)
                        self.store.save_safety(mint,safety)
                    except Exception as exc:
                        warnings.append(f'RugCheck {mint[:6]}…: {type(exc).__name__}')
                        safety={}
                wallets=self.store.wallet_hits(mint)
                history=self.store.history(mint,90)
                live_price=number(pair.get('priceUsd'))
                if live_price is not None and live_price>0:
                    history=history+[{'ts':t,'price':live_price}]
                patterns=detect_patterns(pair,history, wallets, t)
                social=self.store.social_context(mint)
                report=score_token(pair,safety,gecko.get(mint),sources,wallets,t)
                base=pair.get('baseToken') or {}
                liquidity=number((pair.get('liquidity') or {}).get('usd'))
                txns=(pair.get('txns') or {}).get('h1') or {}
                result={
                    'mint':mint,'symbol':str(base.get('symbol') or prior.get('symbol') or '?')[:25],
                    'name':str(base.get('name') or prior.get('name') or '?')[:80],
                    'price_usd':number(pair.get('priceUsd')),'liquidity_usd':liquidity,
                    'volume_h1_usd':number((pair.get('volume') or {}).get('h1')),
                    'market_cap_usd':number(pair.get('marketCap')),'fdv_usd':number(pair.get('fdv')),
                    'buys_h1':number(txns.get('buys')),'sells_h1':number(txns.get('sells')),
                    'change_m5_pct':number((pair.get('priceChange') or {}).get('m5')),
                    'change_h1_pct':number((pair.get('priceChange') or {}).get('h1')),
                    'pair_address':pair.get('pairAddress') if pair else None,
                    'sources':sorted(sources),'wallets':wallets[:10],
                    'patterns':patterns,
                    'safety_summary':{'mint_active':safety.get('mint_active'),
                        'freeze_active':safety.get('freeze_active'),'top10_pct':safety.get('top10_pct'),
                        'rugcheck_score':safety.get('rugcheck_risk_score'),
                        'lp_locked_pct':(safety.get('lp_locked_by_pool') or {}).get(pair.get('pairAddress')) if pair else None},
                    **report}
                result['social_context']=social
                age=result.get('age_min')
                result['regime']='lancement' if age is not None and age<=180 else 'token établi'
                official=social.get('verified_influential_authors_10m',0)
                upstream=social.get('j7_unconfirmed_authors_10m',0)
                influencers=official+upstream
                if influencers>=2 and social['acceleration']>0:
                    result['patterns'].append({'key':'social_attention','label':'Mentions J7 multi-comptes',
                        'why':f"Contrat Solana exact, {influencers} auteurs distincts (≥50 k abonnés), badge signalé par J7 ou confirmé X ; part des abonnés humains inconnue."})
                # X official verification gets higher weight than J7's upstream flags.
                # It changes analysis PRIORITY only, never the safety/status or market score.
                result['attention_score']=min(30,6*official+3*upstream+(6 if influencers>=2 else 0))
                result['priority_score']=round(min(100,report['market_score']/50*70+result['attention_score']),1)
                result['analysis_version']='v6'
                # Require core evidence; a 100% coverage number alone does not prove safety.
                result['eligible']=(not result['risks'] and result['coverage']>=90
                    and liquidity is not None and liquidity>=5000
                    and safety.get('mint_active') is False and safety.get('freeze_active') is False
                    and safety.get('top10_pct') is not None and safety.get('rugcheck_risk_score') is not None)
                self.store.save_coin(result,time.time())
                self.store.record_signal(result)
                self.store.observe(mint,live_price)
                self.store.queue_done(mint,True)
                self.status['progress_done']=index+1
            self.status.update(scanned=len(chosen),cycle=self.status['cycle']+1,errors=warnings[:16],new_tokens=new_count)
            success=True
            return True
        except Exception as exc:
            self.status['errors']=(warnings+[f'Erreur cycle: {type(exc).__name__}: {str(exc)[:150]}'])[:16]
            return False
        finally:
            finished=time.time()
            pause=gecko_pause_seconds()
            self.status['gecko_resume_at']=finished+pause if pause else None
            if pause:
                self.status['errors']=[e for e in self.status.get('errors',[]) if not ('gecko' in e.lower() and '429' in e)]
            self.status.update(running=False,last_scan=finished,finished_at=finished,
                               duration_seconds=round(finished-started,2),last_outcome='ok' if success else 'error',
                               phase='Scan terminé' if success else 'Scan interrompu')
            self.lock.release()

    def run_loop(self):
        while not self.stop_event.is_set():
            self.run_once()
            self.evaluate_due()
            if self.stop_event.is_set(): break
            due=time.time()+self.interval
            self.status['next_scan']=due
            # A manual refresh wakes this wait but cannot overlap a running scan.
            self.refresh_event.wait(self.interval)
            self.refresh_event.clear()
            self.status['next_scan']=None

    def evaluate_due(self):
        """Independent follow-up budget, including risky and hidden candidates."""
        due=self.store.evaluation_due()
        if not due:return
        try:
            pairs=providers.dex_pairs_batch(due)
            for mint in due:
                self.store.observe(mint,number((pairs.get(mint) or {}).get('priceUsd')))
            self.store.research_report()
        except Exception as exc:
            self.status['errors']=(self.status['errors']+[f'Suivi des résultats: {type(exc).__name__}'])[-16:]

    def view(self):
        coins=self.store.list_coins()
        for c in coins:
            hist=self.store.history(c['mint'],60)
            c['history']=[{'ts':p['ts'],'price':p['price']} for p in hist]
            c['social_mentions']=self.store.social_for_mint(c['mint'],5)
            c['research']=self.store.research_for(c['mint'])
            c['fresh']=time.time()-c.get('last_seen',0)<=180
            if (c.get('first_price_usd') or 0)>0 and (c.get('price_usd') or 0)>0:
                c['observed_change_pct']=round((c['price_usd']/c['first_price_usd']-1)*100,2)
            else: c['observed_change_pct']=None
        coins.sort(key=lambda c:({'a_etudier':3,'surveillance':2,'incomplet':1,'risque':0}.get(c.get('status'),0),len(c.get('patterns') or []),c['score']),reverse=True)
        return {'coins':coins, 'stats':{'total':len(coins),'stored':self.store.count_coins(),
                'interesting':sum(c['status']=='a_etudier' for c in coins),
                'incomplete':sum(c['status']=='incomplet' for c in coins),'risky':sum(c['status']=='risque' for c in coins)},
                'status':dict(self.status)}
