@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ===============================================
echo         MemeRadar - Solana Scanner
 echo    Observation uniquement, aucun trade
 echo ===============================================
py -3.13 --version >nul 2>nul
if not errorlevel 1 goto python313
where py >nul 2>nul
if not errorlevel 1 goto python3
python main.py --interval 20
goto end
:python313
py -3.13 main.py --interval 20
goto end
:python3
py -3 main.py --interval 20
:end
echo.
echo Le scanner est arrete ou a rencontre une erreur.
pause
