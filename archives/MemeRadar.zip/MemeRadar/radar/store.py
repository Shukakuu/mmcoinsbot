"""Local SQLite journal for all analyzed tokens and price snapshots."""
from __future__ import annotations
import json, sqlite3, time
from contextlib import contextmanager
from pathlib import Path

SCHEMA = '''
CREATE TABLE IF NOT EXISTS coins (
  mint TEXT PRIMARY KEY, symbol TEXT NOT NULL DEFAULT '?', name TEXT NOT NULL DEFAULT '?',
  first_seen REAL NOT NULL, last_seen REAL NOT NULL, data_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS prices (
  mint TEXT NOT NULL, ts REAL NOT NULL, price REAL NOT NULL, liquidity REAL,
  PRIMARY KEY (mint,ts));
CREATE INDEX IF NOT EXISTS idx_prices_mint_time ON prices(mint,ts);
CREATE TABLE IF NOT EXISTS safety_cache (mint TEXT PRIMARY KEY, ts REAL NOT NULL, data_json TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS wallet_events (
  mint TEXT NOT NULL, wallet TEXT NOT NULL, signature TEXT NOT NULL,
  ts REAL NOT NULL, PRIMARY KEY (mint,wallet,signature));
CREATE TABLE IF NOT EXISTS wallet_cursors (
  wallet TEXT PRIMARY KEY, signature TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT NOT NULL);
'''

class Store:
    def __init__(self, path):
        self.path = str(Path(path).resolve())
        with self.db() as db: db.executescript(SCHEMA)

    @contextmanager
    def db(self):
        """Commit or roll back, and ALWAYS close the SQLite connection."""
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        try:
            db.execute('PRAGMA journal_mode=WAL')
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def get(self, mint):
        with self.db() as db:
            row = db.execute('SELECT * FROM coins WHERE mint=?', (mint,)).fetchone()
        return json.loads(row['data_json']) if row else None

    def list_coins(self, limit=300):
        with self.db() as db:
            rows = db.execute('SELECT data_json FROM coins ORDER BY last_seen DESC LIMIT ?', (limit,)).fetchall()
        return [json.loads(row[0]) for row in rows]

    def save_coin(self, item, ts):
        mint = item['mint']
        with self.db() as db:
            prev = db.execute('SELECT first_seen,data_json FROM coins WHERE mint=?', (mint,)).fetchone()
            item['first_seen'] = prev['first_seen'] if prev else ts
            previous_data=json.loads(prev['data_json']) if prev else {}
            initial = previous_data.get('first_price_usd')
            current = item.get('price_usd')
            item['first_price_usd'] = initial if initial is not None else (current if current and current>0 else None)
            item['last_seen'] = ts
            db.execute('''INSERT INTO coins(mint,symbol,name,first_seen,last_seen,data_json)
                VALUES(?,?,?,?,?,?) ON CONFLICT(mint) DO UPDATE SET
                symbol=excluded.symbol,name=excluded.name,last_seen=excluded.last_seen,
                data_json=excluded.data_json''',
                (mint, item['symbol'], item['name'], item['first_seen'],ts,json.dumps(item,ensure_ascii=False)))
            p = item.get('price_usd')
            if p and p > 0:
                db.execute('INSERT OR IGNORE INTO prices(mint,ts,price,liquidity) VALUES(?,?,?,?)',
                           (mint, int(ts),p,item.get('liquidity_usd')))
            # Long-running monitor: keep latest 3 days of 2-min samples, no fake backfill.
            db.execute('DELETE FROM prices WHERE ts < ?', (ts - 3*86400,))

    def history(self, mint, limit=150):
        with self.db() as db:
            rows = db.execute('SELECT ts,price,liquidity FROM prices WHERE mint=? ORDER BY ts DESC LIMIT ?', (mint,limit)).fetchall()
        return [dict(row) for row in reversed(rows)]

    def cached_safety(self,mint,ttl_s=900):
        with self.db() as db:
            row = db.execute('SELECT * FROM safety_cache WHERE mint=?', (mint,)).fetchone()
        if row and row['ts'] > time.time() - ttl_s: return json.loads(row['data_json'])
        return None

    def save_safety(self,mint,item):
        with self.db() as db:
            db.execute('''INSERT INTO safety_cache VALUES(?,?,?) ON CONFLICT(mint)
                DO UPDATE SET ts=excluded.ts,data_json=excluded.data_json''',
                (mint,time.time(),json.dumps(item)))

    def save_wallet_event(self,mint,wallet,signature,ts):
        with self.db() as db:
            db.execute('INSERT OR IGNORE INTO wallet_events VALUES (?,?,?,?)', (mint,wallet,signature,ts))

    def wallet_hits(self,mint,recent_s=900):
        with self.db() as db:
            rows = db.execute('SELECT DISTINCT wallet FROM wallet_events WHERE mint=? AND ts>=?',(mint,time.time()-recent_s)).fetchall()
        return [r[0] for r in rows]

    def wallet_mints(self, recent_s=14400):
        with self.db() as db:
            rows = db.execute('SELECT DISTINCT mint FROM wallet_events WHERE ts>?',(time.time()-recent_s,)).fetchall()
        return [r[0] for r in rows]

    def cursor(self,wallet):
        with self.db() as db:
            row = db.execute('SELECT signature FROM wallet_cursors WHERE wallet=?',(wallet,)).fetchone()
        return row[0] if row else None

    def set_cursor(self,wallet,signature):
        with self.db() as db:
            db.execute('''INSERT INTO wallet_cursors VALUES(?,?) ON CONFLICT(wallet)
                DO UPDATE SET signature=excluded.signature''',(wallet,signature))

    def stats(self):
        coins = self.list_coins()
        return dict(total=len(coins), promising=sum(x['status']=='a_etudier' for x in coins),
                    risky=sum(x['status']=='risque' for x in coins))
