"""Orchestrates price discovery, independent pool verification and safety research."""
from __future__ import annotations
import time, threading
from . import providers
from .source_scanner import SourceError, number, candidate
from .scoring import score_token
from .patterns import detect_patterns
from .store import Store

class Radar:
    def __init__(self, path, wallets_path, interval=20, limit=14, rpc_url=None):
        self.store=Store(path)
        self.interval=max(20,int(interval))
        self.limit=max(1,min(25,int(limit)))
        self.wallet_monitor=providers.PublicWalletMonitor(self.store,wallets_path,rpc_url or 'https://api.mainnet-beta.solana.com')
        self.lock=threading.Lock()
        self.status={'running':False,'last_scan':None,'errors':[],'cycle':0,'scanned':0,'discovered':0,'mode':'live'}
        self.stop_event=threading.Event()

    def run_once(self):
        if not self.lock.acquire(blocking=False): return False
        self.status['running']=True
        warnings=[]
        try:
            t=time.time()
            try:
                discovered,w=providers.discoveries()
                warnings.extend(w)
            except Exception as exc:
                discovered={};warnings.append(f'Découverte: {type(exc).__name__}: {str(exc)[:150]}')
            try:
                wallet_mints,w=self.wallet_monitor.scan()
                warnings.extend(w)
            except Exception as exc:
                wallet_mints=set();warnings.append(f'Wallet: {type(exc).__name__}: {str(exc)[:150]}')
            for mint in wallet_mints:
                discovered.setdefault(mint,set()).add('wallet_public')
            # Monitor old candidates as well, with a strict budget and a share for new discoveries.
            previous=self.store.list_coins(200)
            known={p['mint'] for p in previous}
            def priority(x):
                mint,src=x
                return (3 if 'wallet_public' in src else 0,
                        2 if 'gecko_new_pools' in src else 0,
                        1 if 'gecko_trending_pools' in src else 0,
                        len(src))
            fresh=[m for m,_ in sorted(discovered.items(),key=priority,reverse=True) if m not in known]
            active=[p['mint'] for p in sorted(previous,key=lambda p:(p.get('status') not in ('a_etudier','surveillance'),(p.get('age_min') or 999999)>30,p.get('last_seen',0)))
                    if p['mint'] not in fresh]
            # Reserve at least half scan capacity for unseen candidates.
            new_limit=max(1,self.limit//2)
            chosen=list(dict.fromkeys(fresh[:new_limit]+active[:self.limit-new_limit]+fresh[new_limit:]))[:self.limit]
            # On quiet periods, no duplicated discovery means no redundant network calls.
            self.status['discovered']=len(discovered)
            if not chosen:
                self.status.update(last_scan=t,scanned=0,cycle=self.status['cycle']+1,errors=warnings[:16]);return True
            try: pairs=providers.dex_pairs_batch(chosen)
            except Exception as exc:
                warnings.append(f'DexScreener: {type(exc).__name__}: {str(exc)[:150]}')
                self.status.update(last_scan=t,scanned=0,cycle=self.status['cycle']+1,errors=warnings[:16]);return False
            gecko,w=providers.quote_same_pools(pairs)
            warnings.extend(w)
            for mint in chosen:
                pair=pairs.get(mint) or {}
                prior=self.store.get(mint) or {}
                sources=set(prior.get('sources') or []) | discovered.get(mint,set())
                safety=self.store.cached_safety(mint)
                if safety is None:
                    try:
                        safety=providers.rug_report(mint)
                        self.store.save_safety(mint,safety)
                    except Exception as exc:
                        warnings.append(f'RugCheck {mint[:6]}…: {type(exc).__name__}')
                        safety={}
                wallets=self.store.wallet_hits(mint)
                history=self.store.history(mint,90)
                live_price=number(pair.get('priceUsd'))
                if live_price is not None and live_price>0:
                    history=history+[{'ts':t,'price':live_price}]
                patterns=detect_patterns(pair,history, wallets, t)
                report=score_token(pair,safety,gecko.get(mint),sources,wallets,t)
                base=pair.get('baseToken') or {}
                liquidity=number((pair.get('liquidity') or {}).get('usd'))
                txns=(pair.get('txns') or {}).get('h1') or {}
                result={
                    'mint':mint,'symbol':str(base.get('symbol') or prior.get('symbol') or '?')[:25],
                    'name':str(base.get('name') or prior.get('name') or '?')[:80],
                    'price_usd':number(pair.get('priceUsd')),'liquidity_usd':liquidity,
                    'volume_h1_usd':number((pair.get('volume') or {}).get('h1')),
                    'market_cap_usd':number(pair.get('marketCap')),'fdv_usd':number(pair.get('fdv')),
                    'buys_h1':number(txns.get('buys')),'sells_h1':number(txns.get('sells')),
                    'change_m5_pct':number((pair.get('priceChange') or {}).get('m5')),
                    'change_h1_pct':number((pair.get('priceChange') or {}).get('h1')),
                    'pair_address':pair.get('pairAddress') if pair else None,
                    'sources':sorted(sources),'wallets':wallets[:10],
                    'patterns':patterns,
                    'safety_summary':{'mint_active':safety.get('mint_active'),
                        'freeze_active':safety.get('freeze_active'),'top10_pct':safety.get('top10_pct'),
                        'rugcheck_score':safety.get('rugcheck_risk_score'),
                        'lp_locked_pct':(safety.get('lp_locked_by_pool') or {}).get(pair.get('pairAddress')) if pair else None},
                    **report}
                self.store.save_coin(result,t)
            self.status.update(last_scan=time.time(),scanned=len(chosen),cycle=self.status['cycle']+1,errors=warnings[:16])
            return True
        finally:
            self.status['running']=False
            self.lock.release()

    def run_loop(self):
        while not self.stop_event.is_set():
            try: self.run_once()
            except Exception as exc:
                self.status['errors']=[f'Erreur cycle: {type(exc).__name__}: {str(exc)[:150]}']
            self.stop_event.wait(self.interval)

    def view(self):
        coins=self.store.list_coins()
        for c in coins:
            hist=self.store.history(c['mint'],60)
            c['history']=[{'ts':p['ts'],'price':p['price']} for p in hist]
            if (c.get('first_price_usd') or 0)>0 and (c.get('price_usd') or 0)>0:
                c['observed_change_pct']=round((c['price_usd']/c['first_price_usd']-1)*100,2)
            else: c['observed_change_pct']=None
        coins.sort(key=lambda c:({'a_etudier':3,'surveillance':2,'incomplet':1,'risque':0}.get(c.get('status'),0),len(c.get('patterns') or []),c['score']),reverse=True)
        return {'coins':coins, 'stats':{'total':len(coins),'interesting':sum(c['status']=='a_etudier' for c in coins),
                'incomplete':sum(c['status']=='incomplet' for c in coins),'risky':sum(c['status']=='risque' for c in coins)},
                'status':dict(self.status)}
