'use strict';
const $ = (id) => document.getElementById(id);
const esc = (v) => String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const statuses={a_etudier:['À ÉTUDIER','a_etudier'],surveillance:['SURVEILLANCE','surveillance'],incomplet:['INCOMPLET','incomplet'],risque:['RISQUE','risque']};
let current={coins:[],stats:{},status:{}}, selected=null;
let favorites=new Set();try{favorites=new Set(JSON.parse(localStorage.getItem('radar_favorites')||'[]'))}catch{}
function money(v){if(v===null||v===undefined||!Number.isFinite(Number(v)))return '—';const n=Number(v);return '$'+(Math.abs(n)>=1000?new Intl.NumberFormat('fr-FR',{maximumFractionDigits:0}).format(n):n.toLocaleString('fr-FR',{maximumFractionDigits:2}));}
function price(v){if(v===null||v===undefined||!Number.isFinite(Number(v))||v<=0)return '—';return '$'+(v<0.0001?Number(v).toPrecision(5):Number(v).toLocaleString('en-US',{maximumSignificantDigits:6}));}
function pct(v){return v===null||v===undefined?'—':`${v>0?'+':''}${Number(v).toFixed(1)} %`;}
function color(v){return v===null||v===undefined?'':v>=0?'up':'down';}
function age(v){return v===null||v===undefined?'—':v<60?Math.round(v)+' min':(v/60).toFixed(1)+' h';}
function since(ts){if(!ts)return 'Jamais';const sec=Math.max(0,Math.round(Date.now()/1000-ts));return sec<60?`${sec} s`:sec<3600?`${Math.round(sec/60)} min`:`${(sec/3600).toFixed(1)} h`;}
function shortMint(m){return m?esc(m.slice(0,5)+'…'+m.slice(-5)):'—';}
function coinId(c){return c.mint;}
function plot(rows){
 const vals=(rows||[]).map(r=>Number(r.price)).filter(p=>Number.isFinite(p)&&p>0);
 if(vals.length<2)return '<span class="tiny">Historique en cours</span>';
 let mn=Math.min(...vals),mx=Math.max(...vals);if(mx===mn){mx+=mn*.001;mn-=mn*.001}
 const coordinates=vals.map((v,i)=>`${(i/(vals.length-1)*110).toFixed(1)},${(32-(v-mn)/(mx-mn)*27).toFixed(1)}`).join(' ');
 const stroke=vals.at(-1)>=vals[0]?'#6ee6b8':'#ff8b9c';
 return `<svg class="sparkline" viewBox="0 0 112 35" aria-label="Prix relevés lors des scans"><polyline points="${coordinates}" fill="none" stroke="${stroke}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>`;
}
function rank(c){return ({a_etudier:3,surveillance:2,incomplet:1,risque:0}[c.status]??0)}
function render(){
 const s=current.stats||{}, st=current.status||{};
 $('statTotal').textContent=s.total??0;$('statInteresting').textContent=s.interesting??0;$('statIncomplete').textContent=s.incomplete??0;$('statRisky').textContent=s.risky??0;
 $('lastScan').textContent=st.last_scan?'Dernier scan : il y a '+since(st.last_scan)+' · '+(st.scanned??0)+' tokens analysés':'En attente du premier scan';
 $('systemText').textContent=st.mode==='demo'?'DÉMONSTRATION':st.running?'Analyse en cours…':st.last_scan?'Surveillance active':'En attente de connexion';
 $('signalDot').className='signal-dot'+(st.last_scan&&!st.running?' on':'');
 $('demoBanner').classList.toggle('hidden',st.mode!=='demo');$('refreshButton').disabled=st.mode==='demo';
 const warnings=(st.errors||[]).slice(0,4);
 $('warningBox').classList.toggle('hidden',warnings.length===0);
 $('warningBox').textContent=warnings.length?'Sources / diagnostics : '+warnings.join(' · '):'';
 const text=$('search').value.trim().toLowerCase(), filter=$('filter').value, sort=$('sort').value;
 let coins=(current.coins||[]).filter(c=>(filter==='all'||(filter==='favorites'?favorites.has(coinId(c)):filter==='signals'?(c.patterns||[]).length>0:c.status===filter))&&
  ((c.symbol||'').toLowerCase().includes(text)||(c.name||'').toLowerCase().includes(text)||(c.mint||'').toLowerCase().includes(text)));
 coins.sort((a,b)=>sort==='signals'?(b.patterns?.length||0)-(a.patterns?.length||0)||b.score-a.score:sort==='score'?b.score-a.score:sort==='recent'?b.first_seen-a.first_seen:
  sort==='age'?(a.age_min??Infinity)-(b.age_min??Infinity):rank(b)-rank(a)||(b.patterns?.length||0)-(a.patterns?.length||0)||b.score-a.score);
 $('coinList').innerHTML=coins.length?coins.map(c=>{
   const label=statuses[c.status]||['INCONNU',''];
   return `<button type="button" class="coin-row" data-mint="${esc(c.mint)}">
    <div class="token-title"><div class="coin-avatar">${esc((c.symbol||'?').slice(0,2).toUpperCase())}</div><div><div class="coin-label"><span class="symbol">$${esc(c.symbol)}<small>${esc((c.name||'').slice(0,17))}</small></span></div><span class="pill ${label[1]}">${label[0]}</span>${(c.patterns||[]).length?`<div class="signal-mini">✦ ${esc(c.patterns.map(x=>x.label).join(" · "))}</div>`:""}</div></div>
    <div><b>${price(c.price_usd)}</b><div class="tiny">${shortMint(c.mint)}</div></div>
    <div><b>${money(c.liquidity_usd)}</b><div class="tiny">1h : ${money(c.volume_h1_usd)}</div></div>
    <div><b class="${color(c.change_m5_pct)}">${pct(c.change_m5_pct)}</b><div class="tiny">Âge ${age(c.age_min)}</div></div>
    <div>${plot(c.history)}<div class="change-small ${color(c.observed_change_pct)}">Depuis 1er relevé : ${pct(c.observed_change_pct)}</div></div>
    <div><div class="score">${esc(c.score)}<small>/100</small></div><div class="tiny">preuves ${esc(c.coverage)} %</div></div></button>`;
 }).join(''):'<div class="empty">Aucun token pour ce filtre. Les scores et les filtres peuvent être stricts ; des résultats vides sont normaux.</div>';
 document.querySelectorAll('.coin-row').forEach(btn=>btn.addEventListener('click',()=>openCoin(btn.dataset.mint)));
}
function chips(items,kind){return (items||[]).length?items.map(x=>`<span class="chip ${kind||''}">${esc(x)}</span>`).join(''):'<span class="muted">Aucun élément enregistré</span>';}
function openCoin(mint){
 selected=mint;const c=(current.coins||[]).find(x=>x.mint===mint);if(!c)return;
 const fav=favorites.has(mint), label=statuses[c.status]?.[0]||'INCONNU',s=c.safety_summary||{};
 $('detailTitle').textContent='$'+(c.symbol||'?')+' · '+(c.name||'Coin');
 const url=current.status.mode==='demo'?'':`https://dexscreener.com/solana/${encodeURIComponent(mint)}`;
 $('detailBody').innerHTML=`<div class="detail-intro"><span class="pill ${esc(c.status)}">${label}</span><p>Mint : <code>${esc(mint)}</code></p>
 <p>Découvert il y a ${since(c.first_seen)} · dernière vérification il y a ${since(c.last_seen)}</p></div>
 <div class="detail-metrics">
 <div class="detail-stat"><small>Score non calibré</small><strong>${esc(c.score)}/100</strong></div>
 <div class="detail-stat"><small>Preuves présentes</small><strong>${esc(c.coverage)} %</strong></div>
 <div class="detail-stat"><small>Prix indicatif</small><strong>${price(c.price_usd)}</strong></div>
 <div class="detail-stat"><small>Liquidité</small><strong>${money(c.liquidity_usd)}</strong></div>
 <div class="detail-stat"><small>Volume sur 1 h</small><strong>${money(c.volume_h1_usd)}</strong></div>
 <div class="detail-stat"><small>Variation 5 min</small><strong class="${color(c.change_m5_pct)}">${pct(c.change_m5_pct)}</strong></div>
 <div class="detail-stat"><small>Achats / Ventes 1 h</small><strong>${c.buys_h1??'—'} / ${c.sells_h1??'—'}</strong></div>
 <div class="detail-stat"><small>Top 10 détenteurs</small><strong>${s.top10_pct==null?'Inconnu':pct(s.top10_pct)}</strong></div>
 <div class="detail-stat"><small>Risque RugCheck</small><strong>${s.rugcheck_score??'Inconnu'}</strong></div></div>
 <div class="details-section"><h3>Historique des prix relevés</h3><div style="margin:8px 0">${plot(c.history)}</div><span class="muted">${c.history?.length||0} relevés disponibles. La courbe n’est pas un historique complet du marché.</span></div>
 <div class="details-section"><h3>Signaux observés (méthodes combinées)</h3><div class="chips">${(c.patterns||[]).length?c.patterns.map(x=>`<div class="pattern" title="${esc(x.why)}"><strong>✦ ${esc(x.label)}</strong><small>${esc(x.why)}</small></div>`).join(""):'<span class="muted">Aucun signal spécifique enregistré pour le moment.</span>'}</div></div>
 <div class="details-section"><h3>Motifs favorables</h3><div class="chips">${chips(c.positives,'good')}</div></div>
 <div class="details-section"><h3>Décomposition du score</h3><div class="scoring-pieces">${Object.entries(c.pieces||{}).map(([k,v])=>`<div><span>${esc(k)}</span><strong>+${Number(v).toFixed(1)}</strong></div>`).join("")||'<span class="muted">Non disponible</span>'}</div><p class="muted">Score heuristique non calibré, les valeurs manquantes valent zéro, et un risque critique bloque le statut « À étudier ».</p></div>
 <div class="details-section"><h3>Risques détectés</h3><div class="chips">${chips(c.risks,'bad')}</div></div>
 <div class="details-section"><h3>Points non vérifiés</h3><div class="chips">${chips(c.unknown)}</div></div>
 <div class="details-section"><h3>Sources et wallets publics</h3><div class="chips">${chips((c.sources||[]).concat((c.wallets||[]).map(x=>'Solde augmenté : '+x.slice(0,7)+'…')))}</div>
 <p class="muted">Un solde de token qui augmente ne prouve pas un achat ; les wallets distincts peuvent appartenir à une même personne. Les boosts publicitaires ne donnent aucun point de qualité.</p></div>
 <div class="modal-note">Contrôles incomplets ≠ token sûr. Un score élevé ne signifie pas un futur pump. Vérifie la liquidité réelle, les détenteurs et la possibilité de vendre avant toute décision manuelle.</div>
 <div class="links"><button id="favoriteButton" class="outline-button">${fav?'★ Retirer des favoris':'☆ Ajouter aux favoris'}</button>${url?`<a href="${url}" target="_blank" rel="noopener noreferrer">Ouvrir DexScreener ↗</a>`:''}</div>`;
 $('favoriteButton').addEventListener('click',()=>{if(favorites.has(mint))favorites.delete(mint);else favorites.add(mint);
  localStorage.setItem('radar_favorites',JSON.stringify([...favorites]));openCoin(mint);render()});
 $('overlay').classList.remove('hidden');
}
$('closeModal').addEventListener('click',()=>$('overlay').classList.add('hidden'));
$('overlay').addEventListener('click',(e)=>{if(e.target===$('overlay'))$('overlay').classList.add('hidden')});
document.addEventListener('keydown',(e)=>{if(e.key==='Escape')$('overlay').classList.add('hidden')});
$('search').addEventListener('input',render);$('filter').addEventListener('change',render);$('sort').addEventListener('change',render);
$('refreshButton').addEventListener('click',async()=>{try{await fetch('/api/refresh',{method:'POST'});$('lastScan').textContent='Scan demandé…'}catch{$('lastScan').textContent='Erreur de connexion locale'}});
async function load(){try{const res=await fetch('/api/data',{cache:'no-store'});if(!res.ok)throw Error('HTTP '+res.status);current=await res.json();render();}catch(e){$('systemText').textContent='Interface hors connexion';$('signalDot').className='signal-dot';$('warningBox').textContent='Impossible de récupérer les données : '+e.message;$('warningBox').classList.remove('hidden')}}
load();setInterval(load,5000);
